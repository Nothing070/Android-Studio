package com.example.cerpenapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class Beranda extends AppCompatActivity {

    RecyclerView recyclerView;
    FloatingActionButton fabTambah;
    TextView textKosong;
    CerpenAdapter adapter;
    ArrayList<Cerpen> daftarCerpen;

    SharedPreferences sharedPreferences;
    Gson gson = new Gson();
    String PREF_CERPEN = "cerpen_pref";

    private final ActivityResultLauncher<Intent> tambahCerpenLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    String judul = result.getData().getStringExtra("judul_cerpen");
                    String isi = result.getData().getStringExtra("isi_cerpen");

                    if (judul != null && isi != null) {
                        daftarCerpen.add(new Cerpen(judul, isi));
                        adapter.notifyItemInserted(daftarCerpen.size() - 1);
                        simpanCerpen();
                        periksaDataKosong();
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beranda);

        recyclerView = findViewById(R.id.recyclerCerpen);
        fabTambah = findViewById(R.id.fabTambah);
        textKosong = findViewById(R.id.textKosong);
        sharedPreferences = getSharedPreferences(PREF_CERPEN, MODE_PRIVATE);

        daftarCerpen = muatCerpen();

        adapter = new CerpenAdapter(daftarCerpen,
                posisi -> {
                    Cerpen terpilih = daftarCerpen.get(posisi);
                    Intent intent = new Intent(this, DetailCerpenActivity.class);
                    intent.putExtra("judul", terpilih.getJudul());
                    intent.putExtra("isi", terpilih.getIsi());
                    startActivity(intent);
                },
                posisi -> {
                    new AlertDialog.Builder(this)
                            .setTitle("Hapus Cerpen")
                            .setMessage("Yakin ingin menghapus cerpen ini?")
                            .setPositiveButton("Hapus", (dialog, which) -> {
                                daftarCerpen.remove(posisi);
                                adapter.notifyItemRemoved(posisi);
                                simpanCerpen();
                                periksaDataKosong();
                            })
                            .setNegativeButton("Batal", null)
                            .show();
                });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        Animation anim = AnimationUtils.loadAnimation(this, R.anim.fade_slide_in);
        recyclerView.startAnimation(anim);
        fabTambah.startAnimation(anim);

        fabTambah.setOnClickListener(v -> {
            Intent intent = new Intent(this, TambahCerpen.class);
            tambahCerpenLauncher.launch(intent);
        });

        periksaDataKosong();
    }

    public void periksaDataKosong() {
        textKosong.setVisibility(daftarCerpen.isEmpty() ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(daftarCerpen.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void simpanCerpen() {
        String json = gson.toJson(daftarCerpen);
        sharedPreferences.edit().putString("list_cerpen", json).apply();
    }

    private ArrayList<Cerpen> muatCerpen() {
        String json = sharedPreferences.getString("list_cerpen", null);
        if (json != null) {
            Type type = new TypeToken<ArrayList<Cerpen>>(){}.getType();
            return gson.fromJson(json, type);
        }
        return new ArrayList<>();
    }
}
