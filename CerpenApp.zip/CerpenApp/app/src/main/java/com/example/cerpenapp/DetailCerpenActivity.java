package com.example.cerpenapp;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DetailCerpenActivity extends AppCompatActivity {

    TextView textJudul, textIsi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_cerpen);

        textJudul = findViewById(R.id.textJudulDetail);
        textIsi = findViewById(R.id.textIsiDetail);

        String judul = getIntent().getStringExtra("judul");
        String isi = getIntent().getStringExtra("isi");

        textJudul.setText(judul != null ? judul : "Judul tidak tersedia");
        textIsi.setText(isi != null ? isi : "Isi tidak tersedia");
    }
}
