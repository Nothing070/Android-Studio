package com.example.cerpenapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class CerpenAdapter extends RecyclerView.Adapter<CerpenAdapter.ViewHolder> {

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public interface OnItemLongClickListener {
        void onItemLongClick(int position);
    }

    private final ArrayList<Cerpen> dataList;
    private final OnItemClickListener clickListener;
    private final OnItemLongClickListener longClickListener;

    public CerpenAdapter(ArrayList<Cerpen> dataList, OnItemClickListener clickListener, OnItemLongClickListener longClickListener) {
        this.dataList = dataList;
        this.clickListener = clickListener;
        this.longClickListener = longClickListener;
    }

    @NonNull
    @Override
    public CerpenAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_cerpen, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CerpenAdapter.ViewHolder holder, int position) {
        Cerpen cerpen = dataList.get(position);
        holder.textView.setText(cerpen.getJudul());

        holder.itemView.setOnClickListener(v -> clickListener.onItemClick(holder.getAdapterPosition()));
        holder.itemView.setOnLongClickListener(v -> {
            longClickListener.onItemLongClick(holder.getAdapterPosition());
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.textCerpenItem);
        }
    }
}
