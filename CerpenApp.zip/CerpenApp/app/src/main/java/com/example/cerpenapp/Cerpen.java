package com.example.cerpenapp;

public class Cerpen {
    private String judul, isi;

    public Cerpen(String judul, String isi) {
        this.judul = judul;
        this.isi = isi;
    }

    public String getJudul() {
        return judul;
    }

    public String getIsi() {
        return isi;
    }
}
