package com.example.cerpenapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {

    EditText editUsername, editPassword;
    Button buttonLogin, buttonRegister;
    CheckBox checkboxShowPassword;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonRegister = findViewById(R.id.buttonBuatAkun);
        checkboxShowPassword = findViewById(R.id.checkboxShowPassword);

        sharedPreferences = getSharedPreferences("user_pref", MODE_PRIVATE);

        // Checkbox untuk menampilkan password
        checkboxShowPassword.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                editPassword.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            } else {
                editPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            }
            editPassword.setSelection(editPassword.getText().length());
        });

        buttonLogin.setOnClickListener(v -> {
            String inputUser = editUsername.getText().toString().trim();
            String inputPass = editPassword.getText().toString().trim();

            String savedUser = sharedPreferences.getString("username", null);
            String savedPass = sharedPreferences.getString("password", null);

            if (inputUser.isEmpty() || inputPass.isEmpty()) {
                Toast.makeText(this, "Isi semua kolom!", Toast.LENGTH_SHORT).show();
            } else if (savedUser == null || savedPass == null) {
                Toast.makeText(this, "Belum ada akun terdaftar!", Toast.LENGTH_SHORT).show();
            } else if (inputUser.equals(savedUser)) {
                if (inputPass.equals(savedPass)) {
                    Toast.makeText(this, "Login berhasil!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(this, Beranda.class));
                    finish();
                } else {
                    Toast.makeText(this, "Password salah!", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Username tidak ditemukan!", Toast.LENGTH_SHORT).show();
            }
        });

        buttonRegister.setOnClickListener(v -> {
            startActivity(new Intent(this, Register.class));
        });
    }
}
