package com.example.cerpenapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;

public class TambahCerpen extends AppCompatActivity {

    EditText editJudulCerpen, editIsiCerpen;
    MaterialButton buttonSimpanCerpen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tambah_cerpen);

        editJudulCerpen = findViewById(R.id.editJudulCerpen);
        editIsiCerpen = findViewById(R.id.editIsiCerpen);
        buttonSimpanCerpen = findViewById(R.id.buttonSimpanCerpen);

        Animation anim = AnimationUtils.loadAnimation(this, R.anim.fade_slide_in);
        editJudulCerpen.startAnimation(anim);
        editIsiCerpen.startAnimation(anim);
        buttonSimpanCerpen.startAnimation(anim);

        buttonSimpanCerpen.setOnClickListener(v -> {
            String judul = editJudulCerpen.getText().toString().trim();
            String isi = editIsiCerpen.getText().toString().trim();

            if (judul.isEmpty() || isi.isEmpty()) {
                Toast.makeText(this, "Judul dan isi tidak boleh kosong!", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent();
                intent.putExtra("judul_cerpen", judul);
                intent.putExtra("isi_cerpen", isi);
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }
}
