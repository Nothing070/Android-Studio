package com.example.cerpenapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Register extends AppCompatActivity {

    EditText editNama, editEmail, editPasswordRegister;
    Button buttonDaftar;
    TextView textRegister;

    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        editNama = findViewById(R.id.editNama);
        editEmail = findViewById(R.id.editEmail);
        editPasswordRegister = findViewById(R.id.editPasswordRegister);
        buttonDaftar = findViewById(R.id.buttonDaftar);
        textRegister = findViewById(R.id.textRegister);

        Animation fade = AnimationUtils.loadAnimation(this, R.anim.fade_slide_in);
        textRegister.startAnimation(fade);
        editNama.startAnimation(fade);
        editEmail.startAnimation(fade);
        editPasswordRegister.startAnimation(fade);
        buttonDaftar.startAnimation(fade);

        sharedPreferences = getSharedPreferences("user_pref", MODE_PRIVATE);

        buttonDaftar.setOnClickListener(v -> {
            String nama = editNama.getText().toString().trim();
            String email = editEmail.getText().toString().trim();
            String pass = editPasswordRegister.getText().toString().trim();

            if (nama.isEmpty() || email.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Harap isi semua data!", Toast.LENGTH_SHORT).show();
            } else {
                // Simpan ke SharedPreferences
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("username", nama);       // gunakan nama sebagai username
                editor.putString("password", pass);
                editor.apply();

                Toast.makeText(this, "Akun berhasil dibuat!", Toast.LENGTH_SHORT).show();

                // Kembali ke halaman login
                Intent intent = new Intent(Register.this, Login.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
