package com.example.eksplorasifarrelapp;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class DataSiswa extends AppCompatActivity {

    private EditText Nama;

    private RadioGroup jnskelamin;

    private RadioButton LakiLaki;

    private RadioButton perempuan;

    private EditText Alamat;

    private EditText Kelas;

    private EditText Noabsen;

    private TextView TampilNama;

    private TextView TampilJenisKelamin;

    private TextView TampilAlamat;

    private TextView TampilKelas;

    private TextView TampilNoAbsen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_siswa);
        Nama=(EditText)findViewById(R.id.isinama);
        jnskelamin=(RadioGroup)findViewById(R.id.radiogrup);
        LakiLaki=(RadioButton)findViewById(R.id.rdb1);
        perempuan=(RadioButton)findViewById(R.id.rdb2);
        Alamat=(EditText)findViewById(R.id.alamatRumah);
        Kelas=(EditText)findViewById(R.id.isikelas);
        Noabsen=(EditText)findViewById(R.id.noAbsen);
    }
    public void hasil(View view){
        setContentView(R.layout.hasil);
        TampilNama=(TextView)findViewById(R.id.tampilNama);
        TampilNama.setTextColor(Color.WHITE);
        TampilNama.setBackgroundColor(Color.BLUE);
        TampilNama.setText(Nama.getText());

        TampilJenisKelamin=(TextView)findViewById(R.id.tampilJenisKelamin);
        TampilJenisKelamin.setTextColor(Color.BLACK);
        if (LakiLaki.isChecked()){
            TampilJenisKelamin.setBackgroundColor(Color.GRAY);
            TampilJenisKelamin.setText("Laki-laki");
        }
        if (perempuan.isChecked()){
            TampilJenisKelamin.setBackgroundColor(Color.MAGENTA);
            TampilJenisKelamin.setText("Perempuan");
        }

        TampilAlamat=(TextView)findViewById(R.id.tampilAlamat);
        TampilAlamat.setTextColor(Color.BLACK);
        TampilAlamat.setBackgroundColor(Color.RED);
        TampilAlamat.setText(Alamat.getText());

        TampilKelas=(TextView)findViewById(R.id.tampilKelas);
        TampilKelas.setTextColor(Color.BLACK);
        TampilKelas.setBackgroundColor(Color.CYAN);
        TampilKelas.setText(Kelas.getText());

        TampilNoAbsen=(TextView)findViewById(R.id.tampilNoAbsen);
        TampilNoAbsen.setTextColor(Color.BLACK);
        TampilNoAbsen.setBackgroundColor(Color.GREEN);
        TampilNoAbsen.setText(Noabsen.getText());
    }
}