package com.example.eksplorasifarrelapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText etEmail, etPassword;

    private CheckBox ShowPassword;

    private Button btnlogin;

    private String email = "farrel@gmail.com";

    private String password = "123";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnlogin = findViewById(R.id.btnlogin);
        ShowPassword = findViewById(R.id.ShowPassword);

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (etEmail.getText().toString().equalsIgnoreCase(email) &&
                        etPassword.getText().toString().equalsIgnoreCase(password)) {
                    Intent login = new Intent(MainActivity.this, DataSiswa.class);
                    startActivity(login);

                    Toast.makeText(MainActivity.this, "LOGIN BERHASIL", Toast.LENGTH_SHORT).show();
                }else {Toast.makeText(MainActivity.this, "Email atau password yang anda masukan salah", Toast.LENGTH_SHORT).show();
                }
            }
        });
        ShowPassword.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                etPassword.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            } else {
                etPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            }
            // Memperbarui tampilan EditText agar perubahan inputType diterapkan
            etPassword.setSelection(etPassword.getText().length());
        });
    }
}