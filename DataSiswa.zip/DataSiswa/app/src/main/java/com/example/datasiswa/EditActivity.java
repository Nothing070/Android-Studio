package com.example.datasiswa;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class EditActivity extends AppCompatActivity {

    Sql dbHelper;
    EditText nis, name, ttl, agama, kelamin, alamat;
    Button edit;
    String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        dbHelper = new Sql(this);
        nis = findViewById(R.id.nis);
        name = findViewById(R.id.name);
        ttl = findViewById(R.id.ttl);
        agama = findViewById(R.id.agama);
        kelamin = findViewById(R.id.kelamin);
        alamat = findViewById(R.id.alamat);
        edit = findViewById(R.id.edit);

        id = getIntent().getStringExtra("id");
        if (id != null) {
            loadData(id);
        }

        edit.setOnClickListener(v -> {
            if (validateInput()) {
                updateData();
            }
        });
    }

    private void loadData(String id) {
        Cursor cursor = dbHelper.getAllData();
        while (cursor.moveToNext()) {
            if (cursor.getString(0).equals(id)) {
                nis.setText(cursor.getString(1));
                name.setText(cursor.getString(2));
                ttl.setText(cursor.getString(3));
                agama.setText(cursor.getString(5));
                kelamin.setText(cursor.getString(6));
                alamat.setText(cursor.getString(7));
                break;
            }
        }
        cursor.close();
    }

    private boolean validateInput() {
        if (nis.getText().toString().trim().isEmpty() ||
                name.getText().toString().trim().isEmpty() ||
                ttl.getText().toString().trim().isEmpty() ||
                agama.getText().toString().trim().isEmpty() ||
                kelamin.getText().toString().trim().isEmpty() ||
                alamat.getText().toString().trim().isEmpty()) {

            Toast.makeText(this, "Semua kolom harus diisi!", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void updateData() {
        boolean isUpdated = dbHelper.updateData(
                id,
                nis.getText().toString(),
                name.getText().toString(),
                ttl.getText().toString(),
                "",
                agama.getText().toString(),
                kelamin.getText().toString(),
                alamat.getText().toString()
        );

        if (isUpdated) {
            Toast.makeText(this, "Data Berhasil Diperbarui !", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Gagal Memperbarui Data !", Toast.LENGTH_SHORT).show();
        }
    }
}
