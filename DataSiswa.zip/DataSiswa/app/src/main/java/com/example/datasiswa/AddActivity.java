package com.example.datasiswa;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddActivity extends AppCompatActivity {

    Sql dbHelper;
    EditText nis, name, ttl, agama, kelamin, alamat;
    Button simpan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        dbHelper = new Sql(this);
        nis = findViewById(R.id.nis);
        name = findViewById(R.id.name);
        ttl = findViewById(R.id.ttl);
        agama = findViewById(R.id.agama);
        kelamin = findViewById(R.id.kelamin);
        alamat = findViewById(R.id.alamat);
        simpan = findViewById(R.id.simpan);

        simpan.setOnClickListener(v -> {
            if (validateInput()) {
                saveData();
            }
        });
    }

    private boolean validateInput() {
        if (nis.getText().toString().trim().isEmpty() ||
                name.getText().toString().trim().isEmpty() ||
                ttl.getText().toString().trim().isEmpty() ||
                agama.getText().toString().trim().isEmpty() ||
                kelamin.getText().toString().trim().isEmpty() ||
                alamat.getText().toString().trim().isEmpty()) {

            Toast.makeText(this, "Semua kolom harus diisi!", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void saveData() {
        boolean isInserted = dbHelper.insertData(
                nis.getText().toString(),
                name.getText().toString(),
                ttl.getText().toString(),
                "",
                agama.getText().toString(),
                kelamin.getText().toString(),
                alamat.getText().toString()
        );

        if (isInserted) {
            Toast.makeText(this, "Data Berhasil Disimpan !", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Gagal Menyimpan Data !", Toast.LENGTH_SHORT).show();
        }
    }
}
