package com.example.datasiswa;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Sql dbHelper;
    ListView listView;
    ArrayAdapter<String> adapter;
    ArrayList<String> dataList;
    ArrayList<String> idList;
    FloatingActionButton fab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new Sql(this);
        listView = findViewById(R.id.ListView);
        fab = findViewById(R.id.fab);

        dataList = new ArrayList<>();
        idList = new ArrayList<>();

        // Menggunakan item_list.xml agar teks dalam ListView berwarna hitam
        adapter = new ArrayAdapter<>(this, R.layout.item_list, dataList);
        listView.setAdapter(adapter);

        loadData();

        fab.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddActivity.class);
            startActivity(intent);
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            String selectedId = idList.get(position);
            showOptionsDialog(selectedId);
        });
    }

    private void loadData() {
        dataList.clear();
        idList.clear();

        Cursor cursor = dbHelper.getAllData();
        if (cursor.getCount() == 0) {
            Toast.makeText(this, "Data masih kosong !", Toast.LENGTH_SHORT).show();
        } else {
            while (cursor.moveToNext()) {
                idList.add(cursor.getString(0)); // Simpan ID
                dataList.add(cursor.getString(2)); // Nama Siswa
            }
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }

    private void showOptionsDialog(String id) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Pilihan")
                .setItems(new String[]{"Edit", "Hapus"}, (dialog, which) -> {
                    if (which == 0) {
                        Intent intent = new Intent(MainActivity.this, EditActivity.class);
                        intent.putExtra("id", id);
                        startActivity(intent);
                    } else {
                        dbHelper.deleteData(id);
                        Toast.makeText(this, "Data berhasil dihapus", Toast.LENGTH_SHORT).show();
                        loadData();
                    }
                })
                .show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData();
    }
}
