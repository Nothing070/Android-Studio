package com.example.datasiswa;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Sql extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "db_siswa.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_SISWA = "siswa";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NIS = "nis";
    public static final String COLUMN_NAMA = "nama";
    public static final String COLUMN_TEMPAT_LAHIR = "tempat_lahir";
    public static final String COLUMN_TANGGAL_LAHIR = "tanggal_lahir";
    public static final String COLUMN_AGAMA = "agama";
    public static final String COLUMN_JENIS_KELAMIN = "jenis_kelamin";
    public static final String COLUMN_ALAMAT = "alamat";

    private static final String CREATE_TABLE_SISWA = "CREATE TABLE " + TABLE_SISWA + " ("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLUMN_NIS + " TEXT NOT NULL, "
            + COLUMN_NAMA + " TEXT NOT NULL, "
            + COLUMN_TEMPAT_LAHIR + " TEXT NOT NULL, "
            + COLUMN_TANGGAL_LAHIR + " TEXT NOT NULL, "
            + COLUMN_AGAMA + " TEXT NOT NULL, "
            + COLUMN_JENIS_KELAMIN + " TEXT NOT NULL, "
            + COLUMN_ALAMAT + " TEXT NOT NULL);";

    public Sql(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_SISWA);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SISWA);
        onCreate(db);
    }

    public boolean insertData(String nis, String nama, String tempatLahir, String tanggalLahir, String agama, String kelamin, String alamat) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NIS, nis);
        values.put(COLUMN_NAMA, nama);
        values.put(COLUMN_TEMPAT_LAHIR, tempatLahir);
        values.put(COLUMN_TANGGAL_LAHIR, tanggalLahir);
        values.put(COLUMN_AGAMA, agama);
        values.put(COLUMN_JENIS_KELAMIN, kelamin);
        values.put(COLUMN_ALAMAT, alamat);

        long result = db.insert(TABLE_SISWA, null, values);
        db.close();
        return result != -1;
    }

    public boolean updateData(String id, String nis, String nama, String tempatLahir, String tanggalLahir, String agama, String kelamin, String alamat) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NIS, nis);
        values.put(COLUMN_NAMA, nama);
        values.put(COLUMN_TEMPAT_LAHIR, tempatLahir);
        values.put(COLUMN_TANGGAL_LAHIR, tanggalLahir);
        values.put(COLUMN_AGAMA, agama);
        values.put(COLUMN_JENIS_KELAMIN, kelamin);
        values.put(COLUMN_ALAMAT, alamat);

        int result = db.update(TABLE_SISWA, values, COLUMN_ID + "=?", new String[]{id});
        db.close();
        return result > 0;
    }

    public boolean deleteData(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_SISWA, COLUMN_ID + "=?", new String[]{id});
        db.close();
        return result > 0;
    }

    public Cursor getAllData() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_SISWA, null);
    }
}
