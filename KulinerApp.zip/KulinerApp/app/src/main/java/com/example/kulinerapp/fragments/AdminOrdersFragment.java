package com.example.kulinerapp.fragments;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.R;
import com.example.kulinerapp.adapters.AdminOrderAdapter;
import com.example.kulinerapp.database.DatabaseHelper;
import com.example.kulinerapp.models.Order;

import java.util.ArrayList;
import java.util.List;

public class AdminOrdersFragment extends Fragment {

    private RecyclerView rvAdminOrders;
    private LinearLayout emptyOrderView;

    private AdminOrderAdapter adminOrderAdapter;
    private DatabaseHelper db;
    private List<Order> orders;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_admin_orders, container, false);

        // Initialize
        db = new DatabaseHelper(getActivity());

        // Find views
        rvAdminOrders = view.findViewById(R.id.rvAdminOrders);
        emptyOrderView = view.findViewById(R.id.emptyOrderView);

        // Setup RecyclerView
        setupOrdersRecyclerView();

        // Load orders
        loadOrders();

        return view;
    }

    private void setupOrdersRecyclerView() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        rvAdminOrders.setLayoutManager(layoutManager);

        orders = new ArrayList<>();
        adminOrderAdapter = new AdminOrderAdapter(getActivity(), orders,
                new AdminOrderAdapter.OnAdminOrderActionListener() {
                    @Override
                    public void onUpdateStatus(Order order) {
                        showStatusDialog(order);
                    }

                    @Override
                    public void onViewDetails(Order order) {
                        Toast.makeText(getActivity(), "Detail Order #" + order.getId(),
                                Toast.LENGTH_SHORT).show();
                    }
                });
        rvAdminOrders.setAdapter(adminOrderAdapter);
    }

    private void loadOrders() {
        orders.clear();
        orders.addAll(db.getAllOrders());

        if (orders.isEmpty()) {
            emptyOrderView.setVisibility(View.VISIBLE);
            rvAdminOrders.setVisibility(View.GONE);
        } else {
            emptyOrderView.setVisibility(View.GONE);
            rvAdminOrders.setVisibility(View.VISIBLE);
        }

        adminOrderAdapter.notifyDataSetChanged();
    }

    private void showStatusDialog(Order order) {
        String[] statuses = {"Pending", "Processing", "Completed", "Cancelled"};

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Update Status Pesanan");
        builder.setItems(statuses, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String newStatus = statuses[which];
                db.updateOrderStatus(order.getId(), newStatus);
                Toast.makeText(getActivity(), "Status diubah menjadi " + newStatus,
                        Toast.LENGTH_SHORT).show();
                loadOrders();
            }
        });
        builder.show();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadOrders();
    }
}