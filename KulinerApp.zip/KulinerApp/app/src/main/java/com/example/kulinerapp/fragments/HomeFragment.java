package com.example.kulinerapp.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.MainActivity;
import com.example.kulinerapp.R;
import com.example.kulinerapp.adapters.CategoryAdapter;
import com.example.kulinerapp.adapters.DiscountAdapter;
import com.example.kulinerapp.adapters.MenuAdapter;
import com.example.kulinerapp.database.DatabaseHelper;
import com.example.kulinerapp.models.MenuItem;
import com.example.kulinerapp.utils.SessionManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class HomeFragment extends Fragment {

    private TextView tvUsername, tvSeeAllMenu;
    private ImageView ivNotification;
    private LinearLayout searchBarContainer;
    private RecyclerView rvDiscount, rvCategories, rvMenuItems;

    private MenuAdapter menuAdapter;
    private DiscountAdapter discountAdapter;
    private CategoryAdapter categoryAdapter;

    private DatabaseHelper db;
    private SessionManager sessionManager;
    private List<MenuItem> menuItems;
    private List<MenuItem> discountItems;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Initialize
        db = new DatabaseHelper(getActivity());
        sessionManager = new SessionManager(getActivity());

        // Find views
        tvUsername = view.findViewById(R.id.tvUsername);
        tvSeeAllMenu = view.findViewById(R.id.tvSeeAllMenu);
        ivNotification = view.findViewById(R.id.ivNotification);
        searchBarContainer = view.findViewById(R.id.searchBarContainer);
        rvDiscount = view.findViewById(R.id.rvDiscount);
        rvCategories = view.findViewById(R.id.rvCategories);
        rvMenuItems = view.findViewById(R.id.rvMenuItems);

        // Set username
        tvUsername.setText(sessionManager.getUserName());

        // Setup RecyclerViews
        setupDiscountRecyclerView();
        setupCategoriesRecyclerView();
        setupMenuItemsRecyclerView();

        // Load data
        loadDiscountItems();
        loadMenuItems();

        // Set click listeners
        searchBarContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to search fragment
                ((MainActivity) getActivity()).findViewById(R.id.bottomNavigationView);
                ((com.google.android.material.bottomnavigation.BottomNavigationView)
                        ((MainActivity) getActivity()).findViewById(R.id.bottomNavigationView))
                        .setSelectedItemId(R.id.nav_search);
            }
        });

        ivNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Animation bounce = AnimationUtils.loadAnimation(getActivity(), R.anim.bounce);
                ivNotification.startAnimation(bounce);
                Toast.makeText(getActivity(), "Tidak ada notifikasi baru", Toast.LENGTH_SHORT).show();
            }
        });

        tvSeeAllMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((com.google.android.material.bottomnavigation.BottomNavigationView)
                        ((MainActivity) getActivity()).findViewById(R.id.bottomNavigationView))
                        .setSelectedItemId(R.id.nav_search);
            }
        });

        return view;
    }

    private void setupDiscountRecyclerView() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(),
                LinearLayoutManager.HORIZONTAL, false);
        rvDiscount.setLayoutManager(layoutManager);

        discountItems = new ArrayList<>();
        discountAdapter = new DiscountAdapter(getActivity(), discountItems, new DiscountAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(MenuItem item) {
                // Handle discount item click
                Toast.makeText(getActivity(), "Promo: " + item.getName(), Toast.LENGTH_SHORT).show();
            }
        });
        rvDiscount.setAdapter(discountAdapter);
    }

    private void setupCategoriesRecyclerView() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(),
                LinearLayoutManager.HORIZONTAL, false);
        rvCategories.setLayoutManager(layoutManager);

        List<String> categories = Arrays.asList(
                "Makanan Berat", "Makanan Ringan", "Minuman", "Dessert"
        );
        List<String> categoryIcons = Arrays.asList("🍜", "🍕", "🥤", "🍰");

        categoryAdapter = new CategoryAdapter(getActivity(), categories, categoryIcons,
                new CategoryAdapter.OnCategoryClickListener() {
                    @Override
                    public void onCategoryClick(String category) {
                        filterByCategory(category);
                    }
                });
        rvCategories.setAdapter(categoryAdapter);
    }

    private void setupMenuItemsRecyclerView() {
        GridLayoutManager layoutManager = new GridLayoutManager(getActivity(), 1);
        rvMenuItems.setLayoutManager(layoutManager);

        menuItems = new ArrayList<>();
        menuAdapter = new MenuAdapter(getActivity(), menuItems, new MenuAdapter.OnItemActionListener() {
            @Override
            public void onAddToCart(MenuItem item) {
                addToCart(item);
            }

            @Override
            public void onFavoriteClick(MenuItem item, boolean isFavorite) {
                toggleFavorite(item, isFavorite);
            }

            @Override
            public void onItemClick(MenuItem item) {
                Toast.makeText(getActivity(), item.getName(), Toast.LENGTH_SHORT).show();
            }
        });
        rvMenuItems.setAdapter(menuAdapter);
    }

    private void loadDiscountItems() {
        discountItems.clear();
        discountItems.addAll(db.getDiscountedItems());
        discountAdapter.notifyDataSetChanged();
    }

    private void loadMenuItems() {
        menuItems.clear();
        menuItems.addAll(db.getAllMenuItems());
        menuAdapter.notifyDataSetChanged();
    }

    private void filterByCategory(String category) {
        menuItems.clear();
        menuItems.addAll(db.getMenuItemsByCategory(category));
        menuAdapter.notifyDataSetChanged();

        // Scroll to menu items section
        rvMenuItems.smoothScrollToPosition(0);
        Toast.makeText(getActivity(), "Menampilkan: " + category, Toast.LENGTH_SHORT).show();
    }

    private void addToCart(MenuItem item) {
        com.example.kulinerapp.models.CartItem cartItem = new com.example.kulinerapp.models.CartItem(
                sessionManager.getUserId(),
                item.getId(),
                item.getName(),
                item.getFinalPrice(),
                item.getImagePath(),
                1,
                ""
        );

        long result = db.addToCart(cartItem);

        if (result > 0) {
            Animation bounce = AnimationUtils.loadAnimation(getActivity(), R.anim.bounce);
            Toast.makeText(getActivity(), item.getName() + " ditambahkan ke keranjang",
                    Toast.LENGTH_SHORT).show();

            // Update cart badge
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).updateCartBadge();
            }
        } else {
            Toast.makeText(getActivity(), "Gagal menambahkan ke keranjang",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleFavorite(MenuItem item, boolean isFavorite) {
        int userId = sessionManager.getUserId();
        int menuId = item.getId();

        if (isFavorite) {
            // Hapus dari favorit
            db.removeFavorite(userId, menuId);
            Toast.makeText(getActivity(), "Dihapus dari favorit", Toast.LENGTH_SHORT).show();
        } else {
            // Tambah ke favorit
            db.addFavorite(userId, menuId);
            Toast.makeText(getActivity(), "Ditambahkan ke favorit", Toast.LENGTH_SHORT).show();
        }
        loadMenuItems();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadMenuItems();
        loadDiscountItems();
    }
}