package com.example.kulinerapp.fragments;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.MainActivity;
import com.example.kulinerapp.R;
import com.example.kulinerapp.adapters.CartAdapter;
import com.example.kulinerapp.database.DatabaseHelper;
import com.example.kulinerapp.models.CartItem;
import com.example.kulinerapp.models.Order;
import com.example.kulinerapp.models.OrderDetail;
import com.example.kulinerapp.utils.FormatHelper;
import com.example.kulinerapp.utils.SessionManager;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.List;

public class CartFragment extends Fragment {

    private RecyclerView rvCartItems;
    private TextView tvCartItemCount, tvSubtotal, tvDiscount, tvDeliveryFee, tvTotal;
    private Button btnCheckout, btnStartShopping;
    private View emptyCartView, checkoutSection; // FIX: Ganti LinearLayout → View

    private CartAdapter cartAdapter;
    private DatabaseHelper db;
    private SessionManager sessionManager;
    private List<CartItem> cartItems = new ArrayList<>();

    private static final double DELIVERY_FEE = 10000;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_cart, container, false);

        rvCartItems = view.findViewById(R.id.rvCartItems);
        tvCartItemCount = view.findViewById(R.id.tvCartItemCount);
        tvSubtotal = view.findViewById(R.id.tvSubtotal);
        tvDiscount = view.findViewById(R.id.tvDiscount);
        tvDeliveryFee = view.findViewById(R.id.tvDeliveryFee);
        tvTotal = view.findViewById(R.id.tvTotal);
        btnCheckout = view.findViewById(R.id.btnCheckout);
        btnStartShopping = view.findViewById(R.id.btnStartShopping);
        emptyCartView = view.findViewById(R.id.emptyCartView);        // FIX: Bukan LinearLayout
        checkoutSection = view.findViewById(R.id.checkoutSection);    // FIX: Bukan LinearLayout

        setupRecyclerView();
        tvDeliveryFee.setText(FormatHelper.formatRupiah(DELIVERY_FEE));

        btnCheckout.setOnClickListener(v -> showCheckoutDialog());
        btnStartShopping.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).getBottomNav().setSelectedItemId(R.id.nav_home);
            }
        });

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        db = new DatabaseHelper(requireContext());
        sessionManager = new SessionManager(requireContext());
        loadCartItems();
    }

    private void setupRecyclerView() {
        rvCartItems.setLayoutManager(new LinearLayoutManager(requireContext()));
        cartAdapter = new CartAdapter(requireContext(), cartItems, new CartAdapter.OnCartActionListener() {
            @Override
            public void onQuantityChanged(CartItem item, int newQuantity) {
                if (newQuantity <= 0) {
                    deleteCartItem(item);
                } else {
                    db.updateCartItemQuantity(item.getId(), newQuantity);
                }
                loadCartItems();
            }

            @Override
            public void onDeleteItem(CartItem item) {
                deleteCartItem(item);
            }

            @Override
            public void onNotesChanged(CartItem item, String notes) {
                db.updateCartItemNotes(item.getId(), notes); // Tambahkan method ini di DatabaseHelper kalau belum ada
            }
        });
        rvCartItems.setAdapter(cartAdapter);
    }

    private void loadCartItems() {
        cartItems.clear();
        cartItems.addAll(db.getCartItems(sessionManager.getUserId()));
        cartAdapter.notifyDataSetChanged();

        if (cartItems.isEmpty()) {
            emptyCartView.setVisibility(View.VISIBLE);
            rvCartItems.setVisibility(View.GONE);
            checkoutSection.setVisibility(View.GONE);
            tvCartItemCount.setText(getString(R.string.empty_cart));
        } else {
            emptyCartView.setVisibility(View.GONE);
            rvCartItems.setVisibility(View.VISIBLE);
            checkoutSection.setVisibility(View.VISIBLE);
            tvCartItemCount.setText(cartItems.size() + " item");
        }
        updateSummary();
        updateBadge();
    }

    private void updateSummary() {
        double subtotal = cartItems.stream().mapToDouble(CartItem::getSubtotal).sum();
        double total = subtotal + DELIVERY_FEE;
        tvSubtotal.setText(FormatHelper.formatRupiah(subtotal));
        tvDiscount.setText("- " + FormatHelper.formatRupiah(0));
        tvTotal.setText(FormatHelper.formatRupiah(total));
    }

    private void deleteCartItem(CartItem item) {
        db.deleteCartItem(item.getId());
        Toast.makeText(requireContext(), "Item dihapus dari keranjang", Toast.LENGTH_SHORT).show();
        loadCartItems();
    }

    private void updateBadge() {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).updateCartBadge();
        }
    }

    private void showCheckoutDialog() {
        Dialog d = new Dialog(requireActivity());
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setContentView(R.layout.dialog_checkout);
        d.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        TextInputEditText etAddress = d.findViewById(R.id.etDeliveryAddress);
        RadioGroup rgPayment = d.findViewById(R.id.rgPaymentMethod);
        TextView tvTotal = d.findViewById(R.id.tvCheckoutTotal);
        Button btnCancel = d.findViewById(R.id.btnCancelCheckout);
        Button btnConfirm = d.findViewById(R.id.btnConfirmCheckout);

        double total = cartItems.stream().mapToDouble(CartItem::getSubtotal).sum() + DELIVERY_FEE;
        tvTotal.setText(FormatHelper.formatRupiah(total));

        btnCancel.setOnClickListener(v -> d.dismiss());
        btnConfirm.setOnClickListener(v -> {
            String address = etAddress.getText() != null ? etAddress.getText().toString().trim() : "";
            if (address.isEmpty()) {
                etAddress.setError("Alamat wajib diisi");
                return;
            }
            if (rgPayment.getCheckedRadioButtonId() == -1) {
                Toast.makeText(requireContext(), "Pilih metode pembayaran", Toast.LENGTH_SHORT).show();
                return;
            }
            RadioButton selected = d.findViewById(rgPayment.getCheckedRadioButtonId());
            String payment = selected != null ? selected.getText().toString() : "Tunai";

            processCheckout(address, payment, total);
            d.dismiss();
        });
        d.show();
    }

    private void processCheckout(String address, String payment, double total) {
        Order order = new Order(
                sessionManager.getUserId(),
                FormatHelper.getCurrentDateTime(),
                total,
                "Pending",
                address,
                payment
        );
        long orderId = db.addOrder(order);
        if (orderId > 0) {
            for (CartItem i : cartItems) {
                db.addOrderDetail(new OrderDetail(
                        (int) orderId,
                        i.getMenuItemId(),
                        i.getMenuName(),
                        i.getQuantity(),
                        i.getMenuPrice()
                ));
            }
            db.clearCart(sessionManager.getUserId());
            Toast.makeText(requireContext(), getString(R.string.success), Toast.LENGTH_LONG).show();
            loadCartItems();
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).getBottomNav().setSelectedItemId(R.id.nav_profile);
            }
        } else {
            Toast.makeText(requireContext(), "Gagal membuat pesanan", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        loadCartItems(); // Update saat kembali ke fragment
    }
}