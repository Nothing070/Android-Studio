package com.example.kulinerapp.fragments;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.MainActivity;
import com.example.kulinerapp.R;
import com.example.kulinerapp.adapters.CartAdapter;
import com.example.kulinerapp.database.DatabaseHelper;
import com.example.kulinerapp.models.CartItem;
import com.example.kulinerapp.models.Order;
import com.example.kulinerapp.models.OrderDetail;
import com.example.kulinerapp.utils.FormatHelper;
import com.example.kulinerapp.utils.SessionManager;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.List;

public class CartFragment extends Fragment {

    private RecyclerView rvCartItems;
    private TextView tvCartItemCount, tvSubtotal, tvDiscount, tvDeliveryFee, tvTotal;
    private Button btnCheckout, btnStartShopping;
    private LinearLayout emptyCartView, checkoutSection;

    private CartAdapter cartAdapter;
    private DatabaseHelper db;
    private SessionManager sessionManager;
    private List<CartItem> cartItems;

    private static final double DELIVERY_FEE = 10000;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_cart, container, false);

        // Initialize
        db = new DatabaseHelper(getActivity());
        sessionManager = new SessionManager(getActivity());

        // Find views
        rvCartItems = view.findViewById(R.id.rvCartItems);
        tvCartItemCount = view.findViewById(R.id.tvCartItemCount);
        tvSubtotal = view.findViewById(R.id.tvSubtotal);
        tvDiscount = view.findViewById(R.id.tvDiscount);
        tvDeliveryFee = view.findViewById(R.id.tvDeliveryFee);
        tvTotal = view.findViewById(R.id.tvTotal);
        btnCheckout = view.findViewById(R.id.btnCheckout);
        btnStartShopping = view.findViewById(R.id.btnStartShopping);
        emptyCartView = view.findViewById(R.id.emptyCartView);
        checkoutSection = view.findViewById(R.id.checkoutSection);

        // Setup RecyclerView
        setupCartRecyclerView();

        // Load cart items
        loadCartItems();

        // Set delivery fee
        tvDeliveryFee.setText(FormatHelper.formatCurrency(DELIVERY_FEE));

        // Set listeners
        btnCheckout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCheckoutDialog();
            }
        });

        btnStartShopping.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((com.google.android.material.bottomnavigation.BottomNavigationView)
                        ((MainActivity) getActivity()).findViewById(R.id.bottomNavigationView))
                        .setSelectedItemId(R.id.nav_home);
            }
        });

        return view;
    }

    private void setupCartRecyclerView() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        rvCartItems.setLayoutManager(layoutManager);

        cartItems = new ArrayList<>();
        cartAdapter = new CartAdapter(getActivity(), cartItems, new CartAdapter.OnCartActionListener() {
            @Override
            public void onQuantityChanged(CartItem item, int newQuantity) {
                updateCartItemQuantity(item, newQuantity);
            }

            @Override
            public void onDeleteItem(CartItem item) {
                deleteCartItem(item);
            }

            @Override
            public void onNotesChanged(CartItem item, String notes) {
                // Notes are handled in adapter
            }
        });
        rvCartItems.setAdapter(cartAdapter);
    }

    private void loadCartItems() {
        cartItems.clear();
        cartItems.addAll(db.getCartItems(sessionManager.getUserId()));

        if (cartItems.isEmpty()) {
            showEmptyCart();
        } else {
            showCartItems();
        }

        updateCartSummary();
        cartAdapter.notifyDataSetChanged();
    }

    private void showEmptyCart() {
        emptyCartView.setVisibility(View.VISIBLE);
        rvCartItems.setVisibility(View.GONE);
        checkoutSection.setVisibility(View.GONE);
        tvCartItemCount.setText("0 item");
    }

    private void showCartItems() {
        emptyCartView.setVisibility(View.GONE);
        rvCartItems.setVisibility(View.VISIBLE);
        checkoutSection.setVisibility(View.VISIBLE);
        tvCartItemCount.setText(cartItems.size() + " item");
    }

    private void updateCartSummary() {
        double subtotal = 0;
        for (CartItem item : cartItems) {
            subtotal += item.getSubtotal();
        }

        double discount = 0; // You can calculate discount based on vouchers
        double total = subtotal - discount + DELIVERY_FEE;

        tvSubtotal.setText(FormatHelper.formatCurrency(subtotal));
        tvDiscount.setText("- " + FormatHelper.formatCurrency(discount));
        tvTotal.setText(FormatHelper.formatCurrency(total));
    }

    private void updateCartItemQuantity(CartItem item, int newQuantity) {
        if (newQuantity <= 0) {
            deleteCartItem(item);
            return;
        }

        db.updateCartItemQuantity(item.getId(), newQuantity);
        loadCartItems();
        updateMainActivityBadge();
    }

    private void deleteCartItem(CartItem item) {
        db.deleteCartItem(item.getId());
        Toast.makeText(getActivity(), "Item dihapus dari keranjang", Toast.LENGTH_SHORT).show();
        loadCartItems();
        updateMainActivityBadge();
    }

    private void showCheckoutDialog() {
        Dialog dialog = new Dialog(getActivity());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_checkout);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        TextInputEditText etDeliveryAddress = dialog.findViewById(R.id.etDeliveryAddress);
        RadioGroup rgPaymentMethod = dialog.findViewById(R.id.rgPaymentMethod);
        TextView tvCheckoutTotal = dialog.findViewById(R.id.tvCheckoutTotal);
        Button btnCancelCheckout = dialog.findViewById(R.id.btnCancelCheckout);
        Button btnConfirmCheckout = dialog.findViewById(R.id.btnConfirmCheckout);

        // Set total
        double subtotal = 0;
        for (CartItem item : cartItems) {
            subtotal += item.getSubtotal();
        }
        double total = subtotal + DELIVERY_FEE;
        tvCheckoutTotal.setText(FormatHelper.formatCurrency(total));

        btnCancelCheckout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        btnConfirmCheckout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String address = etDeliveryAddress.getText().toString().trim();

                if (address.isEmpty()) {
                    etDeliveryAddress.setError("Alamat harus diisi");
                    etDeliveryAddress.requestFocus();
                    return;
                }

                // Get payment method
                int selectedPaymentId = rgPaymentMethod.getCheckedRadioButtonId();
                RadioButton selectedPayment = dialog.findViewById(selectedPaymentId);
                String paymentMethod = selectedPayment.getText().toString();

                // Process checkout
                processCheckout(address, paymentMethod, total);
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void processCheckout(String address, String paymentMethod, double total) {
        // Create order
        Order order = new Order(
                sessionManager.getUserId(),
                FormatHelper.getCurrentDateTime(),
                total,
                "Pending",
                address,
                paymentMethod
        );

        long orderId = db.addOrder(order);

        if (orderId > 0) {
            // Add order details
            for (CartItem item : cartItems) {
                OrderDetail detail = new OrderDetail(
                        (int) orderId,
                        item.getMenuItemId(),
                        item.getMenuName(),
                        item.getQuantity(),
                        item.getMenuPrice()
                );
                db.addOrderDetail(detail);
            }

            // Clear cart
            db.clearCart(sessionManager.getUserId());

            // Show success message
            Toast.makeText(getActivity(), "Pesanan berhasil dibuat!", Toast.LENGTH_LONG).show();

            // Reload cart
            loadCartItems();
            updateMainActivityBadge();

            // Navigate to profile/order history
            ((com.google.android.material.bottomnavigation.BottomNavigationView)
                    ((MainActivity) getActivity()).findViewById(R.id.bottomNavigationView))
                    .setSelectedItemId(R.id.nav_profile);
        } else {
            Toast.makeText(getActivity(), "Gagal membuat pesanan", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateMainActivityBadge() {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).updateCartBadge();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        loadCartItems();
    }
}