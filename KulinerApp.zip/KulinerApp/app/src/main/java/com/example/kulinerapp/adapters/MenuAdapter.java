package com.example.kulinerapp.adapters;

import android.content.Context;
import android.graphics.Paint;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.R;
import com.example.kulinerapp.database.DatabaseHelper;
import com.example.kulinerapp.models.MenuItem;
import com.example.kulinerapp.utils.FormatHelper;
import com.example.kulinerapp.utils.SessionManager;

import java.io.File;
import java.util.List;

public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.MenuViewHolder> {

    private Context context;
    private List<MenuItem> menuItems;
    private OnItemActionListener listener;
    private DatabaseHelper db;
    private SessionManager sessionManager;

    public interface OnItemActionListener {
        void onAddToCart(MenuItem item);
        void onFavoriteClick(MenuItem item, boolean isFavorite);
        void onItemClick(MenuItem item);
    }

    public MenuAdapter(Context context, List<MenuItem> menuItems, OnItemActionListener listener) {
        this.context = context;
        this.menuItems = menuItems;
        this.listener = listener;
        this.db = new DatabaseHelper(context);
        this.sessionManager = new SessionManager(context);
    }

    @NonNull
    @Override
    public MenuViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_menu, parent, false);
        return new MenuViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MenuViewHolder holder, int position) {
        MenuItem item = menuItems.get(position);

        holder.tvMenuName.setText(item.getName());
        holder.tvMenuDescription.setText(item.getDescription());
        holder.tvRating.setText(FormatHelper.formatRating(item.getRating()));

        holder.tvPrice.setText(FormatHelper.formatRupiah(item.getFinalPrice()));

        // Handle discount
        if (item.getDiscount() > 0) {
            holder.tvDiscount.setVisibility(View.VISIBLE);
            holder.tvDiscount.setText(FormatHelper.formatDiscount(item.getDiscount()));
            holder.tvOriginalPrice.setVisibility(View.VISIBLE);
            holder.tvOriginalPrice.setText(FormatHelper.formatRupiah(item.getPrice()));
            holder.tvOriginalPrice.setPaintFlags(holder.tvOriginalPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        } else {
            holder.tvDiscount.setVisibility(View.GONE);
            holder.tvOriginalPrice.setVisibility(View.GONE);
        }

        // Gambar menu dari internal storage (sesuai Add/Edit Menu premium)
        int imageId = item.getImageResource();
        if (imageId != 0) {
            File imgFile = new File(context.getFilesDir(), "menu_" + imageId + ".jpg");
            if (imgFile.exists()) {
                holder.ivMenuItem.setImageURI(Uri.fromFile(imgFile));
            } else {
                holder.ivMenuItem.setImageResource(R.drawable.ic_add_photo_big);
            }
        } else {
            holder.ivMenuItem.setImageResource(R.drawable.ic_add_photo_big);
        }

        // Favorite
        boolean isFavorite = db.isFavorite(sessionManager.getUserId(), item.getId());
        holder.ivFavorite.setImageResource(isFavorite ? R.drawable.ic_favorite : R.drawable.ic_favorite_border);

        // Click listeners
        holder.btnAddToCart.setOnClickListener(v -> {
            Animation bounce = AnimationUtils.loadAnimation(context, R.anim.bounce);
            v.startAnimation(bounce);
            listener.onAddToCart(item);
        });

        holder.ivFavorite.setOnClickListener(v -> {
            Animation bounce = AnimationUtils.loadAnimation(context, R.anim.bounce);
            v.startAnimation(bounce);
            listener.onFavoriteClick(item, !isFavorite);
        });

        holder.itemView.setOnClickListener(v -> listener.onItemClick(item));

        // Animasi masuk
        Animation slideIn = AnimationUtils.loadAnimation(context, R.anim.slide_in_right);
        holder.itemView.startAnimation(slideIn);
    }

    @Override
    public int getItemCount() {
        return menuItems.size();
    }

    static class MenuViewHolder extends RecyclerView.ViewHolder {
        ImageView ivMenuItem, ivFavorite;
        TextView tvMenuName, tvMenuDescription, tvRating, tvPrice, tvOriginalPrice, tvDiscount;
        Button btnAddToCart;

        public MenuViewHolder(@NonNull View itemView) {
            super(itemView);
            ivMenuItem = itemView.findViewById(R.id.ivMenuItem);
            ivFavorite = itemView.findViewById(R.id.ivFavorite);
            tvMenuName = itemView.findViewById(R.id.tvMenuName);
            tvMenuDescription = itemView.findViewById(R.id.tvMenuDescription);
            tvRating = itemView.findViewById(R.id.tvRating);
            tvPrice = itemView.findViewById(R.id.tvPrice);
            tvOriginalPrice = itemView.findViewById(R.id.tvOriginalPrice);
            tvDiscount = itemView.findViewById(R.id.tvDiscount);
            btnAddToCart = itemView.findViewById(R.id.btnAddToCart);
        }
    }
}