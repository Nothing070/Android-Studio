package com.example.kulinerapp.models;

import android.os.Parcel;
import android.os.Parcelable;

public class MenuItem implements Parcelable {

    private int id;
    private String name;
    private String description;
    private double price;
    private String category;
    private String imagePath;
    private float rating;
    private int discount;
    private boolean isAvailable;

    // Constructor kosong
    public MenuItem() {}

    // Constructor tanpa ID (untuk addMenuItem)
    public MenuItem(String name, String description, double price, String category,
                    String imagePath, float rating, int discount, boolean isAvailable) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.category = category;
        this.imagePath = imagePath;
        this.rating = rating;
        this.discount = discount;
        this.isAvailable = isAvailable;
    }

    // Constructor dengan ID (dari database)
    public MenuItem(int id, String name, String description, double price, String category,
                    String imagePath, float rating, int discount, boolean isAvailable) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price = price;
        this.category = category;
        this.imagePath = imagePath;
        this.rating = rating;
        this.discount = discount;
        this.isAvailable = isAvailable;
    }

    // Parcelable
    protected MenuItem(Parcel in) {
        id = in.readInt();
        name = in.readString();
        description = in.readString();
        price = in.readDouble();
        category = in.readString();
        imagePath = in.readString();
        rating = in.readFloat();
        discount = in.readInt();
        isAvailable = in.readByte() != 0;
    }

    public static final Creator<MenuItem> CREATOR = new Creator<MenuItem>() {
        @Override
        public MenuItem createFromParcel(Parcel in) {
            return new MenuItem(in);
        }

        @Override
        public MenuItem[] newArray(int size) {
            return new MenuItem[size];
        }
    };

    @Override
    public int describeContents() { return 0; }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(name);
        dest.writeString(description);
        dest.writeDouble(price);
        dest.writeString(category);
        dest.writeString(imagePath);
        dest.writeFloat(rating);
        dest.writeInt(discount);
        dest.writeByte((byte) (isAvailable ? 1 : 0));
    }

    // ==================== GETTER & SETTER ====================
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getImagePath() { return imagePath; }
    public void setImagePath(String imagePath) { this.imagePath = imagePath; }

    public float getRating() { return rating; }
    public void setRating(float rating) { this.rating = rating; }

    public int getDiscount() { return discount; }
    public void setDiscount(int discount) { this.discount = discount; }

    public boolean isAvailable() { return isAvailable; }
    public void setAvailable(boolean available) { isAvailable = available; }

    // Harga setelah diskon
    public double getFinalPrice() {
        if (discount > 0) {
            return price - (price * discount / 100.0);
        }
        return price;
    }
}