package com.example.kulinerapp.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.MainActivity;
import com.example.kulinerapp.R;
import com.example.kulinerapp.adapters.MenuAdapter;
import com.example.kulinerapp.database.DatabaseHelper;
import com.example.kulinerapp.models.CartItem;
import com.example.kulinerapp.models.MenuItem;
import com.example.kulinerapp.utils.LocaleHelper;
import com.example.kulinerapp.utils.SessionManager;

import java.util.ArrayList;
import java.util.List;

public class FavoritesActivity extends AppCompatActivity {

    private ImageView ivBack;
    private RecyclerView rvFavorites;
    private LinearLayout emptyFavoriteView;
    private Button btnBrowseMenu;

    private MenuAdapter menuAdapter;
    private DatabaseHelper db;
    private SessionManager sessionManager;
    private List<MenuItem> favoriteItems;

    @Override
    protected void attachBaseContext(Context newBase) {
        SessionManager sessionManager = new SessionManager(newBase);
        String savedLanguage = sessionManager.getLanguage();
        super.attachBaseContext(LocaleHelper.setLocale(newBase, savedLanguage));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);

        // Initialize
        db = new DatabaseHelper(this);
        sessionManager = new SessionManager(this);

        // Find views
        ivBack = findViewById(R.id.ivBack);
        rvFavorites = findViewById(R.id.rvFavorites);
        emptyFavoriteView = findViewById(R.id.emptyFavoriteView);
        btnBrowseMenu = findViewById(R.id.btnBrowseMenu);

        // Handle back press
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                finish();
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            }
        });

        // Setup RecyclerView
        setupFavoritesRecyclerView();

        // Load favorites
        loadFavorites();

        // Set click listeners
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            }
        });

        btnBrowseMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FavoritesActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void setupFavoritesRecyclerView() {
        GridLayoutManager layoutManager = new GridLayoutManager(this, 1);
        rvFavorites.setLayoutManager(layoutManager);

        favoriteItems = new ArrayList<>();
        menuAdapter = new MenuAdapter(this, favoriteItems, new MenuAdapter.OnItemActionListener() {
            @Override
            public void onAddToCart(MenuItem item) {
                addToCart(item);
            }

            @Override
            public void onFavoriteClick(MenuItem item, boolean isFavorite) {
                toggleFavorite(item);
            }

            @Override
            public void onItemClick(MenuItem item) {
                Toast.makeText(FavoritesActivity.this, item.getName(), Toast.LENGTH_SHORT).show();
            }
        });
        rvFavorites.setAdapter(menuAdapter);
    }

    private void loadFavorites() {
        favoriteItems.clear();
        favoriteItems.addAll(db.getFavoriteMenuItems(sessionManager.getUserId()));

        if (favoriteItems.isEmpty()) {
            emptyFavoriteView.setVisibility(View.VISIBLE);
            rvFavorites.setVisibility(View.GONE);
        } else {
            emptyFavoriteView.setVisibility(View.GONE);
            rvFavorites.setVisibility(View.VISIBLE);
        }

        menuAdapter.notifyDataSetChanged();
    }

    private void addToCart(MenuItem item) {
        CartItem cartItem = new CartItem(
                sessionManager.getUserId(),
                item.getId(),
                item.getName(),
                item.getFinalPrice(),
                item.getImageResource(),
                1,
                ""
        );

        long result = db.addToCart(cartItem);

        if (result > 0) {
            Toast.makeText(this, item.getName() + " ditambahkan ke keranjang",
                    Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Gagal menambahkan ke keranjang",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleFavorite(MenuItem item) {
        db.removeFavorite(sessionManager.getUserId(), item.getId());
        Toast.makeText(this, "Dihapus dari favorit", Toast.LENGTH_SHORT).show();
        loadFavorites();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadFavorites();
    }
}