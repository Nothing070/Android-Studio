package com.example.kulinerapp.models;

import android.os.Parcel;
import android.os.Parcelable;

public class CartItem implements Parcelable {
    private int id;
    private int userId;
    private int menuItemId;
    private String menuName;
    private double menuPrice;
    private String menuImagePath;  // DIUBAH DARI int → String
    private int quantity;
    private String notes;

    public CartItem() {
    }

    // Constructor dengan ID (dari database)
    public CartItem(int id, int userId, int menuItemId, String menuName,
                    double menuPrice, String menuImagePath, int quantity, String notes) {
        this.id = id;
        this.userId = userId;
        this.menuItemId = menuItemId;
        this.menuName = menuName;
        this.menuPrice = menuPrice;
        this.menuImagePath = menuImagePath;
        this.quantity = quantity;
        this.notes = notes != null ? notes : "";
    }

    // Constructor tanpa ID (untuk addToCart)
    public CartItem(int userId, int menuItemId, String menuName,
                    double menuPrice, String menuImagePath, int quantity, String notes) {
        this.userId = userId;
        this.menuItemId = menuItemId;
        this.menuName = menuName;
        this.menuPrice = menuPrice;
        this.menuImagePath = menuImagePath;
        this.quantity = quantity;
        this.notes = notes != null ? notes : "";
    }

    // Parcelable
    protected CartItem(Parcel in) {
        id = in.readInt();
        userId = in.readInt();
        menuItemId = in.readInt();
        menuName = in.readString();
        menuPrice = in.readDouble();
        menuImagePath = in.readString();
        quantity = in.readInt();
        notes = in.readString();
    }

    public static final Creator<CartItem> CREATOR = new Creator<CartItem>() {
        @Override
        public CartItem createFromParcel(Parcel in) {
            return new CartItem(in);
        }

        @Override
        public CartItem[] newArray(int size) {
            return new CartItem[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeInt(userId);
        dest.writeInt(menuItemId);
        dest.writeString(menuName);
        dest.writeDouble(menuPrice);
        dest.writeString(menuImagePath);
        dest.writeInt(quantity);
        dest.writeString(notes);
    }

    // ==================== GETTER & SETTER ====================
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public int getMenuItemId() { return menuItemId; }
    public void setMenuItemId(int menuItemId) { this.menuItemId = menuItemId; }

    public String getMenuName() { return menuName; }
    public void setMenuName(String menuName) { this.menuName = menuName; }

    public double getMenuPrice() { return menuPrice; }
    public void setMenuPrice(double menuPrice) { this.menuPrice = menuPrice; }

    public String getMenuImagePath() { return menuImagePath; }  // SEKARANG RETURN STRING
    public void setMenuImagePath(String menuImagePath) { this.menuImagePath = menuImagePath; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes != null ? notes : ""; }

    public double getSubtotal() {
        return menuPrice * quantity;
    }
}