package com.example.kulinerapp.models;

public class CartItem {
    private int id;
    private int userId;
    private int menuItemId;
    private String menuName;
    private double menuPrice;
    private int menuImage;
    private int quantity;
    private String notes;

    public CartItem() {
    }

    public CartItem(int id, int userId, int menuItemId, String menuName,
                    double menuPrice, int menuImage, int quantity, String notes) {
        this.id = id;
        this.userId = userId;
        this.menuItemId = menuItemId;
        this.menuName = menuName;
        this.menuPrice = menuPrice;
        this.menuImage = menuImage;
        this.quantity = quantity;
        this.notes = notes;
    }

    public CartItem(int userId, int menuItemId, String menuName,
                    double menuPrice, int menuImage, int quantity, String notes) {
        this.userId = userId;
        this.menuItemId = menuItemId;
        this.menuName = menuName;
        this.menuPrice = menuPrice;
        this.menuImage = menuImage;
        this.quantity = quantity;
        this.notes = notes;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getMenuItemId() {
        return menuItemId;
    }

    public void setMenuItemId(int menuItemId) {
        this.menuItemId = menuItemId;
    }

    public String getMenuName() {
        return menuName;
    }

    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }

    public double getMenuPrice() {
        return menuPrice;
    }

    public void setMenuPrice(double menuPrice) {
        this.menuPrice = menuPrice;
    }

    public int getMenuImage() {
        return menuImage;
    }

    public void setMenuImage(int menuImage) {
        this.menuImage = menuImage;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public double getSubtotal() {
        return menuPrice * quantity;
    }
}