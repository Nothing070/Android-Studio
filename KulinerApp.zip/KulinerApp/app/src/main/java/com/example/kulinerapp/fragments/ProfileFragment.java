package com.example.kulinerapp.fragments;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import com.example.kulinerapp.LoginActivity;
import com.example.kulinerapp.R;
import com.example.kulinerapp.activities.AdminActivity;
import com.example.kulinerapp.activities.EditProfileActivity;
import com.example.kulinerapp.activities.MembershipActivity;
import com.example.kulinerapp.activities.OrderHistoryActivity;
import com.example.kulinerapp.activities.SettingsActivity;
import com.example.kulinerapp.utils.SessionManager;

public class ProfileFragment extends Fragment {

    private TextView tvProfileName, tvProfileEmail;
    private CardView cardMyProfile, cardOrderHistory, cardFavorites, cardVouchers,
            cardMembership, cardSettings, cardLogout, cardAdminPanel;

    private SessionManager sessionManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        sessionManager = new SessionManager(requireContext());

        tvProfileName = view.findViewById(R.id.tvProfileName);
        tvProfileEmail = view.findViewById(R.id.tvProfileEmail);
        cardMyProfile = view.findViewById(R.id.cardMyProfile);
        cardOrderHistory = view.findViewById(R.id.cardOrderHistory);
        cardFavorites = view.findViewById(R.id.cardFavorites);
        cardVouchers = view.findViewById(R.id.cardVouchers);
        cardMembership = view.findViewById(R.id.cardMembership);
        cardSettings = view.findViewById(R.id.cardSettings);
        cardLogout = view.findViewById(R.id.cardLogout);
        cardAdminPanel = view.findViewById(R.id.cardAdminPanel);

        loadProfileData();

        if (sessionManager.isAdmin()) {
            cardAdminPanel.setVisibility(View.VISIBLE);
        }

        // SEMUA SUDAH DIUBAH JADI FRAGMENT!
        cardMyProfile.setOnClickListener(v -> {
            animateClick(v);
            startActivity(new Intent(getActivity(), EditProfileActivity.class));
        });

        cardOrderHistory.setOnClickListener(v -> {
            animateClick(v);
            startActivity(new Intent(getActivity(), OrderHistoryActivity.class));
        });

        // FAVORITES → GUNAKAN FRAGMENT!
        cardFavorites.setOnClickListener(v -> {
            animateClick(v);
            loadFragment(new FavoritesFragment());
        });

        // VOUCHERS → GUNAKAN FRAGMENT!
        cardVouchers.setOnClickListener(v -> {
            animateClick(v);
            loadFragment(new VouchersFragment());
        });

        cardMembership.setOnClickListener(v -> {
            animateClick(v);
            startActivity(new Intent(getActivity(), MembershipActivity.class));
        });

        cardSettings.setOnClickListener(v -> {
            animateClick(v);
            startActivity(new Intent(getActivity(), SettingsActivity.class));
        });

        cardAdminPanel.setOnClickListener(v -> {
            animateClick(v);
            startActivity(new Intent(getActivity(), AdminActivity.class));
        });

        cardLogout.setOnClickListener(v -> {
            animateClick(v);
            showLogoutDialog();
        });

        return view;
    }

    // METHOD INI YANG PENTING BANGET!
    private void loadFragment(Fragment fragment) {
        requireActivity().getSupportFragmentManager()
                .beginTransaction()
                .setCustomAnimations(
                        R.anim.slide_in_right,
                        R.anim.slide_out_left,
                        R.anim.slide_in_left,
                        R.anim.slide_out_right
                )
                .replace(R.id.fragmentContainer, fragment)
                .addToBackStack(null)
                .commit();
    }

    private void loadProfileData() {
        tvProfileName.setText(sessionManager.getUserName());
        tvProfileEmail.setText(sessionManager.getUserEmail());
    }

    private void showLogoutDialog() {
        new AlertDialog.Builder(requireContext())
                .setTitle("Keluar")
                .setMessage("Apakah Anda yakin ingin keluar?")
                .setPositiveButton("Ya", (dialog, which) -> logout())
                .setNegativeButton("Batal", null)
                .show();
    }

    private void logout() {
        sessionManager.logoutUser();
        Toast.makeText(requireContext(), "Berhasil keluar", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(getActivity(), LoginActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
        requireActivity().finish();
    }

    private void animateClick(View view) {
        Animation bounce = AnimationUtils.loadAnimation(requireContext(), R.anim.bounce);
        view.startAnimation(bounce);
    }

    @Override
    public void onResume() {
        super.onResume();
        loadProfileData();
    }
}