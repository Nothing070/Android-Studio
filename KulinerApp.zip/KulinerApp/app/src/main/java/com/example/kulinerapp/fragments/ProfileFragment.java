package com.example.kulinerapp.fragments;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import com.example.kulinerapp.LoginActivity;
import com.example.kulinerapp.R;
import com.example.kulinerapp.activities.AdminActivity;
import com.example.kulinerapp.activities.EditProfileActivity;
import com.example.kulinerapp.activities.FavoritesActivity;
import com.example.kulinerapp.activities.MembershipActivity;
import com.example.kulinerapp.activities.OrderHistoryActivity;
import com.example.kulinerapp.activities.SettingsActivity;
import com.example.kulinerapp.activities.VouchersActivity;
import com.example.kulinerapp.utils.SessionManager;

public class ProfileFragment extends Fragment {

    private TextView tvProfileName, tvProfileEmail;
    private CardView cardMyProfile, cardOrderHistory, cardFavorites, cardVouchers,
            cardMembership, cardSettings, cardLogout, cardAdminPanel;

    private SessionManager sessionManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        // Initialize
        sessionManager = new SessionManager(getActivity());

        // Find views
        tvProfileName = view.findViewById(R.id.tvProfileName);
        tvProfileEmail = view.findViewById(R.id.tvProfileEmail);
        cardMyProfile = view.findViewById(R.id.cardMyProfile);
        cardOrderHistory = view.findViewById(R.id.cardOrderHistory);
        cardFavorites = view.findViewById(R.id.cardFavorites);
        cardVouchers = view.findViewById(R.id.cardVouchers);
        cardMembership = view.findViewById(R.id.cardMembership);
        cardSettings = view.findViewById(R.id.cardSettings);
        cardLogout = view.findViewById(R.id.cardLogout);
        cardAdminPanel = view.findViewById(R.id.cardAdminPanel);

        // Set profile data
        loadProfileData();

        // Show admin panel if user is admin
        if (sessionManager.isAdmin()) {
            cardAdminPanel.setVisibility(View.VISIBLE);
        }

        // Set click listeners
        cardMyProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                animateClick(v);
                Intent intent = new Intent(getActivity(), EditProfileActivity.class);
                startActivity(intent);
                getActivity().overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
        });

        cardOrderHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                animateClick(v);
                Intent intent = new Intent(getActivity(), OrderHistoryActivity.class);
                startActivity(intent);
                getActivity().overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
        });

        cardFavorites.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                animateClick(v);
                Intent intent = new Intent(getActivity(), FavoritesActivity.class);
                startActivity(intent);
                getActivity().overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
        });

        cardVouchers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                animateClick(v);
                Intent intent = new Intent(getActivity(), VouchersActivity.class);
                startActivity(intent);
                getActivity().overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
        });

        cardMembership.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                animateClick(v);
                Intent intent = new Intent(getActivity(), MembershipActivity.class);
                startActivity(intent);
                getActivity().overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
        });

        cardSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                animateClick(v);
                Intent intent = new Intent(getActivity(), SettingsActivity.class);
                startActivity(intent);
                getActivity().overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
        });

        cardAdminPanel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                animateClick(v);
                Intent intent = new Intent(getActivity(), AdminActivity.class);
                startActivity(intent);
                getActivity().overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
        });

        cardLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                animateClick(v);
                showLogoutDialog();
            }
        });

        return view;
    }

    private void loadProfileData() {
        tvProfileName.setText(sessionManager.getUserName());
        tvProfileEmail.setText(sessionManager.getUserEmail());
    }

    private void showLogoutDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Keluar");
        builder.setMessage("Apakah Anda yakin ingin keluar?");
        builder.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                logout();
            }
        });
        builder.setNegativeButton("Batal", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.show();
    }

    private void logout() {
        sessionManager.logoutUser();
        Toast.makeText(getActivity(), "Berhasil keluar", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(getActivity(), LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        getActivity().overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        getActivity().finish();
    }

    private void animateClick(View view) {
        Animation bounce = AnimationUtils.loadAnimation(getActivity(), R.anim.bounce);
        view.startAnimation(bounce);
    }

    @Override
    public void onResume() {
        super.onResume();
        loadProfileData();
    }
}