package com.example.kulinerapp.models;

public class Voucher {
    private int id;
    private String code;
    private String name;
    private String description;
    private int discountPercent;
    private double discountAmount;
    private double minPurchase;
    private String validUntil;
    private boolean isActive;
    private int imageResource;

    public Voucher() {
    }

    public Voucher(int id, String code, String name, String description,
                   int discountPercent, double discountAmount, double minPurchase,
                   String validUntil, boolean isActive, int imageResource) {
        this.id = id;
        this.code = code;
        this.name = name;
        this.description = description;
        this.discountPercent = discountPercent;
        this.discountAmount = discountAmount;
        this.minPurchase = minPurchase;
        this.validUntil = validUntil;
        this.isActive = isActive;
        this.imageResource = imageResource;
    }

    public Voucher(String code, String name, String description,
                   int discountPercent, double discountAmount, double minPurchase,
                   String validUntil, boolean isActive, int imageResource) {
        this.code = code;
        this.name = name;
        this.description = description;
        this.discountPercent = discountPercent;
        this.discountAmount = discountAmount;
        this.minPurchase = minPurchase;
        this.validUntil = validUntil;
        this.isActive = isActive;
        this.imageResource = imageResource;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public int getDiscountPercent() { return discountPercent; }
    public void setDiscountPercent(int discountPercent) { this.discountPercent = discountPercent; }

    public double getDiscountAmount() { return discountAmount; }
    public void setDiscountAmount(double discountAmount) { this.discountAmount = discountAmount; }

    public double getMinPurchase() { return minPurchase; }
    public void setMinPurchase(double minPurchase) { this.minPurchase = minPurchase; }

    public String getValidUntil() { return validUntil; }
    public void setValidUntil(String validUntil) { this.validUntil = validUntil; }

    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }

    public int getImageResource() { return imageResource; }
    public void setImageResource(int imageResource) { this.imageResource = imageResource; }
}