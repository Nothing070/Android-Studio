package com.example.kulinerapp;

import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.kulinerapp.database.DatabaseHelper;
import com.example.kulinerapp.fragments.CartFragment;
import com.example.kulinerapp.fragments.HomeFragment;
import com.example.kulinerapp.fragments.ProfileFragment;
import com.example.kulinerapp.fragments.SearchFragment;
import com.example.kulinerapp.utils.SessionManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {  // GANTI JADI AppCompatActivity (kalau belum pakai BaseActivity)

    private BottomNavigationView bottomNavigationView;
    private SessionManager sessionManager;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Init
        sessionManager = new SessionManager(this);
        db = new DatabaseHelper(this);
        bottomNavigationView = findViewById(R.id.bottomNavigationView);

        // Load fragment pertama
        if (savedInstanceState == null) {
            loadFragment(new HomeFragment());
            bottomNavigationView.setSelectedItemId(R.id.nav_home);
        }

        // Bottom Navigation Listener
        bottomNavigationView.setOnItemSelectedListener(this::onNavigationItemSelected);

        // Update badge keranjang
        updateCartBadge();
    }

    private boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Fragment fragment = null;

        int itemId = item.getItemId();
        if (itemId == R.id.nav_home) {
            fragment = new HomeFragment();
        } else if (itemId == R.id.nav_search) {
            fragment = new SearchFragment();
        } else if (itemId == R.id.nav_cart) {
            fragment = new CartFragment();
        } else if (itemId == R.id.nav_profile) {
            fragment = new ProfileFragment();
        }

        if (fragment != null) {
            loadFragment(fragment);
            return true;
        }
        return false;
    }

    private void loadFragment(Fragment fragment) {
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.setCustomAnimations(
                R.anim.fade_in,
                R.anim.fade_out
        );
        ft.replace(R.id.fragmentContainer, fragment);
        ft.commit();
    }

    // Method buat CartFragment panggil
    public BottomNavigationView getBottomNav() {
        return bottomNavigationView;
    }

    // Update badge keranjang
    public void updateCartBadge() {
        int count = db.getCartItemCount(sessionManager.getUserId()); // Total quantity (paling umum dipakai)

        TextView badge = findViewById(R.id.tvCartBadge);
        if (badge != null) {
            if (count > 0) {
                badge.setVisibility(View.VISIBLE);
                badge.setText(String.valueOf(count));
                if (count > 99) badge.setText("99+");
            } else {
                badge.setVisibility(View.GONE);
            }
        }
    }

    // Custom Toast Premium (Hijau + Icon Check)
    public void showCustomToast(String message) {
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.custom_toast, null);

        TextView text = layout.findViewById(R.id.tvToastMessage);
        text.setText(message);

        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setView(layout);
        toast.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 120);
        toast.show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateCartBadge();
    }
}