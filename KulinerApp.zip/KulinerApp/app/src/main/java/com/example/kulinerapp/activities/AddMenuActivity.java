package com.example.kulinerapp.activities;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.kulinerapp.R;
import com.example.kulinerapp.database.DatabaseHelper;
import com.example.kulinerapp.models.MenuItem;
import com.example.kulinerapp.utils.LocaleHelper;
import com.example.kulinerapp.utils.SessionManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class AddMenuActivity extends AppCompatActivity {

    private ImageView ivMenuHeader;
    private FloatingActionButton fabChangeImage;
    private TextInputEditText etMenuName, etMenuDescription, etMenuPrice, etMenuDiscount, etMenuRating;
    private AutoCompleteTextView spinnerCategory;
    private MaterialButton btnSave;
    private DatabaseHelper db;
    private String selectedImagePath = "";

    private final ActivityResultLauncher<Intent> imagePicker = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Uri uri = result.getData().getData();
                    try {
                        Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                        ivMenuHeader.setImageBitmap(bitmap);
                        selectedImagePath = saveImageToInternal(bitmap);
                    } catch (IOException e) {
                        Toast.makeText(this, "Gagal memuat gambar", Toast.LENGTH_SHORT).show();
                    }
                }
            });

    @Override
    protected void attachBaseContext(Context newBase) {
        SessionManager sm = new SessionManager(newBase);
        super.attachBaseContext(LocaleHelper.setLocale(newBase, sm.getLanguage()));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_menu);

        db = new DatabaseHelper(this);
        initViews();
        setupCategory();
        setupToolbar();
        setupListeners();
    }

    private void initViews() {
        ivMenuHeader = findViewById(R.id.ivMenuHeader);
        fabChangeImage = findViewById(R.id.fabChangeImage);
        etMenuName = findViewById(R.id.etMenuName);
        etMenuDescription = findViewById(R.id.etMenuDescription);
        etMenuPrice = findViewById(R.id.etMenuPrice);
        etMenuDiscount = findViewById(R.id.etMenuDiscount);
        etMenuRating = findViewById(R.id.etMenuRating);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        btnSave = findViewById(R.id.btnSave);
    }

    private void setupCategory() {
        String[] categories = getResources().getStringArray(R.array.menu_categories);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, categories);
        spinnerCategory.setAdapter(adapter);
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    private void setupListeners() {
        fabChangeImage.setOnClickListener(v -> openGallery());
        btnSave.setOnClickListener(v -> saveMenu());
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        imagePicker.launch(intent);
    }

    private String saveImageToInternal(Bitmap bitmap) {
        String filename = "menu_" + System.currentTimeMillis() + ".jpg";
        File file = new File(getFilesDir(), filename);
        try (FileOutputStream out = new FileOutputStream(file)) {
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
            return file.getAbsolutePath();
        } catch (IOException e) {
            e.printStackTrace();
            return "";
        }
    }

    private void saveMenu() {
        String name = etMenuName.getText().toString().trim();
        String desc = etMenuDescription.getText().toString().trim();
        String priceStr = etMenuPrice.getText().toString().trim();
        String discountStr = etMenuDiscount.getText().toString().trim();
        String ratingStr = etMenuRating.getText().toString().trim();
        String category = spinnerCategory.getText().toString().trim();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(desc) || TextUtils.isEmpty(priceStr) || TextUtils.isEmpty(category)) {
            Toast.makeText(this, "Lengkapi semua field wajib!", Toast.LENGTH_SHORT).show();
            return;
        }

        double price = Double.parseDouble(priceStr);
        int discount = TextUtils.isEmpty(discountStr) ? 0 : Integer.parseInt(discountStr);
        float rating = TextUtils.isEmpty(ratingStr) ? 4.8f : Float.parseFloat(ratingStr);

        MenuItem item = new MenuItem(0, name, desc, price, category,
                selectedImagePath.isEmpty() ? null : selectedImagePath,
                rating, discount, true);

        long id = db.addMenuItem(item);
        if (id > 0) {
            setResult(RESULT_OK);
            Toast.makeText(this, "Menu berhasil ditambahkan!", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Gagal menambahkan menu", Toast.LENGTH_SHORT).show();
        }
    }
}