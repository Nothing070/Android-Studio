package com.example.kulinerapp.models;

public class Favorite {
    private int id;
    private int userId;
    private int menuItemId;

    public Favorite() {
    }

    public Favorite(int id, int userId, int menuItemId) {
        this.id = id;
        this.userId = userId;
        this.menuItemId = menuItemId;
    }

    public Favorite(int userId, int menuItemId) {
        this.userId = userId;
        this.menuItemId = menuItemId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getMenuItemId() {
        return menuItemId;
    }

    public void setMenuItemId(int menuItemId) {
        this.menuItemId = menuItemId;
    }
}