package com.example.kulinerapp.fragments;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.R;
import com.example.kulinerapp.activities.AddMenuActivity;
import com.example.kulinerapp.activities.EditMenuActivity;
import com.example.kulinerapp.adapters.AdminMenuAdapter;
import com.example.kulinerapp.database.DatabaseHelper;
import com.example.kulinerapp.models.MenuItem;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class AdminMenuFragment extends Fragment implements AdminMenuAdapter.OnMenuActionListener {

    private RecyclerView recyclerView;
    private FloatingActionButton fabAddMenu;
    private AdminMenuAdapter adapter;
    private DatabaseHelper databaseHelper;
    private List<MenuItem> menuList;

    private final ActivityResultLauncher<Intent> addMenuLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    loadMenuData();
                }
            });

    private final ActivityResultLauncher<Intent> editMenuLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    loadMenuData();
                }
            });

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_admin_menu, container, false);

        recyclerView = view.findViewById(R.id.rvAdminMenu);
        fabAddMenu = view.findViewById(R.id.fabAddMenu);
        databaseHelper = new DatabaseHelper(getContext());

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        loadMenuData();

        fabAddMenu.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), AddMenuActivity.class);
            addMenuLauncher.launch(intent);
        });

        return view;
    }

    private void loadMenuData() {
        menuList = databaseHelper.getAllMenuItems();
        adapter = new AdminMenuAdapter(getContext(), menuList, this);
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onEditClick(MenuItem menuItem) {
        Intent intent = new Intent(getActivity(), EditMenuActivity.class);
        intent.putExtra("MENU_ITEM", menuItem);
        editMenuLauncher.launch(intent);
    }

    @Override
    public void onDeleteClick(MenuItem menuItem) {
        new androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Hapus Menu")
                .setMessage("Yakin ingin menghapus \"" + menuItem.getName() + "\"?")
                .setPositiveButton("Hapus", (d, w) -> {
                    databaseHelper.deleteMenuItem(menuItem.getId());
                    loadMenuData();
                    Toast.makeText(requireContext(), "Menu berhasil dihapus", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    @Override
    public void onAvailabilityChanged(MenuItem menuItem, boolean isAvailable) {
        menuItem.setAvailable(isAvailable);
        if (databaseHelper.updateMenuAvailability(menuItem.getId(), isAvailable)) {
            Toast.makeText(getContext(), menuItem.getName() + " sekarang " + (isAvailable ? "tersedia" : "habis"), Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getContext(), "Gagal update status", Toast.LENGTH_SHORT).show();
            loadMenuData();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        loadMenuData();
    }
}