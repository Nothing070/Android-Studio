package com.example.kulinerapp.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.R;
import com.example.kulinerapp.adapters.AdminMenuAdapter;
import com.example.kulinerapp.database.DatabaseHelper;
import com.example.kulinerapp.models.MenuItem;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class AdminMenuFragment extends Fragment {

    private RecyclerView rvAdminMenu;
    private FloatingActionButton fabAddMenu;

    private AdminMenuAdapter adminMenuAdapter;
    private DatabaseHelper db;
    private List<MenuItem> menuItems;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_admin_menu, container, false);

        // Initialize
        db = new DatabaseHelper(getActivity());

        // Find views
        rvAdminMenu = view.findViewById(R.id.rvAdminMenu);
        fabAddMenu = view.findViewById(R.id.fabAddMenu);

        // Setup RecyclerView
        setupMenuRecyclerView();

        // Load menu items
        loadMenuItems();

        // Set click listeners
        fabAddMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "Fitur tambah menu akan segera hadir",
                        Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }

    private void setupMenuRecyclerView() {
        GridLayoutManager layoutManager = new GridLayoutManager(getActivity(), 1);
        rvAdminMenu.setLayoutManager(layoutManager);

        menuItems = new ArrayList<>();
        adminMenuAdapter = new AdminMenuAdapter(getActivity(), menuItems,
                new AdminMenuAdapter.OnAdminMenuActionListener() {
                    @Override
                    public void onEditMenu(MenuItem item) {
                        Toast.makeText(getActivity(), "Edit: " + item.getName(),
                                Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onDeleteMenu(MenuItem item) {
                        deleteMenuItem(item);
                    }

                    @Override
                    public void onToggleAvailability(MenuItem item) {
                        toggleMenuAvailability(item);
                    }
                });
        rvAdminMenu.setAdapter(adminMenuAdapter);
    }

    private void loadMenuItems() {
        menuItems.clear();
        menuItems.addAll(db.getAllMenuItems());
        adminMenuAdapter.notifyDataSetChanged();
    }

    private void deleteMenuItem(MenuItem item) {
        db.deleteMenuItem(item.getId());
        Toast.makeText(getActivity(), item.getName() + " berhasil dihapus",
                Toast.LENGTH_SHORT).show();
        loadMenuItems();
    }

    private void toggleMenuAvailability(MenuItem item) {
        item.setAvailable(!item.isAvailable());
        db.updateMenuItem(item);
        String status = item.isAvailable() ? "tersedia" : "tidak tersedia";
        Toast.makeText(getActivity(), item.getName() + " sekarang " + status,
                Toast.LENGTH_SHORT).show();
        loadMenuItems();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadMenuItems();
    }
}