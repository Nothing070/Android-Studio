package com.example.kulinerapp.models;

public class OrderDetail {
    private int id;
    private int orderId;
    private int menuItemId;
    private String menuName;
    private int quantity;
    private double price;

    public OrderDetail() {
    }

    public OrderDetail(int id, int orderId, int menuItemId, String menuName, int quantity, double price) {
        this.id = id;
        this.orderId = orderId;
        this.menuItemId = menuItemId;
        this.menuName = menuName;
        this.quantity = quantity;
        this.price = price;
    }

    public OrderDetail(int orderId, int menuItemId, String menuName, int quantity, double price) {
        this.orderId = orderId;
        this.menuItemId = menuItemId;
        this.menuName = menuName;
        this.quantity = quantity;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getMenuItemId() {
        return menuItemId;
    }

    public void setMenuItemId(int menuItemId) {
        this.menuItemId = menuItemId;
    }

    public String getMenuName() {
        return menuName;
    }

    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getSubtotal() {
        return price * quantity;
    }
}