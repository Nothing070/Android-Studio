package com.example.kulinerapp.activities;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.R;
import com.example.kulinerapp.adapters.VoucherAdapter;
import com.example.kulinerapp.database.DatabaseHelper;
import com.example.kulinerapp.models.Voucher;
import com.example.kulinerapp.utils.LocaleHelper;
import com.example.kulinerapp.utils.SessionManager;

import java.util.ArrayList;
import java.util.List;

public class VouchersActivity extends AppCompatActivity {

    private ImageView ivBack;
    private EditText etVoucherCode;
    private Button btnApplyVoucher;
    private RecyclerView rvVouchers;
    private LinearLayout emptyVoucherView;

    private VoucherAdapter voucherAdapter;
    private DatabaseHelper db;
    private SessionManager sessionManager;
    private List<Voucher> vouchers;

    @Override
    protected void attachBaseContext(Context newBase) {
        SessionManager sessionManager = new SessionManager(newBase);
        String savedLanguage = sessionManager.getLanguage();
        super.attachBaseContext(LocaleHelper.setLocale(newBase, savedLanguage));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vouchers);

        // Initialize
        db = new DatabaseHelper(this);
        sessionManager = new SessionManager(this);

        // Find views
        ivBack = findViewById(R.id.ivBack);
        etVoucherCode = findViewById(R.id.etVoucherCode);
        btnApplyVoucher = findViewById(R.id.btnApplyVoucher);
        rvVouchers = findViewById(R.id.rvVouchers);
        emptyVoucherView = findViewById(R.id.emptyVoucherView);

        // Handle back press
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                finish();
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            }
        });

        // Setup RecyclerView
        setupVouchersRecyclerView();

        // Load vouchers
        loadVouchers();

        // Set click listeners
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            }
        });

        btnApplyVoucher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                applyVoucher();
            }
        });
    }

    private void setupVouchersRecyclerView() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        rvVouchers.setLayoutManager(layoutManager);

        vouchers = new ArrayList<>();
        voucherAdapter = new VoucherAdapter(this, vouchers, new VoucherAdapter.OnVoucherClickListener() {
            @Override
            public void onVoucherClick(Voucher voucher) {
                etVoucherCode.setText(voucher.getCode());
            }
        });
        rvVouchers.setAdapter(voucherAdapter);
    }

    private void loadVouchers() {
        vouchers.clear();
        vouchers.addAll(db.getAllVouchers());

        if (vouchers.isEmpty()) {
            emptyVoucherView.setVisibility(View.VISIBLE);
            rvVouchers.setVisibility(View.GONE);
        } else {
            emptyVoucherView.setVisibility(View.GONE);
            rvVouchers.setVisibility(View.VISIBLE);
        }

        voucherAdapter.notifyDataSetChanged();
    }

    private void applyVoucher() {
        String code = etVoucherCode.getText().toString().trim().toUpperCase();

        if (TextUtils.isEmpty(code)) {
            etVoucherCode.setError("Masukkan kode voucher");
            etVoucherCode.requestFocus();
            return;
        }

        Voucher voucher = db.getVoucherByCode(code);

        if (voucher != null) {
            Toast.makeText(this, "Voucher berhasil diterapkan!", Toast.LENGTH_SHORT).show();
            etVoucherCode.setText("");
        } else {
            Toast.makeText(this, "Kode voucher tidak valid", Toast.LENGTH_SHORT).show();
        }
    }
}