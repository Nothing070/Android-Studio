package com.example.kulinerapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.R;

import java.util.List;

public class SearchHistoryAdapter extends RecyclerView.Adapter<SearchHistoryAdapter.HistoryViewHolder> {

    private Context context;
    private List<String> historyList;
    private OnHistoryActionListener listener;

    public interface OnHistoryActionListener {
        void onHistoryClick(String query);
        void onDeleteClick(String query);
    }

    public SearchHistoryAdapter(Context context, List<String> historyList, OnHistoryActionListener listener) {
        this.context = context;
        this.historyList = historyList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public HistoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_search_history, parent, false);
        return new HistoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HistoryViewHolder holder, int position) {
        String query = historyList.get(position);
        holder.tvHistoryQuery.setText(query);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onHistoryClick(query);
            }
        });

        holder.ivDeleteHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onDeleteClick(query);
            }
        });
    }

    @Override
    public int getItemCount() {
        return historyList.size();
    }

    static class HistoryViewHolder extends RecyclerView.ViewHolder {
        TextView tvHistoryQuery;
        ImageView ivDeleteHistory;

        public HistoryViewHolder(@NonNull View itemView) {
            super(itemView);
            tvHistoryQuery = itemView.findViewById(R.id.tvHistoryQuery);
            ivDeleteHistory = itemView.findViewById(R.id.ivDeleteHistory);
        }
    }
}