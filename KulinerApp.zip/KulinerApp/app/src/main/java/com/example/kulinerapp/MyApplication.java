package com.example.kulinerapp;

import android.app.Application;
import android.content.Context;
import com.example.kulinerapp.utils.LocaleHelper;
import com.example.kulinerapp.utils.SessionManager;

public class MyApplication extends Application {
    @Override
    protected void attachBaseContext(Context base) {
        SessionManager sm = new SessionManager(base);
        super.attachBaseContext(LocaleHelper.setLocale(base, sm.getLanguage()));
    }
}