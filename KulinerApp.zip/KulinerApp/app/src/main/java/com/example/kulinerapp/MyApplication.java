package com.example.kulinerapp;

import android.app.Application;
import android.content.Context;
import com.example.kulinerapp.utils.LocaleHelper;

public class MyApplication extends Application {

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleHelper.onAttach(base));
    }
}