package com.example.kulinerapp.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.cardview.widget.CardView;

import com.example.kulinerapp.R;
import com.example.kulinerapp.utils.LocaleHelper;
import com.example.kulinerapp.utils.SessionManager;

public class SettingsActivity extends AppCompatActivity {

    private ImageView ivBack;
    private CardView cardChangePassword, cardLanguage, cardAbout, cardPrivacy, cardTerms;
    private SwitchCompat switchOrderNotif, switchPromoNotif;
    private TextView tvCurrentLanguage;

    private SessionManager sessionManager;

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(LocaleHelper.onAttach(newBase));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Initialize
        sessionManager = new SessionManager(this);

        // Find views
        ivBack = findViewById(R.id.ivBack);
        cardChangePassword = findViewById(R.id.cardChangePassword);
        cardLanguage = findViewById(R.id.cardLanguage);
        cardAbout = findViewById(R.id.cardAbout);
        cardPrivacy = findViewById(R.id.cardPrivacy);
        cardTerms = findViewById(R.id.cardTerms);
        switchOrderNotif = findViewById(R.id.switchOrderNotif);
        switchPromoNotif = findViewById(R.id.switchPromoNotif);
        tvCurrentLanguage = findViewById(R.id.tvCurrentLanguage);

        // Load saved preferences
        loadPreferences();

        // Handle back press
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                finish();
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            }
        });

        // Set click listeners
        ivBack.setOnClickListener(v -> {
            finish();
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        });

        cardChangePassword.setOnClickListener(v -> {
            Intent intent = new Intent(SettingsActivity.this, ChangePasswordActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });

        cardLanguage.setOnClickListener(v -> {
            Intent intent = new Intent(SettingsActivity.this, LanguageActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });

        cardAbout.setOnClickListener(v -> {
            Toast.makeText(SettingsActivity.this,
                    "KulinerApp v1.0.0\nDeveloped by KulinerApp Team",
                    Toast.LENGTH_LONG).show();
        });

        cardPrivacy.setOnClickListener(v -> {
            Toast.makeText(SettingsActivity.this,
                    "Kebijakan privasi akan segera hadir", Toast.LENGTH_SHORT).show();
        });

        cardTerms.setOnClickListener(v -> {
            Toast.makeText(SettingsActivity.this,
                    "Syarat & ketentuan akan segera hadir", Toast.LENGTH_SHORT).show();
        });

        // Switch listeners
        switchOrderNotif.setOnCheckedChangeListener((buttonView, isChecked) -> {
            sessionManager.setOrderNotification(isChecked);
            String message = isChecked ? "Notifikasi pesanan diaktifkan" : "Notifikasi pesanan dinonaktifkan";
            Toast.makeText(SettingsActivity.this, message, Toast.LENGTH_SHORT).show();
        });

        switchPromoNotif.setOnCheckedChangeListener((buttonView, isChecked) -> {
            sessionManager.setPromoNotification(isChecked);
            String message = isChecked ? "Notifikasi promo diaktifkan" : "Notifikasi promo dinonaktifkan";
            Toast.makeText(SettingsActivity.this, message, Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateLanguageDisplay();
    }

    private void loadPreferences() {
        switchOrderNotif.setChecked(sessionManager.isOrderNotificationEnabled());
        switchPromoNotif.setChecked(sessionManager.isPromoNotificationEnabled());
        updateLanguageDisplay();
    }

    private void updateLanguageDisplay() {
        String currentLang = sessionManager.getLanguage();
        tvCurrentLanguage.setText(LocaleHelper.getLanguageName(currentLang));
    }
}