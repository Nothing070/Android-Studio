package com.example.kulinerapp.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.cardview.widget.CardView;

import com.example.kulinerapp.R;

public class SettingsActivity extends AppCompatActivity {

    private ImageView ivBack;
    private CardView cardChangePassword, cardLanguage, cardAbout, cardPrivacy, cardTerms;
    private SwitchCompat switchOrderNotif, switchPromoNotif;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Find views
        ivBack = findViewById(R.id.ivBack);
        cardChangePassword = findViewById(R.id.cardChangePassword);
        cardLanguage = findViewById(R.id.cardLanguage);
        cardAbout = findViewById(R.id.cardAbout);
        cardPrivacy = findViewById(R.id.cardPrivacy);
        cardTerms = findViewById(R.id.cardTerms);
        switchOrderNotif = findViewById(R.id.switchOrderNotif);
        switchPromoNotif = findViewById(R.id.switchPromoNotif);

        // Handle back press
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                finish();
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            }
        });

        // Set click listeners
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            }
        });

        cardChangePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(SettingsActivity.this,
                        "Fitur ubah password akan segera hadir", Toast.LENGTH_SHORT).show();
            }
        });

        cardLanguage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(SettingsActivity.this,
                        "Fitur ganti bahasa akan segera hadir", Toast.LENGTH_SHORT).show();
            }
        });

        cardAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(SettingsActivity.this,
                        "KulinerApp v1.0.0\nDeveloped by KulinerApp Team",
                        Toast.LENGTH_LONG).show();
            }
        });

        cardPrivacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(SettingsActivity.this,
                        "Kebijakan privasi akan segera hadir", Toast.LENGTH_SHORT).show();
            }
        });

        cardTerms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(SettingsActivity.this,
                        "Syarat & ketentuan akan segera hadir", Toast.LENGTH_SHORT).show();
            }
        });

        // Switch listeners
        switchOrderNotif.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                String message = isChecked ? "Notifikasi pesanan diaktifkan" : "Notifikasi pesanan dinonaktifkan";
                Toast.makeText(SettingsActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });

        switchPromoNotif.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                String message = isChecked ? "Notifikasi promo diaktifkan" : "Notifikasi promo dinonaktifkan";
                Toast.makeText(SettingsActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }
}