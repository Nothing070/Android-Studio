package com.example.kulinerapp.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPreferencesManager {
    private static final String PREF_NAME = "KulinerAppPrefs";
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_USER_EMAIL = "user_email";
    private static final String KEY_USER_NAME = "user_name";
    private static final String KEY_IS_LOGGED_IN = "is_logged_in";
    private static final String KEY_LANGUAGE = "app_language";
    private static final String KEY_ORDER_NOTIF = "order_notification";
    private static final String KEY_PROMO_NOTIF = "promo_notification";

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private Context context;

    public SharedPreferencesManager(Context context) {
        this.context = context;
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    // User Session
    public void saveUserSession(int userId, String email, String username) {
        editor.putInt(KEY_USER_ID, userId);
        editor.putString(KEY_USER_EMAIL, email);
        editor.putString(KEY_USER_NAME, username);
        editor.putBoolean(KEY_IS_LOGGED_IN, true);
        editor.apply();
    }

    public int getUserId() {
        return sharedPreferences.getInt(KEY_USER_ID, -1);
    }

    public String getUserEmail() {
        return sharedPreferences.getString(KEY_USER_EMAIL, "");
    }

    public String getUserName() {
        return sharedPreferences.getString(KEY_USER_NAME, "");
    }

    public boolean isLoggedIn() {
        return sharedPreferences.getBoolean(KEY_IS_LOGGED_IN, false);
    }

    public void clearSession() {
        editor.clear();
        editor.apply();
    }

    // Language Settings
    public void setLanguage(String languageCode) {
        editor.putString(KEY_LANGUAGE, languageCode);
        editor.apply();
    }

    public String getLanguage() {
        return sharedPreferences.getString(KEY_LANGUAGE, "id"); // Default Indonesia
    }

    // Notification Settings
    public void setOrderNotification(boolean enabled) {
        editor.putBoolean(KEY_ORDER_NOTIF, enabled);
        editor.apply();
    }

    public boolean isOrderNotificationEnabled() {
        return sharedPreferences.getBoolean(KEY_ORDER_NOTIF, true);
    }

    public void setPromoNotification(boolean enabled) {
        editor.putBoolean(KEY_PROMO_NOTIF, enabled);
        editor.apply();
    }

    public boolean isPromoNotificationEnabled() {
        return sharedPreferences.getBoolean(KEY_PROMO_NOTIF, true);
    }
}