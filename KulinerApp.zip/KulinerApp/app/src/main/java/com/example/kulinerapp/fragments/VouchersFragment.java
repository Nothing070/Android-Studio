package com.example.kulinerapp.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.R;
import com.example.kulinerapp.adapters.VoucherAdapter;
import com.example.kulinerapp.database.DatabaseHelper;
import com.example.kulinerapp.models.Voucher;

import java.util.List;

public class VouchersFragment extends Fragment {

    private RecyclerView rvVouchers;
    private TextView tvEmpty;
    private VoucherAdapter adapter;
    private DatabaseHelper db;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_vouchers, container, false);

        rvVouchers = view.findViewById(R.id.rvVouchers);
        tvEmpty = view.findViewById(R.id.tvEmptyVouchers);

        db = new DatabaseHelper(requireContext());
        List<Voucher> voucherList = db.getAllVouchers();

        rvVouchers.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new VoucherAdapter(requireContext(), voucherList);
        rvVouchers.setAdapter(adapter);

        if (voucherList.isEmpty()) {
            tvEmpty.setVisibility(View.VISIBLE);
            rvVouchers.setVisibility(View.GONE);
        } else {
            tvEmpty.setVisibility(View.GONE);
            rvVouchers.setVisibility(View.VISIBLE);
        }

        return view;
    }
}