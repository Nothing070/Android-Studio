package com.example.kulinerapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.kulinerapp.database.DatabaseHelper;
import com.example.kulinerapp.utils.DataSeeder;
import com.example.kulinerapp.utils.SessionManager;

public class SplashActivity extends AppCompatActivity {

    private static final int SPLASH_DURATION = 3800;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        sessionManager = new SessionManager(this);

        // Init database + seeding di background
        initializeDatabase();

        // Animasi keren
        applyAnimations();

        // Pindah setelah delay
        new Handler().postDelayed(this::navigateToNextScreen, SPLASH_DURATION);
    }

    private void initializeDatabase() {
        new Thread(() -> {
            DatabaseHelper db = new DatabaseHelper(SplashActivity.this);
            DataSeeder seeder = new DataSeeder(SplashActivity.this);
            seeder.seedData();
        }).start();
    }

    private void applyAnimations() {
        CardView logoCard = findViewById(R.id.logoCard);
        TextView tvAppName = findViewById(R.id.tvAppName);
        TextView tvTagline = findViewById(R.id.tvTagline);
        View decorLine = findViewById(R.id.decorLine);
        LinearLayout loadingSection = findViewById(R.id.loadingSection);
        TextView tvLoading = findViewById(R.id.tvLoading);

        // Logo bounce
        logoCard.setScaleX(0f); logoCard.setScaleY(0f);
        logoCard.animate().scaleX(1f).scaleY(1f)
                .setDuration(1000).setStartDelay(300)
                .setInterpolator(new OvershootInterpolator()).start();

        // App name slide up
        tvAppName.setTranslationY(100f); tvAppName.setAlpha(0f);
        tvAppName.animate().translationY(0f).alpha(1f)
                .setDuration(800).setStartDelay(800).start();

        // Tagline fade
        tvTagline.setAlpha(0f);
        tvTagline.animate().alpha(1f).setDuration(800).setStartDelay(1200).start();

        // Decor line
        decorLine.setScaleX(0f);
        decorLine.animate().scaleX(1f).setDuration(600).setStartDelay(1400).start();

        // Loading section
        loadingSection.setAlpha(0f);
        loadingSection.animate().alpha(1f).setDuration(600).setStartDelay(1800).start();

        // Pulsing dots
        final String[] dots = {"", ".", "..", "..."};
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            int i = 0;
            @Override public void run() {
                tvLoading.setText("Memuat data" + dots[i++ % 4]);
                handler.postDelayed(this, 400);
            }
        }, 400);
    }

    private void navigateToNextScreen() {
        Intent intent;
        if (sessionManager.isLoggedIn() && sessionManager.getUserId() > 0) {
            intent = new Intent(this, MainActivity.class);
        } else {
            sessionManager.logoutUser(); // bersihkan session rusak
            intent = new Intent(this, LoginActivity.class);
        }
        startActivity(intent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        finish();
    }
}