package com.example.kulinerapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.kulinerapp.database.DatabaseHelper;
import com.example.kulinerapp.utils.DataSeeder;
import com.example.kulinerapp.utils.SessionManager;

public class SplashActivity extends AppCompatActivity {

    private static final int SPLASH_DURATION = 3500; // 3.5 seconds
    private SessionManager sessionManager;

    private CardView logoCard;
    private TextView tvAppName, tvTagline, tvLoading;
    private View decorLine;
    private LinearLayout loadingSection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        sessionManager = new SessionManager(this);

        // Find views
        logoCard = findViewById(R.id.logoCard);
        tvAppName = findViewById(R.id.tvAppName);
        tvTagline = findViewById(R.id.tvTagline);
        tvLoading = findViewById(R.id.tvLoading);
        decorLine = findViewById(R.id.decorLine);
        loadingSection = findViewById(R.id.loadingSection);

        // Initialize database in background
        initializeDatabase();

        // Apply beautiful animations
        applyAnimations();

        // Navigate after delay
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                navigateToNextScreen();
            }
        }, SPLASH_DURATION);
    }

    private void initializeDatabase() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                DatabaseHelper db = new DatabaseHelper(SplashActivity.this);
                DataSeeder seeder = new DataSeeder(SplashActivity.this);
                seeder.seedData();
            }
        }).start();
    }

    private void applyAnimations() {
        // Fade in untuk background
        View rootLayout = findViewById(android.R.id.content);
        Animation fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        fadeIn.setDuration(800);
        rootLayout.startAnimation(fadeIn);

        // Scale + Bounce animation untuk logo
        logoCard.setScaleX(0f);
        logoCard.setScaleY(0f);
        logoCard.animate()
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(1000)
                .setStartDelay(300)
                .setInterpolator(new OvershootInterpolator())
                .start();

        // Slide from bottom untuk app name
        tvAppName.setTranslationY(100f);
        tvAppName.setAlpha(0f);
        tvAppName.animate()
                .translationY(0f)
                .alpha(1f)
                .setDuration(800)
                .setStartDelay(800)
                .setInterpolator(new DecelerateInterpolator())
                .start();

        // Fade in untuk tagline
        tvTagline.setAlpha(0f);
        tvTagline.animate()
                .alpha(1f)
                .setDuration(800)
                .setStartDelay(1200)
                .start();

        // Scale animation untuk decorative line
        decorLine.setScaleX(0f);
        decorLine.animate()
                .scaleX(1f)
                .setDuration(600)
                .setStartDelay(1400)
                .start();

        // Fade in untuk loading section
        loadingSection.setAlpha(0f);
        loadingSection.animate()
                .alpha(1f)
                .setDuration(600)
                .setStartDelay(1800)
                .start();

        // Pulsing animation untuk loading text
        animateLoadingText();
    }

    private void animateLoadingText() {
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            int dotCount = 0;
            @Override
            public void run() {
                String[] loadingTexts = {
                        "Memuat data",
                        "Memuat data.",
                        "Memuat data..",
                        "Memuat data..."
                };

                tvLoading.setText(loadingTexts[dotCount]);
                dotCount = (dotCount + 1) % loadingTexts.length;

                handler.postDelayed(this, 400);
            }
        }, 400);
    }

    private void navigateToNextScreen() {
        Intent intent;

        if (sessionManager.isLoggedIn()) {
            intent = new Intent(SplashActivity.this, MainActivity.class);
        } else {
            intent = new Intent(SplashActivity.this, LoginActivity.class);
        }

        startActivity(intent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        finish();
    }
}