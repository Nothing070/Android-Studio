package com.example.kulinerapp.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.kulinerapp.models.CartItem;
import com.example.kulinerapp.models.Favorite;
import com.example.kulinerapp.models.MenuItem;
import com.example.kulinerapp.models.Order;
import com.example.kulinerapp.models.OrderDetail;
import com.example.kulinerapp.models.User;
import com.example.kulinerapp.models.Voucher;
import com.example.kulinerapp.models.Membership;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "KulinerApp.db";
    private static final int DATABASE_VERSION = 2;

    // Table Users
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "id";
    private static final String COLUMN_USER_NAME = "username";
    private static final String COLUMN_USER_EMAIL = "email";
    private static final String COLUMN_USER_PHONE = "phone";
    private static final String COLUMN_USER_PASSWORD = "password";
    private static final String COLUMN_USER_IS_ADMIN = "is_admin";

    // Table Menu Items
    private static final String TABLE_MENU_ITEMS = "menu_items";
    private static final String COLUMN_MENU_ID = "id";
    private static final String COLUMN_MENU_NAME = "name";
    private static final String COLUMN_MENU_DESCRIPTION = "description";
    private static final String COLUMN_MENU_PRICE = "price";
    private static final String COLUMN_MENU_CATEGORY = "category";
    private static final String COLUMN_MENU_IMAGE = "image_resource";
    private static final String COLUMN_MENU_RATING = "rating";
    private static final String COLUMN_MENU_DISCOUNT = "discount";
    private static final String COLUMN_MENU_AVAILABLE = "is_available";

    // Table Cart
    private static final String TABLE_CART = "cart";
    private static final String COLUMN_CART_ID = "id";
    private static final String COLUMN_CART_USER_ID = "user_id";
    private static final String COLUMN_CART_MENU_ID = "menu_item_id";
    private static final String COLUMN_CART_MENU_NAME = "menu_name";
    private static final String COLUMN_CART_MENU_PRICE = "menu_price";
    private static final String COLUMN_CART_MENU_IMAGE = "menu_image";
    private static final String COLUMN_CART_QUANTITY = "quantity";
    private static final String COLUMN_CART_NOTES = "notes";

    // Table Orders
    private static final String TABLE_ORDERS = "orders";
    private static final String COLUMN_ORDER_ID = "id";
    private static final String COLUMN_ORDER_USER_ID = "user_id";
    private static final String COLUMN_ORDER_DATE = "order_date";
    private static final String COLUMN_ORDER_TOTAL = "total_amount";
    private static final String COLUMN_ORDER_STATUS = "status";
    private static final String COLUMN_ORDER_ADDRESS = "delivery_address";
    private static final String COLUMN_ORDER_PAYMENT = "payment_method";

    // Table Order Details
    private static final String TABLE_ORDER_DETAILS = "order_details";
    private static final String COLUMN_ORDER_DETAIL_ID = "id";
    private static final String COLUMN_ORDER_DETAIL_ORDER_ID = "order_id";
    private static final String COLUMN_ORDER_DETAIL_MENU_ID = "menu_item_id";
    private static final String COLUMN_ORDER_DETAIL_MENU_NAME = "menu_name";
    private static final String COLUMN_ORDER_DETAIL_QUANTITY = "quantity";
    private static final String COLUMN_ORDER_DETAIL_PRICE = "price";

    // Table Favorites
    private static final String TABLE_FAVORITES = "favorites";
    private static final String COLUMN_FAVORITE_ID = "id";
    private static final String COLUMN_FAVORITE_USER_ID = "user_id";
    private static final String COLUMN_FAVORITE_MENU_ID = "menu_item_id";

    // Table Search History
    private static final String TABLE_SEARCH_HISTORY = "search_history";
    private static final String COLUMN_SEARCH_ID = "id";
    private static final String COLUMN_SEARCH_USER_ID = "user_id";
    private static final String COLUMN_SEARCH_QUERY = "query";
    private static final String COLUMN_SEARCH_DATE = "search_date";

    // Table Vouchers
    private static final String TABLE_VOUCHERS = "vouchers";
    private static final String COLUMN_VOUCHER_ID = "id";
    private static final String COLUMN_VOUCHER_CODE = "code";
    private static final String COLUMN_VOUCHER_NAME = "name";
    private static final String COLUMN_VOUCHER_DESCRIPTION = "description";
    private static final String COLUMN_VOUCHER_DISCOUNT_PERCENT = "discount_percent";
    private static final String COLUMN_VOUCHER_DISCOUNT_AMOUNT = "discount_amount";
    private static final String COLUMN_VOUCHER_MIN_PURCHASE = "min_purchase";
    private static final String COLUMN_VOUCHER_VALID_UNTIL = "valid_until";
    private static final String COLUMN_VOUCHER_IS_ACTIVE = "is_active";
    private static final String COLUMN_VOUCHER_IMAGE = "image_resource";

    // Table Memberships
    private static final String TABLE_MEMBERSHIPS = "memberships";
    private static final String COLUMN_MEMBERSHIP_ID = "id";
    private static final String COLUMN_MEMBERSHIP_USER_ID = "user_id";
    private static final String COLUMN_MEMBERSHIP_TYPE = "member_type";
    private static final String COLUMN_MEMBERSHIP_POINTS = "points";
    private static final String COLUMN_MEMBERSHIP_JOIN_DATE = "join_date";
    private static final String COLUMN_MEMBERSHIP_EXPIRED_DATE = "expired_date";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users Table
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + "("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_USER_NAME + " TEXT,"
                + COLUMN_USER_EMAIL + " TEXT UNIQUE,"
                + COLUMN_USER_PHONE + " TEXT,"
                + COLUMN_USER_PASSWORD + " TEXT,"
                + COLUMN_USER_IS_ADMIN + " INTEGER DEFAULT 0"
                + ")";
        db.execSQL(createUsersTable);

        // Create Menu Items Table
        String createMenuTable = "CREATE TABLE " + TABLE_MENU_ITEMS + "("
                + COLUMN_MENU_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_MENU_NAME + " TEXT,"
                + COLUMN_MENU_DESCRIPTION + " TEXT,"
                + COLUMN_MENU_PRICE + " REAL,"
                + COLUMN_MENU_CATEGORY + " TEXT,"
                + COLUMN_MENU_IMAGE + " INTEGER,"
                + COLUMN_MENU_RATING + " REAL,"
                + COLUMN_MENU_DISCOUNT + " INTEGER,"
                + COLUMN_MENU_AVAILABLE + " INTEGER DEFAULT 1"
                + ")";
        db.execSQL(createMenuTable);

        // Create Cart Table
        String createCartTable = "CREATE TABLE " + TABLE_CART + "("
                + COLUMN_CART_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_CART_USER_ID + " INTEGER,"
                + COLUMN_CART_MENU_ID + " INTEGER,"
                + COLUMN_CART_MENU_NAME + " TEXT,"
                + COLUMN_CART_MENU_PRICE + " REAL,"
                + COLUMN_CART_MENU_IMAGE + " INTEGER,"
                + COLUMN_CART_QUANTITY + " INTEGER,"
                + COLUMN_CART_NOTES + " TEXT,"
                + "FOREIGN KEY(" + COLUMN_CART_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + "),"
                + "FOREIGN KEY(" + COLUMN_CART_MENU_ID + ") REFERENCES " + TABLE_MENU_ITEMS + "(" + COLUMN_MENU_ID + ")"
                + ")";
        db.execSQL(createCartTable);

        // Create Orders Table
        String createOrdersTable = "CREATE TABLE " + TABLE_ORDERS + "("
                + COLUMN_ORDER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_ORDER_USER_ID + " INTEGER,"
                + COLUMN_ORDER_DATE + " TEXT,"
                + COLUMN_ORDER_TOTAL + " REAL,"
                + COLUMN_ORDER_STATUS + " TEXT,"
                + COLUMN_ORDER_ADDRESS + " TEXT,"
                + COLUMN_ORDER_PAYMENT + " TEXT,"
                + "FOREIGN KEY(" + COLUMN_ORDER_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + ")"
                + ")";
        db.execSQL(createOrdersTable);

        // Create Order Details Table
        String createOrderDetailsTable = "CREATE TABLE " + TABLE_ORDER_DETAILS + "("
                + COLUMN_ORDER_DETAIL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_ORDER_DETAIL_ORDER_ID + " INTEGER,"
                + COLUMN_ORDER_DETAIL_MENU_ID + " INTEGER,"
                + COLUMN_ORDER_DETAIL_MENU_NAME + " TEXT,"
                + COLUMN_ORDER_DETAIL_QUANTITY + " INTEGER,"
                + COLUMN_ORDER_DETAIL_PRICE + " REAL,"
                + "FOREIGN KEY(" + COLUMN_ORDER_DETAIL_ORDER_ID + ") REFERENCES " + TABLE_ORDERS + "(" + COLUMN_ORDER_ID + "),"
                + "FOREIGN KEY(" + COLUMN_ORDER_DETAIL_MENU_ID + ") REFERENCES " + TABLE_MENU_ITEMS + "(" + COLUMN_MENU_ID + ")"
                + ")";
        db.execSQL(createOrderDetailsTable);

        // Create Favorites Table
        String createFavoritesTable = "CREATE TABLE " + TABLE_FAVORITES + "("
                + COLUMN_FAVORITE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_FAVORITE_USER_ID + " INTEGER,"
                + COLUMN_FAVORITE_MENU_ID + " INTEGER,"
                + "FOREIGN KEY(" + COLUMN_FAVORITE_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + "),"
                + "FOREIGN KEY(" + COLUMN_FAVORITE_MENU_ID + ") REFERENCES " + TABLE_MENU_ITEMS + "(" + COLUMN_MENU_ID + ")"
                + ")";
        db.execSQL(createFavoritesTable);

        // Create Search History Table
        String createSearchHistoryTable = "CREATE TABLE " + TABLE_SEARCH_HISTORY + "("
                + COLUMN_SEARCH_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_SEARCH_USER_ID + " INTEGER,"
                + COLUMN_SEARCH_QUERY + " TEXT,"
                + COLUMN_SEARCH_DATE + " TEXT,"
                + "FOREIGN KEY(" + COLUMN_SEARCH_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + ")"
                + ")";
        db.execSQL(createSearchHistoryTable);

        // Create Vouchers Table
        String createVouchersTable = "CREATE TABLE " + TABLE_VOUCHERS + "("
                + COLUMN_VOUCHER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_VOUCHER_CODE + " TEXT UNIQUE,"
                + COLUMN_VOUCHER_NAME + " TEXT,"
                + COLUMN_VOUCHER_DESCRIPTION + " TEXT,"
                + COLUMN_VOUCHER_DISCOUNT_PERCENT + " INTEGER,"
                + COLUMN_VOUCHER_DISCOUNT_AMOUNT + " REAL,"
                + COLUMN_VOUCHER_MIN_PURCHASE + " REAL,"
                + COLUMN_VOUCHER_VALID_UNTIL + " TEXT,"
                + COLUMN_VOUCHER_IS_ACTIVE + " INTEGER DEFAULT 1,"
                + COLUMN_VOUCHER_IMAGE + " INTEGER"
                + ")";
        db.execSQL(createVouchersTable);

        // Create Memberships Table
        String createMembershipsTable = "CREATE TABLE " + TABLE_MEMBERSHIPS + "("
                + COLUMN_MEMBERSHIP_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_MEMBERSHIP_USER_ID + " INTEGER,"
                + COLUMN_MEMBERSHIP_TYPE + " TEXT,"
                + COLUMN_MEMBERSHIP_POINTS + " INTEGER DEFAULT 0,"
                + COLUMN_MEMBERSHIP_JOIN_DATE + " TEXT,"
                + COLUMN_MEMBERSHIP_EXPIRED_DATE + " TEXT,"
                + "FOREIGN KEY(" + COLUMN_MEMBERSHIP_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + ")"
                + ")";
        db.execSQL(createMembershipsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MENU_ITEMS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CART);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ORDERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ORDER_DETAILS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FAVORITES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SEARCH_HISTORY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_VOUCHERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MEMBERSHIPS);
        onCreate(db);
    }

    // ==================== USER METHODS ====================

    public long addUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_NAME, user.getUsername());
        values.put(COLUMN_USER_EMAIL, user.getEmail());
        values.put(COLUMN_USER_PHONE, user.getPhone());
        values.put(COLUMN_USER_PASSWORD, user.getPassword());
        values.put(COLUMN_USER_IS_ADMIN, user.isAdmin() ? 1 : 0);

        long id = db.insert(TABLE_USERS, null, values);
        db.close();
        return id;
    }

    public User getUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_USER_ID, COLUMN_USER_NAME, COLUMN_USER_EMAIL,
                        COLUMN_USER_PHONE, COLUMN_USER_PASSWORD, COLUMN_USER_IS_ADMIN},
                COLUMN_USER_EMAIL + "=? AND " + COLUMN_USER_PASSWORD + "=?",
                new String[]{email, password}, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            User user = new User(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getString(3),
                    cursor.getString(4),
                    cursor.getInt(5) == 1
            );
            cursor.close();
            db.close();
            return user;
        }

        if (cursor != null) cursor.close();
        db.close();
        return null;
    }

    public User getUserById(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_USER_ID, COLUMN_USER_NAME, COLUMN_USER_EMAIL,
                        COLUMN_USER_PHONE, COLUMN_USER_PASSWORD, COLUMN_USER_IS_ADMIN},
                COLUMN_USER_ID + "=?",
                new String[]{String.valueOf(userId)}, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            User user = new User(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getString(3),
                    cursor.getString(4),
                    cursor.getInt(5) == 1
            );
            cursor.close();
            db.close();
            return user;
        }

        if (cursor != null) cursor.close();
        db.close();
        return null;
    }

    public boolean checkUserEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_USER_ID},
                COLUMN_USER_EMAIL + "=?",
                new String[]{email}, null, null, null);

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    public int updateUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_NAME, user.getUsername());
        values.put(COLUMN_USER_EMAIL, user.getEmail());
        values.put(COLUMN_USER_PHONE, user.getPhone());

        int result = db.update(TABLE_USERS, values,
                COLUMN_USER_ID + "=?",
                new String[]{String.valueOf(user.getId())});
        db.close();
        return result;
    }

    // ==================== MENU ITEM METHODS ====================

    public long addMenuItem(MenuItem menuItem) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_MENU_NAME, menuItem.getName());
        values.put(COLUMN_MENU_DESCRIPTION, menuItem.getDescription());
        values.put(COLUMN_MENU_PRICE, menuItem.getPrice());
        values.put(COLUMN_MENU_CATEGORY, menuItem.getCategory());
        values.put(COLUMN_MENU_IMAGE, menuItem.getImageResource());
        values.put(COLUMN_MENU_RATING, menuItem.getRating());
        values.put(COLUMN_MENU_DISCOUNT, menuItem.getDiscount());
        values.put(COLUMN_MENU_AVAILABLE, menuItem.isAvailable() ? 1 : 0);

        long id = db.insert(TABLE_MENU_ITEMS, null, values);
        db.close();
        return id;
    }

    public List<MenuItem> getAllMenuItems() {
        List<MenuItem> menuItems = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_MENU_ITEMS +
                " WHERE " + COLUMN_MENU_AVAILABLE + "=1", null);

        if (cursor.moveToFirst()) {
            do {
                MenuItem item = new MenuItem(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getDouble(3),
                        cursor.getString(4),
                        cursor.getInt(5),
                        cursor.getFloat(6),
                        cursor.getInt(7),
                        cursor.getInt(8) == 1
                );
                menuItems.add(item);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return menuItems;
    }

    public List<MenuItem> getMenuItemsByCategory(String category) {
        List<MenuItem> menuItems = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_MENU_ITEMS,
                null,
                COLUMN_MENU_CATEGORY + "=? AND " + COLUMN_MENU_AVAILABLE + "=1",
                new String[]{category}, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                MenuItem item = new MenuItem(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getDouble(3),
                        cursor.getString(4),
                        cursor.getInt(5),
                        cursor.getFloat(6),
                        cursor.getInt(7),
                        cursor.getInt(8) == 1
                );
                menuItems.add(item);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return menuItems;
    }

    public List<MenuItem> searchMenuItems(String query) {
        List<MenuItem> menuItems = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_MENU_ITEMS,
                null,
                COLUMN_MENU_NAME + " LIKE ? AND " + COLUMN_MENU_AVAILABLE + "=1",
                new String[]{"%" + query + "%"}, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                MenuItem item = new MenuItem(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getDouble(3),
                        cursor.getString(4),
                        cursor.getInt(5),
                        cursor.getFloat(6),
                        cursor.getInt(7),
                        cursor.getInt(8) == 1
                );
                menuItems.add(item);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return menuItems;
    }

    public List<MenuItem> getDiscountedItems() {
        List<MenuItem> menuItems = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_MENU_ITEMS,
                null,
                COLUMN_MENU_DISCOUNT + " > 0 AND " + COLUMN_MENU_AVAILABLE + "=1",
                null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                MenuItem item = new MenuItem(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getDouble(3),
                        cursor.getString(4),
                        cursor.getInt(5),
                        cursor.getFloat(6),
                        cursor.getInt(7),
                        cursor.getInt(8) == 1
                );
                menuItems.add(item);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return menuItems;
    }

    public MenuItem getMenuItemById(int menuId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_MENU_ITEMS,
                null,
                COLUMN_MENU_ID + "=?",
                new String[]{String.valueOf(menuId)}, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            MenuItem item = new MenuItem(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getDouble(3),
                    cursor.getString(4),
                    cursor.getInt(5),
                    cursor.getFloat(6),
                    cursor.getInt(7),
                    cursor.getInt(8) == 1
            );
            cursor.close();
            db.close();
            return item;
        }

        if (cursor != null) cursor.close();
        db.close();
        return null;
    }

    // ==================== CART METHODS ====================

    public long addToCart(CartItem cartItem) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Check if item already exists in cart
        Cursor cursor = db.query(TABLE_CART,
                new String[]{COLUMN_CART_ID, COLUMN_CART_QUANTITY},
                COLUMN_CART_USER_ID + "=? AND " + COLUMN_CART_MENU_ID + "=?",
                new String[]{String.valueOf(cartItem.getUserId()),
                        String.valueOf(cartItem.getMenuItemId())},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            // Update quantity
            int existingId = cursor.getInt(0);
            int existingQuantity = cursor.getInt(1);
            ContentValues values = new ContentValues();
            values.put(COLUMN_CART_QUANTITY, existingQuantity + cartItem.getQuantity());
            cursor.close();
            db.update(TABLE_CART, values, COLUMN_CART_ID + "=?",
                    new String[]{String.valueOf(existingId)});
            db.close();
            return existingId;
        }

        if (cursor != null) cursor.close();

        // Add new item
        ContentValues values = new ContentValues();
        values.put(COLUMN_CART_USER_ID, cartItem.getUserId());
        values.put(COLUMN_CART_MENU_ID, cartItem.getMenuItemId());
        values.put(COLUMN_CART_MENU_NAME, cartItem.getMenuName());
        values.put(COLUMN_CART_MENU_PRICE, cartItem.getMenuPrice());
        values.put(COLUMN_CART_MENU_IMAGE, cartItem.getMenuImage());
        values.put(COLUMN_CART_QUANTITY, cartItem.getQuantity());
        values.put(COLUMN_CART_NOTES, cartItem.getNotes());

        long id = db.insert(TABLE_CART, null, values);
        db.close();
        return id;
    }

    public List<CartItem> getCartItems(int userId) {
        List<CartItem> cartItems = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_CART,
                null,
                COLUMN_CART_USER_ID + "=?",
                new String[]{String.valueOf(userId)}, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                CartItem item = new CartItem(
                        cursor.getInt(0),
                        cursor.getInt(1),
                        cursor.getInt(2),
                        cursor.getString(3),
                        cursor.getDouble(4),
                        cursor.getInt(5),
                        cursor.getInt(6),
                        cursor.getString(7)
                );
                cartItems.add(item);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return cartItems;
    }

    public int updateCartItemQuantity(int cartItemId, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_CART_QUANTITY, quantity);

        int result = db.update(TABLE_CART, values,
                COLUMN_CART_ID + "=?",
                new String[]{String.valueOf(cartItemId)});
        db.close();
        return result;
    }

    public void deleteCartItem(int cartItemId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_CART, COLUMN_CART_ID + "=?",
                new String[]{String.valueOf(cartItemId)});
        db.close();
    }

    public void clearCart(int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_CART, COLUMN_CART_USER_ID + "=?",
                new String[]{String.valueOf(userId)});
        db.close();
    }

    public int getCartItemCount(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT SUM(" + COLUMN_CART_QUANTITY + ") FROM "
                        + TABLE_CART + " WHERE " + COLUMN_CART_USER_ID + "=?",
                new String[]{String.valueOf(userId)});

        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        db.close();
        return count;
    }

    // ==================== ORDER METHODS ====================

    public long addOrder(Order order) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ORDER_USER_ID, order.getUserId());
        values.put(COLUMN_ORDER_DATE, order.getOrderDate());
        values.put(COLUMN_ORDER_TOTAL, order.getTotalAmount());
        values.put(COLUMN_ORDER_STATUS, order.getStatus());
        values.put(COLUMN_ORDER_ADDRESS, order.getDeliveryAddress());
        values.put(COLUMN_ORDER_PAYMENT, order.getPaymentMethod());

        long id = db.insert(TABLE_ORDERS, null, values);
        db.close();
        return id;
    }

    public long addOrderDetail(OrderDetail orderDetail) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ORDER_DETAIL_ORDER_ID, orderDetail.getOrderId());
        values.put(COLUMN_ORDER_DETAIL_MENU_ID, orderDetail.getMenuItemId());
        values.put(COLUMN_ORDER_DETAIL_MENU_NAME, orderDetail.getMenuName());
        values.put(COLUMN_ORDER_DETAIL_QUANTITY, orderDetail.getQuantity());
        values.put(COLUMN_ORDER_DETAIL_PRICE, orderDetail.getPrice());

        long id = db.insert(TABLE_ORDER_DETAILS, null, values);
        db.close();
        return id;
    }

    public List<Order> getUserOrders(int userId) {
        List<Order> orders = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_ORDERS,
                null,
                COLUMN_ORDER_USER_ID + "=?",
                new String[]{String.valueOf(userId)},
                null, null, COLUMN_ORDER_ID + " DESC");

        if (cursor.moveToFirst()) {
            do {
                Order order = new Order(
                        cursor.getInt(0),
                        cursor.getInt(1),
                        cursor.getString(2),
                        cursor.getDouble(3),
                        cursor.getString(4),
                        cursor.getString(5),
                        cursor.getString(6)
                );
                orders.add(order);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return orders;
    }

    public List<OrderDetail> getOrderDetails(int orderId) {
        List<OrderDetail> orderDetails = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_ORDER_DETAILS,
                null,
                COLUMN_ORDER_DETAIL_ORDER_ID + "=?",
                new String[]{String.valueOf(orderId)}, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                OrderDetail detail = new OrderDetail(
                        cursor.getInt(0),
                        cursor.getInt(1),
                        cursor.getInt(2),
                        cursor.getString(3),
                        cursor.getInt(4),
                        cursor.getDouble(5)
                );
                orderDetails.add(detail);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return orderDetails;
    }

    // ==================== FAVORITE METHODS ====================

    public long addFavorite(Favorite favorite) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_FAVORITE_USER_ID, favorite.getUserId());
        values.put(COLUMN_FAVORITE_MENU_ID, favorite.getMenuItemId());

        long id = db.insert(TABLE_FAVORITES, null, values);
        db.close();
        return id;
    }

    public void removeFavorite(int userId, int menuItemId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_FAVORITES,
                COLUMN_FAVORITE_USER_ID + "=? AND " + COLUMN_FAVORITE_MENU_ID + "=?",
                new String[]{String.valueOf(userId), String.valueOf(menuItemId)});
        db.close();
    }

    public boolean isFavorite(int userId, int menuItemId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_FAVORITES,
                new String[]{COLUMN_FAVORITE_ID},
                COLUMN_FAVORITE_USER_ID + "=? AND " + COLUMN_FAVORITE_MENU_ID + "=?",
                new String[]{String.valueOf(userId), String.valueOf(menuItemId)},
                null, null, null);

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    public List<MenuItem> getFavoriteMenuItems(int userId) {
        List<MenuItem> menuItems = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT m.* FROM " + TABLE_MENU_ITEMS + " m " +
                "INNER JOIN " + TABLE_FAVORITES + " f ON m." + COLUMN_MENU_ID +
                " = f." + COLUMN_FAVORITE_MENU_ID +
                " WHERE f." + COLUMN_FAVORITE_USER_ID + "=?";

        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId)});

        if (cursor.moveToFirst()) {
            do {
                MenuItem item = new MenuItem(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getDouble(3),
                        cursor.getString(4),
                        cursor.getInt(5),
                        cursor.getFloat(6),
                        cursor.getInt(7),
                        cursor.getInt(8) == 1
                );
                menuItems.add(item);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return menuItems;
    }

    // ==================== SEARCH HISTORY METHODS ====================

    public long addSearchHistory(int userId, String query, String date) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Check if query already exists for this user
        Cursor cursor = db.query(TABLE_SEARCH_HISTORY,
                new String[]{COLUMN_SEARCH_ID},
                COLUMN_SEARCH_USER_ID + "=? AND " + COLUMN_SEARCH_QUERY + "=?",
                new String[]{String.valueOf(userId), query},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            // Update date
            int existingId = cursor.getInt(0);
            ContentValues values = new ContentValues();
            values.put(COLUMN_SEARCH_DATE, date);
            cursor.close();
            db.update(TABLE_SEARCH_HISTORY, values,
                    COLUMN_SEARCH_ID + "=?",
                    new String[]{String.valueOf(existingId)});
            db.close();
            return existingId;
        }

        if (cursor != null) cursor.close();

        // Add new search history
        ContentValues values = new ContentValues();
        values.put(COLUMN_SEARCH_USER_ID, userId);
        values.put(COLUMN_SEARCH_QUERY, query);
        values.put(COLUMN_SEARCH_DATE, date);

        long id = db.insert(TABLE_SEARCH_HISTORY, null, values);
        db.close();
        return id;
    }

    public List<String> getSearchHistory(int userId) {
        List<String> history = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_SEARCH_HISTORY,
                new String[]{COLUMN_SEARCH_QUERY},
                COLUMN_SEARCH_USER_ID + "=?",
                new String[]{String.valueOf(userId)},
                null, null, COLUMN_SEARCH_DATE + " DESC", "10");

        if (cursor.moveToFirst()) {
            do {
                history.add(cursor.getString(0));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return history;
    }

    public void clearSearchHistory(int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_SEARCH_HISTORY,
                COLUMN_SEARCH_USER_ID + "=?",
                new String[]{String.valueOf(userId)});
        db.close();
    }

    public void deleteSearchHistoryItem(int userId, String query) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_SEARCH_HISTORY,
                COLUMN_SEARCH_USER_ID + "=? AND " + COLUMN_SEARCH_QUERY + "=?",
                new String[]{String.valueOf(userId), query});
        db.close();
    }

    // ==================== ADMIN METHODS ====================

    public List<Order> getAllOrders() {
        List<Order> orders = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_ORDERS,
                null, null, null, null, null,
                COLUMN_ORDER_ID + " DESC");

        if (cursor.moveToFirst()) {
            do {
                Order order = new Order(
                        cursor.getInt(0),
                        cursor.getInt(1),
                        cursor.getString(2),
                        cursor.getDouble(3),
                        cursor.getString(4),
                        cursor.getString(5),
                        cursor.getString(6)
                );
                orders.add(order);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return orders;
    }

    // ==================== VOUCHER METHODS ====================

    public long addVoucher(Voucher voucher) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_VOUCHER_CODE, voucher.getCode());
        values.put(COLUMN_VOUCHER_NAME, voucher.getName());
        values.put(COLUMN_VOUCHER_DESCRIPTION, voucher.getDescription());
        values.put(COLUMN_VOUCHER_DISCOUNT_PERCENT, voucher.getDiscountPercent());
        values.put(COLUMN_VOUCHER_DISCOUNT_AMOUNT, voucher.getDiscountAmount());
        values.put(COLUMN_VOUCHER_MIN_PURCHASE, voucher.getMinPurchase());
        values.put(COLUMN_VOUCHER_VALID_UNTIL, voucher.getValidUntil());
        values.put(COLUMN_VOUCHER_IS_ACTIVE, voucher.isActive() ? 1 : 0);
        values.put(COLUMN_VOUCHER_IMAGE, voucher.getImageResource());

        long id = db.insert(TABLE_VOUCHERS, null, values);
        db.close();
        return id;
    }

    public List<Voucher> getAllVouchers() {
        List<Voucher> vouchers = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_VOUCHERS, null,
                COLUMN_VOUCHER_IS_ACTIVE + "=1", null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                Voucher voucher = new Voucher(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getInt(4),
                        cursor.getDouble(5),
                        cursor.getDouble(6),
                        cursor.getString(7),
                        cursor.getInt(8) == 1,
                        cursor.getInt(9)
                );
                vouchers.add(voucher);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return vouchers;
    }

    public Voucher getVoucherByCode(String code) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_VOUCHERS, null,
                COLUMN_VOUCHER_CODE + "=? AND " + COLUMN_VOUCHER_IS_ACTIVE + "=1",
                new String[]{code}, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            Voucher voucher = new Voucher(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getString(3),
                    cursor.getInt(4),
                    cursor.getDouble(5),
                    cursor.getDouble(6),
                    cursor.getString(7),
                    cursor.getInt(8) == 1,
                    cursor.getInt(9)
            );
            cursor.close();
            db.close();
            return voucher;
        }

        if (cursor != null) cursor.close();
        db.close();
        return null;
    }

    // ==================== MEMBERSHIP METHODS ====================

        public long addMembership(Membership membership) {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COLUMN_MEMBERSHIP_USER_ID, membership.getUserId());
            values.put(COLUMN_MEMBERSHIP_TYPE, membership.getMemberType());
            values.put(COLUMN_MEMBERSHIP_POINTS, membership.getPoints());
            values.put(COLUMN_MEMBERSHIP_JOIN_DATE, membership.getJoinDate());
            values.put(COLUMN_MEMBERSHIP_EXPIRED_DATE, membership.getExpiredDate());

            long id = db.insert(TABLE_MEMBERSHIPS, null, values);
            db.close();
            return id;
        }

        public Membership getMembershipByUserId(int userId) {
            SQLiteDatabase db = this.getReadableDatabase();
            Cursor cursor = db.query(TABLE_MEMBERSHIPS, null,
                    COLUMN_MEMBERSHIP_USER_ID + "=?",
                    new String[]{String.valueOf(userId)}, null, null, null);

            if (cursor != null && cursor.moveToFirst()) {
                Membership membership = new Membership(
                        cursor.getInt(0),
                        cursor.getInt(1),
                        cursor.getString(2),
                        cursor.getInt(3),
                        cursor.getString(4),
                        cursor.getString(5)
                );
                cursor.close();
                db.close();
                return membership;
            }

            if (cursor != null) cursor.close();
            db.close();
            return null;
        }

    public int updateMembershipPoints(int userId, int points) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_MEMBERSHIP_POINTS, points);

        int result = db.update(TABLE_MEMBERSHIPS, values,
                COLUMN_MEMBERSHIP_USER_ID + "=?",
                new String[]{String.valueOf(userId)});
        db.close();
        return result;
    }

    public int updateOrderStatus(int orderId, String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ORDER_STATUS, status);

        int result = db.update(TABLE_ORDERS, values,
                COLUMN_ORDER_ID + "=?",
                new String[]{String.valueOf(orderId)});
        db.close();
        return result;
    }

    public int updateMenuItem(MenuItem menuItem) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_MENU_NAME, menuItem.getName());
        values.put(COLUMN_MENU_DESCRIPTION, menuItem.getDescription());
        values.put(COLUMN_MENU_PRICE, menuItem.getPrice());
        values.put(COLUMN_MENU_CATEGORY, menuItem.getCategory());
        values.put(COLUMN_MENU_IMAGE, menuItem.getImageResource());
        values.put(COLUMN_MENU_RATING, menuItem.getRating());
        values.put(COLUMN_MENU_DISCOUNT, menuItem.getDiscount());
        values.put(COLUMN_MENU_AVAILABLE, menuItem.isAvailable() ? 1 : 0);

        int result = db.update(TABLE_MENU_ITEMS, values,
                COLUMN_MENU_ID + "=?",
                new String[]{String.valueOf(menuItem.getId())});
        db.close();
        return result;
    }

    public void deleteMenuItem(int menuItemId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_MENU_ITEMS, COLUMN_MENU_ID + "=?",
                new String[]{String.valueOf(menuItemId)});
        db.close();
    }
}