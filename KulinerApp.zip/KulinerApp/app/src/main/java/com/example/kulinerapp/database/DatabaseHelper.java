package com.example.kulinerapp.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.kulinerapp.models.*;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "KulinerApp.db";
    private static final int DATABASE_VERSION = 4; // Naikkan versi biar migrasi jalan otomatis

    // ==================== TABLE USERS ====================
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "id";
    private static final String COLUMN_USER_NAME = "username";
    private static final String COLUMN_USER_EMAIL = "email";
    private static final String COLUMN_USER_PHONE = "phone";
    private static final String COLUMN_USER_PASSWORD = "password";
    private static final String COLUMN_USER_IS_ADMIN = "is_admin";

    // ==================== TABLE MENU ITEMS (BARU: image_path TEXT) ====================
    private static final String TABLE_MENU_ITEMS = "menu_items";
    private static final String COLUMN_MENU_ID = "id";
    private static final String COLUMN_MENU_NAME = "name";
    private static final String COLUMN_MENU_DESCRIPTION = "description";
    private static final String COLUMN_MENU_PRICE = "price";
    private static final String COLUMN_MENU_CATEGORY = "category";
    private static final String COLUMN_MENU_IMAGE_PATH = "image_path";     // BARU: TEXT
    private static final String COLUMN_MENU_RATING = "rating";
    private static final String COLUMN_MENU_DISCOUNT = "discount";
    private static final String COLUMN_MENU_AVAILABLE = "is_available";

    // ==================== TABLE CART ====================
    private static final String TABLE_CART = "cart";
    private static final String COLUMN_CART_ID = "id";
    private static final String COLUMN_CART_USER_ID = "user_id";
    private static final String COLUMN_CART_MENU_ID = "menu_item_id";
    private static final String COLUMN_CART_MENU_NAME = "menu_name";
    private static final String COLUMN_CART_MENU_PRICE = "menu_price";
    private static final String COLUMN_CART_MENU_IMAGE = "menu_image"; // masih int (drawable)
    private static final String COLUMN_CART_QUANTITY = "quantity";
    private static final String COLUMN_CART_NOTES = "notes";

    // ==================== ORDERS & ORDER DETAILS ====================
    private static final String TABLE_ORDERS = "orders";
    private static final String COLUMN_ORDER_ID = "id";
    private static final String COLUMN_ORDER_USER_ID = "user_id";
    private static final String COLUMN_ORDER_DATE = "order_date";
    private static final String COLUMN_ORDER_TOTAL = "total_amount";
    private static final String COLUMN_ORDER_STATUS = "status";
    private static final String COLUMN_ORDER_ADDRESS = "delivery_address";
    private static final String COLUMN_ORDER_PAYMENT = "payment_method";

    private static final String TABLE_ORDER_DETAILS = "order_details";
    private static final String COLUMN_ORDER_DETAIL_ID = "id";
    private static final String COLUMN_ORDER_DETAIL_ORDER_ID = "order_id";
    private static final String COLUMN_ORDER_DETAIL_MENU_ID = "menu_item_id";
    private static final String COLUMN_ORDER_DETAIL_MENU_NAME = "menu_name";
    private static final String COLUMN_ORDER_DETAIL_QUANTITY = "quantity";
    private static final String COLUMN_ORDER_DETAIL_PRICE = "price";

    // ==================== FAVORITES, SEARCH, VOUCHER, MEMBERSHIP ====================
    private static final String TABLE_FAVORITES = "favorites";
    private static final String COLUMN_FAVORITE_ID = "id";
    private static final String COLUMN_FAVORITE_USER_ID = "user_id";
    private static final String COLUMN_FAVORITE_MENU_ID = "menu_item_id";

    private static final String TABLE_SEARCH_HISTORY = "search_history";
    private static final String COLUMN_SEARCH_ID = "id";
    private static final String COLUMN_SEARCH_USER_ID = "user_id";
    private static final String COLUMN_SEARCH_QUERY = "query";
    private static final String COLUMN_SEARCH_DATE = "search_date";

    private static final String TABLE_VOUCHERS = "vouchers";
    private static final String COLUMN_VOUCHER_ID = "id";
    private static final String COLUMN_VOUCHER_CODE = "code";
    private static final String COLUMN_VOUCHER_NAME = "name";
    private static final String COLUMN_VOUCHER_DESCRIPTION = "description";
    private static final String COLUMN_VOUCHER_DISCOUNT_PERCENT = "discount_percent";
    private static final String COLUMN_VOUCHER_DISCOUNT_AMOUNT = "discount_amount";
    private static final String COLUMN_VOUCHER_MIN_PURCHASE = "min_purchase";
    private static final String COLUMN_VOUCHER_VALID_UNTIL = "valid_until";
    private static final String COLUMN_VOUCHER_IS_ACTIVE = "is_active";
    private static final String COLUMN_VOUCHER_IMAGE = "image_resource";

    private static final String TABLE_MEMBERSHIPS = "memberships";
    private static final String COLUMN_MEMBERSHIP_ID = "id";
    private static final String COLUMN_MEMBERSHIP_USER_ID = "user_id";
    private static final String COLUMN_MEMBERSHIP_TYPE = "member_type";
    private static final String COLUMN_MEMBERSHIP_POINTS = "points";
    private static final String COLUMN_MEMBERSHIP_JOIN_DATE = "join_date";
    private static final String COLUMN_MEMBERSHIP_EXPIRED_DATE = "expired_date";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // === USERS ===
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_USERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT, " +
                "email TEXT UNIQUE, " +
                "phone TEXT, " +
                "password TEXT, " +
                "is_admin INTEGER DEFAULT 0)");

        // === MENU ITEMS (image_path TEXT) ===
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_MENU_ITEMS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT, " +
                "description TEXT, " +
                "price REAL, " +
                "category TEXT, " +
                "image_path TEXT, " +
                "rating REAL DEFAULT 4.8, " +
                "discount INTEGER DEFAULT 0, " +
                "is_available INTEGER DEFAULT 1)");

        // === CART ===
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_CART + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER, " +
                "menu_item_id INTEGER, " +
                "menu_name TEXT, " +
                "menu_price REAL, " +
                "menu_image INTEGER, " +
                "quantity INTEGER DEFAULT 1, " +
                "notes TEXT)");

        // === ORDERS ===
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_ORDERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER, " +
                "order_date TEXT, " +
                "total_amount REAL, " +
                "status TEXT, " +
                "delivery_address TEXT, " +
                "payment_method TEXT)");

        // === ORDER DETAILS ===
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_ORDER_DETAILS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "order_id INTEGER, " +
                "menu_item_id INTEGER, " +
                "menu_name TEXT, " +
                "quantity INTEGER, " +
                "price REAL)");

        // === FAVORITES ===
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_FAVORITES + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER, " +
                "menu_item_id INTEGER)");

        // === SEARCH HISTORY ===
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_SEARCH_HISTORY + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER, " +
                "query TEXT, " +
                "search_date TEXT)");

        // === VOUCHERS ===
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_VOUCHERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "code TEXT UNIQUE, " +
                "name TEXT, " +
                "description TEXT, " +
                "discount_percent INTEGER, " +
                "discount_amount REAL, " +
                "min_purchase REAL, " +
                "valid_until TEXT, " +
                "is_active INTEGER DEFAULT 1, " +
                "image_resource INTEGER)");

        // === MEMBERSHIPS ===
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_MEMBERSHIPS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER, " +
                "member_type TEXT, " +
                "points INTEGER DEFAULT 0, " +
                "join_date TEXT, " +
                "expired_date TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 4) {
            // Migrasi otomatis: image_resource (INTEGER) → image_path (TEXT)
            db.execSQL("ALTER TABLE " + TABLE_MENU_ITEMS + " RENAME TO temp_menu");
            db.execSQL("CREATE TABLE " + TABLE_MENU_ITEMS + "(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, description TEXT, price REAL, category TEXT, image_path TEXT, rating REAL DEFAULT 4.8, discount INTEGER DEFAULT 0, is_available INTEGER DEFAULT 1)");
            db.execSQL("INSERT INTO " + TABLE_MENU_ITEMS + " SELECT id, name, description, price, category, NULL, rating, discount, is_available FROM temp_menu");
            db.execSQL("DROP TABLE temp_menu");
        }
    }

    public long addUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_NAME, user.getUsername());
        values.put(COLUMN_USER_EMAIL, user.getEmail());
        values.put(COLUMN_USER_PHONE, user.getPhone());
        values.put(COLUMN_USER_PASSWORD, user.getPassword());
        values.put(COLUMN_USER_IS_ADMIN, user.isAdmin() ? 1 : 0);
        long id = db.insert(TABLE_USERS, null, values);
        db.close();
        return id;
    }

    public User getUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{COLUMN_USER_ID, COLUMN_USER_NAME, COLUMN_USER_EMAIL, COLUMN_USER_PHONE, COLUMN_USER_PASSWORD, COLUMN_USER_IS_ADMIN},
                COLUMN_USER_EMAIL + "=? AND " + COLUMN_USER_PASSWORD + "=?", new String[]{email, password}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            User user = new User(cursor.getInt(0), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getInt(5) == 1);
            cursor.close();
            db.close();
            return user;
        }
        if (cursor != null) cursor.close();
        db.close();
        return null;
    }

    public boolean updatePassword(int userId, String oldPassword, String newPassword) {
        SQLiteDatabase db = this.getReadableDatabase();

        // Cek password lama benar atau tidak
        Cursor cursor = db.rawQuery("SELECT " + COLUMN_USER_PASSWORD + " FROM " + TABLE_USERS + " WHERE " + COLUMN_USER_ID + " = ?",
                new String[]{String.valueOf(userId)});

        if (cursor.moveToFirst()) {
            String currentPassword = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_PASSWORD));
            cursor.close();

            if (currentPassword.equals(oldPassword)) {
                SQLiteDatabase dbWrite = this.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put(COLUMN_USER_PASSWORD, newPassword);

                int result = dbWrite.update(TABLE_USERS, values, COLUMN_USER_ID + " = ?",
                        new String[]{String.valueOf(userId)});
                dbWrite.close();
                return result > 0;
            }
        }

        if (cursor != null && !cursor.isClosed()) cursor.close();
        db.close();
        return false;
    }

    public User getUserById(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_USER_ID, COLUMN_USER_NAME, COLUMN_USER_EMAIL, COLUMN_USER_PHONE, COLUMN_USER_PASSWORD, COLUMN_USER_IS_ADMIN},
                COLUMN_USER_ID + " = ?", new String[]{String.valueOf(userId)}, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            User user = new User(
                    cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_USER_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_NAME)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_EMAIL)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_PHONE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_PASSWORD)),
                    cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_USER_IS_ADMIN)) == 1
            );
            cursor.close();
            db.close();
            return user;
        }

        if (cursor != null) cursor.close();
        db.close();
        return null;
    }

    public int updateUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_NAME, user.getUsername());
        values.put(COLUMN_USER_EMAIL, user.getEmail());
        values.put(COLUMN_USER_PHONE, user.getPhone());
        // password & is_admin tidak diubah di edit profile

        int result = db.update(TABLE_USERS, values, COLUMN_USER_ID + " = ?",
                new String[]{String.valueOf(user.getId())});

        db.close();
        return result;
    }

    public long addMenuItem(MenuItem menuItem) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_MENU_NAME, menuItem.getName());
        values.put(COLUMN_MENU_DESCRIPTION, menuItem.getDescription());
        values.put(COLUMN_MENU_PRICE, menuItem.getPrice());
        values.put(COLUMN_MENU_CATEGORY, menuItem.getCategory());
        values.put(COLUMN_MENU_IMAGE_PATH, menuItem.getImagePath()); // BARU
        values.put(COLUMN_MENU_RATING, menuItem.getRating());
        values.put(COLUMN_MENU_DISCOUNT, menuItem.getDiscount());
        values.put(COLUMN_MENU_AVAILABLE, menuItem.isAvailable() ? 1 : 0);
        long id = db.insert(TABLE_MENU_ITEMS, null, values);
        db.close();
        return id;
    }

    public List<MenuItem> getAllMenuItems() {
        List<MenuItem> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + TABLE_MENU_ITEMS, null);
        if (c.moveToFirst()) {
            do {
                MenuItem item = new MenuItem(
                        c.getInt(c.getColumnIndexOrThrow(COLUMN_MENU_ID)),
                        c.getString(c.getColumnIndexOrThrow(COLUMN_MENU_NAME)),
                        c.getString(c.getColumnIndexOrThrow(COLUMN_MENU_DESCRIPTION)),
                        c.getDouble(c.getColumnIndexOrThrow(COLUMN_MENU_PRICE)),
                        c.getString(c.getColumnIndexOrThrow(COLUMN_MENU_CATEGORY)),
                        c.getString(c.getColumnIndexOrThrow(COLUMN_MENU_IMAGE_PATH)),
                        c.getFloat(c.getColumnIndexOrThrow(COLUMN_MENU_RATING)),
                        c.getInt(c.getColumnIndexOrThrow(COLUMN_MENU_DISCOUNT)),
                        c.getInt(c.getColumnIndexOrThrow(COLUMN_MENU_AVAILABLE)) == 1
                );
                list.add(item);
            } while (c.moveToNext());
        }
        c.close();
        db.close();
        return list;
    }

    public MenuItem getMenuItemById(int menuId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.query(TABLE_MENU_ITEMS, null, COLUMN_MENU_ID + "=?", new String[]{String.valueOf(menuId)}, null, null, null);
        if (c != null && c.moveToFirst()) {
            MenuItem item = new MenuItem(
                    c.getInt(c.getColumnIndexOrThrow(COLUMN_MENU_ID)),
                    c.getString(c.getColumnIndexOrThrow(COLUMN_MENU_NAME)),
                    c.getString(c.getColumnIndexOrThrow(COLUMN_MENU_DESCRIPTION)),
                    c.getDouble(c.getColumnIndexOrThrow(COLUMN_MENU_PRICE)),
                    c.getString(c.getColumnIndexOrThrow(COLUMN_MENU_CATEGORY)),
                    c.getString(c.getColumnIndexOrThrow(COLUMN_MENU_IMAGE_PATH)),
                    c.getFloat(c.getColumnIndexOrThrow(COLUMN_MENU_RATING)),
                    c.getInt(c.getColumnIndexOrThrow(COLUMN_MENU_DISCOUNT)),
                    c.getInt(c.getColumnIndexOrThrow(COLUMN_MENU_AVAILABLE)) == 1
            );
            c.close();
            db.close();
            return item;
        }
        if (c != null) c.close();
        db.close();
        return null;
    }

    public int updateMenuItem(MenuItem menuItem) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_MENU_NAME, menuItem.getName());
        cv.put(COLUMN_MENU_DESCRIPTION, menuItem.getDescription());
        cv.put(COLUMN_MENU_PRICE, menuItem.getPrice());
        cv.put(COLUMN_MENU_CATEGORY, menuItem.getCategory());
        cv.put(COLUMN_MENU_IMAGE_PATH, menuItem.getImagePath());
        cv.put(COLUMN_MENU_RATING, menuItem.getRating());
        cv.put(COLUMN_MENU_DISCOUNT, menuItem.getDiscount());
        cv.put(COLUMN_MENU_AVAILABLE, menuItem.isAvailable() ? 1 : 0);
        int rows = db.update(TABLE_MENU_ITEMS, cv, COLUMN_MENU_ID + "=?", new String[]{String.valueOf(menuItem.getId())});
        db.close();
        return rows;
    }

    public boolean deleteMenuItem(int menuItemId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_MENU_ITEMS, COLUMN_MENU_ID + "=?", new String[]{String.valueOf(menuItemId)});
        db.close();
        return rows > 0;
    }

    public boolean updateMenuAvailability(int menuId, boolean isAvailable) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_MENU_AVAILABLE, isAvailable ? 1 : 0);
        int rows = db.update(TABLE_MENU_ITEMS, cv, COLUMN_MENU_ID + "=?", new String[]{String.valueOf(menuId)});
        db.close();
        return rows > 0;
    }

    public int getCartItemCount(int userId) {
        int total = 0;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        try {
            String query = "SELECT SUM(quantity) FROM cart WHERE user_id = ?";
            cursor = db.rawQuery(query, new String[]{String.valueOf(userId)});

            if (cursor != null && cursor.moveToFirst()) {
                total = cursor.getInt(0); // Bisa null → jadi 0
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }

        return total;
    }

    public int getCartTotalItems(int userId) {
        int count = 0;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        try {
            String query = "SELECT COUNT(*) FROM cart WHERE user_id = ?";
            cursor = db.rawQuery(query, new String[]{String.valueOf(userId)});

            if (cursor != null && cursor.moveToFirst()) {
                count = cursor.getInt(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }

        return count;
    }

    public List<CartItem> getCartItems(int userId) {
        List<CartItem> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + TABLE_CART + " WHERE user_id = ? ORDER BY id DESC",
                new String[]{String.valueOf(userId)});

        if (c.moveToFirst()) {
            do {
                CartItem item = new CartItem(
                        c.getInt(c.getColumnIndexOrThrow(COLUMN_CART_ID)),
                        c.getInt(c.getColumnIndexOrThrow(COLUMN_CART_USER_ID)),
                        c.getInt(c.getColumnIndexOrThrow(COLUMN_CART_MENU_ID)),
                        c.getString(c.getColumnIndexOrThrow(COLUMN_CART_MENU_NAME)),
                        c.getDouble(c.getColumnIndexOrThrow(COLUMN_CART_MENU_PRICE)),
                        c.getString(c.getColumnIndexOrThrow(COLUMN_CART_MENU_IMAGE)),
                        c.getInt(c.getColumnIndexOrThrow(COLUMN_CART_QUANTITY)),
                        c.getString(c.getColumnIndexOrThrow(COLUMN_CART_NOTES))
                );
                list.add(item);
            } while (c.moveToNext());
        }
        c.close();
        db.close();
        return list;
    }

    public void updateCartItemQuantity(int cartId, int newQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_CART_QUANTITY, newQuantity);
        db.update(TABLE_CART, cv, COLUMN_CART_ID + "=?", new String[]{String.valueOf(cartId)});
        db.close();
    }

    public void updateCartItemNotes(int cartId, String notes) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_CART_NOTES, notes);
        db.update(TABLE_CART, cv, COLUMN_CART_ID + "=?", new String[]{String.valueOf(cartId)});
        db.close();
    }

    public void deleteCartItem(int cartId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_CART, COLUMN_CART_ID + "=?", new String[]{String.valueOf(cartId)});
        db.close();
    }

    public long addOrder(Order order) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_ORDER_USER_ID, order.getUserId());
        cv.put(COLUMN_ORDER_DATE, order.getOrderDate());
        cv.put(COLUMN_ORDER_TOTAL, order.getTotalAmount());
        cv.put(COLUMN_ORDER_STATUS, order.getStatus());
        cv.put(COLUMN_ORDER_ADDRESS, order.getDeliveryAddress());
        cv.put(COLUMN_ORDER_PAYMENT, order.getPaymentMethod());
        long id = db.insert(TABLE_ORDERS, null, cv);
        db.close();
        return id;
    }

    public void addOrderDetail(OrderDetail detail) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_ORDER_DETAIL_ORDER_ID, detail.getOrderId());
        cv.put(COLUMN_ORDER_DETAIL_MENU_ID, detail.getMenuItemId());
        cv.put(COLUMN_ORDER_DETAIL_MENU_NAME, detail.getMenuName());
        cv.put(COLUMN_ORDER_DETAIL_QUANTITY, detail.getQuantity());
        cv.put(COLUMN_ORDER_DETAIL_PRICE, detail.getPrice());
        db.insert(TABLE_ORDER_DETAILS, null, cv);
        db.close();
    }

    public void clearCart(int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_CART, COLUMN_CART_USER_ID + "=?", new String[]{String.valueOf(userId)});
        db.close();
    }

    public boolean addFavorite(int userId, int menuItemId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_FAVORITE_USER_ID, userId);
        cv.put(COLUMN_FAVORITE_MENU_ID, menuItemId);
        long result = db.insert(TABLE_FAVORITES, null, cv);
        db.close();
        return result != -1;
    }

    public boolean removeFavorite(int userId, int menuItemId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_FAVORITES,
                COLUMN_FAVORITE_USER_ID + " = ? AND " + COLUMN_FAVORITE_MENU_ID + " = ?",
                new String[]{String.valueOf(userId), String.valueOf(menuItemId)});
        db.close();
        return rows > 0;
    }

    public boolean isFavorite(int userId, int menuItemId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT 1 FROM " + TABLE_FAVORITES +
                " WHERE " + COLUMN_FAVORITE_USER_ID + " = ? AND " +
                COLUMN_FAVORITE_MENU_ID + " = ? LIMIT 1";

        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId), String.valueOf(menuItemId)});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    public List<MenuItem> getFavoriteMenuItems(int userId) {
        List<MenuItem> list = new ArrayList<>();
        String query = "SELECT mi.* FROM " + TABLE_MENU_ITEMS + " mi " +
                "INNER JOIN " + TABLE_FAVORITES + " f ON mi." + COLUMN_MENU_ID + " = f." + COLUMN_FAVORITE_MENU_ID +
                " WHERE f." + COLUMN_FAVORITE_USER_ID + " = ?";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(query, new String[]{String.valueOf(userId)});

        if (c.moveToFirst()) {
            do {
                MenuItem item = new MenuItem(
                        c.getInt(c.getColumnIndexOrThrow(COLUMN_MENU_ID)),
                        c.getString(c.getColumnIndexOrThrow(COLUMN_MENU_NAME)),
                        c.getString(c.getColumnIndexOrThrow(COLUMN_MENU_DESCRIPTION)),
                        c.getDouble(c.getColumnIndexOrThrow(COLUMN_MENU_PRICE)),
                        c.getString(c.getColumnIndexOrThrow(COLUMN_MENU_CATEGORY)),
                        c.getString(c.getColumnIndexOrThrow(COLUMN_MENU_IMAGE_PATH)),
                        c.getFloat(c.getColumnIndexOrThrow(COLUMN_MENU_RATING)),
                        c.getInt(c.getColumnIndexOrThrow(COLUMN_MENU_DISCOUNT)),
                        c.getInt(c.getColumnIndexOrThrow(COLUMN_MENU_AVAILABLE)) == 1
                );
                list.add(item);
            } while (c.moveToNext());
        }
        c.close();
        db.close();
        return list;
    }

    public long addToCart(CartItem cartItem) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_CART_USER_ID, cartItem.getUserId());
        cv.put(COLUMN_CART_MENU_ID, cartItem.getMenuItemId());
        cv.put(COLUMN_CART_MENU_NAME, cartItem.getMenuName());
        cv.put(COLUMN_CART_MENU_PRICE, cartItem.getMenuPrice());
        cv.put(COLUMN_CART_MENU_IMAGE, cartItem.getMenuImagePath());
        cv.put(COLUMN_CART_QUANTITY, cartItem.getQuantity());
        cv.put(COLUMN_CART_NOTES, cartItem.getNotes());

        long result = db.insert(TABLE_CART, null, cv);
        db.close();
        return result;
    }

    public Membership getMembershipByUserId(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_MEMBERSHIPS,
                null,
                COLUMN_MEMBERSHIP_USER_ID + " = ?",
                new String[]{String.valueOf(userId)},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            Membership membership = new Membership(
                    cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_MEMBERSHIP_ID)),
                    cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_MEMBERSHIP_USER_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MEMBERSHIP_TYPE)),
                    cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_MEMBERSHIP_POINTS)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MEMBERSHIP_JOIN_DATE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MEMBERSHIP_EXPIRED_DATE))
            );
            cursor.close();
            db.close();
            return membership;
        }

        if (cursor != null) cursor.close();
        db.close();
        return null;
    }

    public long addMembership(Membership membership) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_MEMBERSHIP_USER_ID, membership.getUserId());
        cv.put(COLUMN_MEMBERSHIP_TYPE, membership.getMemberType());
        cv.put(COLUMN_MEMBERSHIP_POINTS, membership.getPoints());
        cv.put(COLUMN_MEMBERSHIP_JOIN_DATE, membership.getJoinDate());
        cv.put(COLUMN_MEMBERSHIP_EXPIRED_DATE, membership.getExpiredDate());

        long result = db.insert(TABLE_MEMBERSHIPS, null, cv);
        db.close();
        return result;
    }

    public List<Order> getUserOrders(int userId) {
        List<Order> orderList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT * FROM " + TABLE_ORDERS +
                " WHERE " + COLUMN_ORDER_USER_ID + " = ? " +
                " ORDER BY " + COLUMN_ORDER_DATE + " DESC";

        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId)});

        if (cursor.moveToFirst()) {
            do {
                Order order = new Order(
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ORDER_ID)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ORDER_USER_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ORDER_DATE)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_ORDER_TOTAL)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ORDER_STATUS)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ORDER_ADDRESS)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ORDER_PAYMENT))
                );
                orderList.add(order);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return orderList;
    }

    public List<OrderDetail> getOrderDetails(int orderId) {
        List<OrderDetail> detailList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT * FROM " + TABLE_ORDER_DETAILS +
                " WHERE " + COLUMN_ORDER_DETAIL_ORDER_ID + " = ?" +
                " ORDER BY " + COLUMN_ORDER_DETAIL_ID;

        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(orderId)});

        if (cursor.moveToFirst()) {
            do {
                OrderDetail detail = new OrderDetail(
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ORDER_DETAIL_ID)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ORDER_DETAIL_ORDER_ID)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ORDER_DETAIL_MENU_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ORDER_DETAIL_MENU_NAME)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ORDER_DETAIL_QUANTITY)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_ORDER_DETAIL_PRICE))
                );
                detailList.add(detail);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return detailList;
    }

    public List<Voucher> getAllVouchers() {
        List<Voucher> voucherList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT * FROM " + TABLE_VOUCHERS +
                " WHERE " + COLUMN_VOUCHER_IS_ACTIVE + " = 1" +
                " ORDER BY " + COLUMN_VOUCHER_ID + " DESC";

        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                Voucher voucher = new Voucher(
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_VOUCHER_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_VOUCHER_CODE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_VOUCHER_NAME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_VOUCHER_DESCRIPTION)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_VOUCHER_DISCOUNT_PERCENT)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_VOUCHER_DISCOUNT_AMOUNT)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_VOUCHER_MIN_PURCHASE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_VOUCHER_VALID_UNTIL)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_VOUCHER_IS_ACTIVE)) == 1,
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_VOUCHER_IMAGE))
                );
                voucherList.add(voucher);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return voucherList;
    }

    public Voucher getVoucherByCode(String code) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_VOUCHERS,
                null,
                COLUMN_VOUCHER_CODE + " = ? AND " + COLUMN_VOUCHER_IS_ACTIVE + " = 1",
                new String[]{code},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            Voucher voucher = new Voucher(
                    cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_VOUCHER_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_VOUCHER_CODE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_VOUCHER_NAME)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_VOUCHER_DESCRIPTION)),
                    cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_VOUCHER_DISCOUNT_PERCENT)),
                    cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_VOUCHER_DISCOUNT_AMOUNT)),
                    cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_VOUCHER_MIN_PURCHASE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_VOUCHER_VALID_UNTIL)),
                    cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_VOUCHER_IS_ACTIVE)) == 1,
                    cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_VOUCHER_IMAGE))
            );
            cursor.close();
            db.close();
            return voucher;
        }

        if (cursor != null) cursor.close();
        db.close();
        return null;
    }

    public List<MenuItem> getMenuItemsByCategory(String category) {
        List<MenuItem> menuList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_MENU_ITEMS,
                null,
                COLUMN_MENU_CATEGORY + " = ?",
                new String[]{category},
                null, null, null
        );

        if (cursor.moveToFirst()) {
            do {
                MenuItem item = new MenuItem(
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_MENU_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MENU_NAME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MENU_DESCRIPTION)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_MENU_PRICE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MENU_CATEGORY)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MENU_IMAGE_PATH)),
                        cursor.getFloat(cursor.getColumnIndexOrThrow(COLUMN_MENU_RATING)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_MENU_DISCOUNT)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_MENU_AVAILABLE)) == 1
                );
                menuList.add(item);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return menuList;
    }

    public List<Order> getAllOrders() {
        List<Order> orderList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_ORDERS + " ORDER BY " + COLUMN_ORDER_DATE + " DESC",
                null
        );

        if (cursor.moveToFirst()) {
            do {
                Order order = new Order(
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ORDER_ID)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ORDER_USER_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ORDER_DATE)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_ORDER_TOTAL)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ORDER_STATUS)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ORDER_ADDRESS)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ORDER_PAYMENT))
                );
                orderList.add(order);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return orderList;
    }

    public boolean updateOrderStatus(int orderId, String newStatus) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ORDER_STATUS, newStatus);

        int result = db.update(TABLE_ORDERS, values,
                COLUMN_ORDER_ID + " = ?", new String[]{String.valueOf(orderId)});
        db.close();
        return result > 0;
    }

    public List<MenuItem> getDiscountedItems() {
        List<MenuItem> discountedList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT * FROM " + TABLE_MENU_ITEMS +
                " WHERE " + COLUMN_MENU_DISCOUNT + " > 0" +
                " AND " + COLUMN_MENU_AVAILABLE + " = 1" +
                " ORDER BY " + COLUMN_MENU_DISCOUNT + " DESC LIMIT 10";

        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                MenuItem item = new MenuItem(
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_MENU_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MENU_NAME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MENU_DESCRIPTION)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_MENU_PRICE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MENU_CATEGORY)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MENU_IMAGE_PATH)),
                        cursor.getFloat(cursor.getColumnIndexOrThrow(COLUMN_MENU_RATING)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_MENU_DISCOUNT)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_MENU_AVAILABLE)) == 1
                );
                discountedList.add(item);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return discountedList;
    }

    public void addSearchHistory(int userId, String query, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_SEARCH_USER_ID, userId);
        cv.put(COLUMN_SEARCH_QUERY, query.trim().toLowerCase());
        cv.put(COLUMN_SEARCH_DATE, date);

        db.delete(TABLE_SEARCH_HISTORY,
                COLUMN_SEARCH_USER_ID + " = ? AND " + COLUMN_SEARCH_QUERY + " = ?",
                new String[]{String.valueOf(userId), query.trim().toLowerCase()});

        db.insert(TABLE_SEARCH_HISTORY, null, cv);
        db.close();
    }

    public List<String> getSearchHistory(int userId) {
        List<String> history = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT " + COLUMN_SEARCH_QUERY + " FROM " + TABLE_SEARCH_HISTORY +
                " WHERE " + COLUMN_SEARCH_USER_ID + " = ?" +
                " ORDER BY " + COLUMN_SEARCH_DATE + " DESC LIMIT 20";

        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId)});

        if (cursor.moveToFirst()) {
            do {
                history.add(cursor.getString(0));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return history;
    }

    public void deleteSearchHistoryItem(int userId, String query) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_SEARCH_HISTORY,
                COLUMN_SEARCH_USER_ID + " = ? AND " + COLUMN_SEARCH_QUERY + " = ?",
                new String[]{String.valueOf(userId), query.trim().toLowerCase()});
        db.close();
    }

    public void clearSearchHistory(int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_SEARCH_HISTORY, COLUMN_SEARCH_USER_ID + " = ?",
                new String[]{String.valueOf(userId)});
        db.close();
    }

    // === SEARCH MENU ===
    public List<MenuItem> searchMenuItems(String keyword) {
        List<MenuItem> results = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT * FROM " + TABLE_MENU_ITEMS +
                " WHERE " + COLUMN_MENU_NAME + " LIKE ?" +
                " OR " + COLUMN_MENU_DESCRIPTION + " LIKE ?" +
                " OR " + COLUMN_MENU_CATEGORY + " LIKE ?" +
                " ORDER BY " + COLUMN_MENU_NAME + " ASC";

        String searchParam = "%" + keyword + "%";
        Cursor cursor = db.rawQuery(query, new String[]{searchParam, searchParam, searchParam});

        if (cursor.moveToFirst()) {
            do {
                MenuItem item = new MenuItem(
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_MENU_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MENU_NAME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MENU_DESCRIPTION)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_MENU_PRICE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MENU_CATEGORY)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MENU_IMAGE_PATH)),
                        cursor.getFloat(cursor.getColumnIndexOrThrow(COLUMN_MENU_RATING)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_MENU_DISCOUNT)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_MENU_AVAILABLE)) == 1
                );
                results.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return results;
    }

    public boolean checkUserEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT 1 FROM " + TABLE_USERS + " WHERE " + COLUMN_USER_EMAIL + " = ? LIMIT 1",
                new String[]{email});

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    public long addVoucher(Voucher voucher) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_VOUCHER_CODE, voucher.getCode());
        cv.put(COLUMN_VOUCHER_NAME, voucher.getName());
        cv.put(COLUMN_VOUCHER_DESCRIPTION, voucher.getDescription());
        cv.put(COLUMN_VOUCHER_DISCOUNT_PERCENT, voucher.getDiscountPercent());
        cv.put(COLUMN_VOUCHER_DISCOUNT_AMOUNT, voucher.getDiscountAmount());
        cv.put(COLUMN_VOUCHER_MIN_PURCHASE, voucher.getMinPurchase());
        cv.put(COLUMN_VOUCHER_VALID_UNTIL, voucher.getValidUntil());
        cv.put(COLUMN_VOUCHER_IS_ACTIVE, voucher.isActive() ? 1 : 0);
        cv.put(COLUMN_VOUCHER_IMAGE, voucher.getImageResource());

        long result = db.insert(TABLE_VOUCHERS, null, cv);
        db.close();
        return result;
    }

    public void toggleFavorite(int userId, int menuId) {
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT 1 FROM " + TABLE_FAVORITES +
                        " WHERE " + COLUMN_FAVORITE_USER_ID + " = ? AND " + COLUMN_FAVORITE_MENU_ID + " = ?",
                new String[]{String.valueOf(userId), String.valueOf(menuId)}
        );

        if (cursor.getCount() > 0) {
            // Sudah favorit → HAPUS
            db.delete(TABLE_FAVORITES,
                    COLUMN_FAVORITE_USER_ID + " = ? AND " + COLUMN_FAVORITE_MENU_ID + " = ?",
                    new String[]{String.valueOf(userId), String.valueOf(menuId)});
        } else {
            // Belum favorit → TAMBAH
            ContentValues cv = new ContentValues();
            cv.put(COLUMN_FAVORITE_USER_ID, userId);
            cv.put(COLUMN_FAVORITE_MENU_ID, menuId);
            db.insert(TABLE_FAVORITES, null, cv);
        }
        cursor.close();
        db.close(); // penting ditutup!
    }

    public List<MenuItem> getFavoriteItems(int userId) {
        List<MenuItem> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT mi.* FROM " + TABLE_MENU_ITEMS + " mi " +
                "INNER JOIN " + TABLE_FAVORITES + " f " +
                "ON mi." + COLUMN_MENU_ID + " = f." + COLUMN_FAVORITE_MENU_ID +
                " WHERE f." + COLUMN_FAVORITE_USER_ID + " = ?" +
                " ORDER BY mi." + COLUMN_MENU_NAME + " ASC";

        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId)});

        if (cursor.moveToFirst()) {
            do {
                MenuItem item = new MenuItem(
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_MENU_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MENU_NAME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MENU_DESCRIPTION)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_MENU_PRICE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MENU_CATEGORY)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MENU_IMAGE_PATH)), // sesuai image_path TEXT
                        cursor.getFloat(cursor.getColumnIndexOrThrow(COLUMN_MENU_RATING)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_MENU_DISCOUNT)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_MENU_AVAILABLE)) == 1
                );
                list.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return list;
    }
}