package com.example.kulinerapp.utils;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * FormatHelper – Semua format tampilan di aplikasi KulinerApp
 * Updated: 17 November 2025
 */
public class FormatHelper {

    private static final Locale INDONESIA = new Locale("id", "ID");
    private static final NumberFormat CURRENCY_FORMAT = NumberFormat.getCurrencyInstance(INDONESIA);

    /**
     * Format Rupiah → Rp25.000
     */
    public static String formatRupiah(double amount) {
        return CURRENCY_FORMAT.format(amount);
    }

    public static String formatRupiah(int amount) {
        return CURRENCY_FORMAT.format(amount);
    }

    /**
     * Format tanggal dari database → 17 Nov 2025, 17:18
     * Input: "2025-11-17 17:18:00"
     * Output: "17 Nov 2025, 17:18"
     */
    public static String formatDate(String dateString) {
        if (dateString == null || dateString.isEmpty()) return "-";
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            SimpleDateFormat outputFormat = new SimpleDateFormat("dd MMM yyyy, HH:mm", INDONESIA);
            Date date = inputFormat.parse(dateString);
            return outputFormat.format(date);
        } catch (Exception e) {
            e.printStackTrace();
            return dateString; // fallback
        }
    }

    /**
     * Format tanggal hanya tanggal → 17 Nov 2025
     */
    public static String formatDateOnly(String dateString) {
        if (dateString == null || dateString.isEmpty()) return "-";
        try {
            SimpleDateFormat input = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            SimpleDateFormat output = new SimpleDateFormat("dd MMM yyyy", INDONESIA);
            return output.format(input.parse(dateString));
        } catch (Exception e) {
            return dateString;
        }
    }

    /**
     * Format waktu saja → 17:18
     */
    public static String formatTimeOnly(String dateString) {
        if (dateString == null || dateString.isEmpty()) return "-";
        try {
            SimpleDateFormat input = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            SimpleDateFormat output = new SimpleDateFormat("HH:mm", INDONESIA);
            return output.format(input.parse(dateString));
        } catch (Exception e) {
            return dateString;
        }
    }

    /**
     * Dapatkan tanggal + waktu sekarang untuk database
     * Output: "2025-11-17 17:18:00"
     */
    public static String getCurrentDateTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return sdf.format(new Date());
    }

    /**
     * Format rating → 4.8
     */
    public static String formatRating(float rating) {
        return String.format(INDONESIA, "%.1f", rating);
    }

    /**
     * Format diskon → 20% OFF
     */
    public static String formatDiscount(int discount) {
        if (discount <= 0) return "";
        return discount + "% OFF";
    }

    /**
     * Format harga setelah diskon → Rp20.000 (dari Rp25.000 - 20%)
     */
    public static String formatPriceAfterDiscount(double originalPrice, int discountPercent) {
        if (discountPercent <= 0) return formatRupiah(originalPrice);
        double discounted = originalPrice * (100 - discountPercent) / 100.0;
        return formatRupiah(discounted);
    }

    /**
     * Format nomor telepon Indonesia → +62 812-3456-7890
     */
    public static String formatPhoneNumber(String phone) {
        if (phone == null || phone.isEmpty()) return "";
        String cleaned = phone.replaceAll("[^\\d]", "");
        if (cleaned.startsWith("0")) {
            cleaned = "62" + cleaned.substring(1);
        } else if (!cleaned.startsWith("62")) {
            cleaned = "62" + cleaned;
        }
        // Format: +62 812-3456-7890
        if (cleaned.length() >= 12) {
            return "+62 " + cleaned.substring(2, 6) + "-" +
                    cleaned.substring(6, 10) + "-" +
                    cleaned.substring(10);
        }
        return "+62 " + cleaned.substring(2);
    }

    /**
     * Hanya untuk status order (Pending, Diproses, Selesai, Dibatalkan)
     */
    public static String formatOrderStatus(String status) {
        switch (status.toLowerCase()) {
            case "pending":      return "Menunggu Pembayaran";
            case "processing":   return "Sedang Diproses";
            case "completed":    return "Selesai";
            case "cancelled":    return "Dibatalkan";
            default:             return status;
        }
    }
}