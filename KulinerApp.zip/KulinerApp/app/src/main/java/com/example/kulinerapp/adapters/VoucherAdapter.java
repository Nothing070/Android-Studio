package com.example.kulinerapp.adapters;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.R;
import com.example.kulinerapp.models.Voucher;
import com.example.kulinerapp.utils.FormatHelper;

import java.util.List;

public class VoucherAdapter extends RecyclerView.Adapter<VoucherAdapter.VH> {

    private final Context ctx;
    private final List<Voucher> list;

    public VoucherAdapter(Context ctx, List<Voucher> list) {
        this.ctx = ctx;
        this.list = list;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(ctx).inflate(R.layout.item_voucher, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        Voucher v = list.get(pos);

        // PAKAI getName() karena model kamu pakai "name", bukan "title"
        h.tvVoucherName.setText(v.getName());

        String desc = v.getDescription();
        if (v.getMinPurchase() > 0) {
            desc += "\nMin. pembelian " + FormatHelper.formatRupiah(v.getMinPurchase());
        }
        h.tvVoucherDescription.setText(desc);

        h.tvVoucherCode.setText(v.getCode());
        h.tvVoucherExpiry.setText("Berlaku hingga: " + v.getValidUntil()); // langsung pakai String
        h.ivVoucher.setImageResource(v.getImageResource());

        // KLIK → COPY KODE
        h.itemView.setOnClickListener(view -> {
            ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("voucher", v.getCode());
            cm.setPrimaryClip(clip);
            Toast.makeText(ctx, "Kode " + v.getCode() + " disalin!", Toast.LENGTH_SHORT).show();

            Animation bounce = AnimationUtils.loadAnimation(ctx, R.anim.bounce);
            view.startAnimation(bounce);
        });

        // Animasi masuk
        Animation anim = AnimationUtils.loadAnimation(ctx, R.anim.slide_in_right);
        anim.setStartOffset(pos * 70);
        h.itemView.startAnimation(anim);
    }

    @Override
    public int getItemCount() {
        return list != null ? list.size() : 0;
    }

    static class VH extends RecyclerView.ViewHolder {
        ImageView ivVoucher;
        TextView tvVoucherName, tvVoucherDescription, tvVoucherCode, tvVoucherExpiry;

        VH(@NonNull View v) {
            super(v);
            ivVoucher            = v.findViewById(R.id.ivVoucher);
            tvVoucherName        = v.findViewById(R.id.tvVoucherName);
            tvVoucherDescription = v.findViewById(R.id.tvVoucherDescription);
            tvVoucherCode        = v.findViewById(R.id.tvVoucherCode);
            tvVoucherExpiry      = v.findViewById(R.id.tvVoucherExpiry);
        }
    }
}