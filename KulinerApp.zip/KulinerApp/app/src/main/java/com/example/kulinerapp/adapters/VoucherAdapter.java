package com.example.kulinerapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.R;
import com.example.kulinerapp.models.Voucher;
import com.example.kulinerapp.utils.FormatHelper;

import java.util.List;

public class VoucherAdapter extends RecyclerView.Adapter<VoucherAdapter.VoucherViewHolder> {

    private Context context;
    private List<Voucher> vouchers;
    private OnVoucherClickListener listener;

    public interface OnVoucherClickListener {
        void onVoucherClick(Voucher voucher);
    }

    public VoucherAdapter(Context context, List<Voucher> vouchers, OnVoucherClickListener listener) {
        this.context = context;
        this.vouchers = vouchers;
        this.listener = listener;
    }

    @NonNull
    @Override
    public VoucherViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_voucher, parent, false);
        return new VoucherViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VoucherViewHolder holder, int position) {
        Voucher voucher = vouchers.get(position);

        holder.tvVoucherName.setText(voucher.getName());

        // PERBAIKAN: formatCurrency → formatRupiah
        holder.tvVoucherDescription.setText(voucher.getDescription() +
                "\nMin. pembelian " + FormatHelper.formatRupiah(voucher.getMinPurchase()));

        holder.tvVoucherCode.setText(voucher.getCode());

        // PERBAIKAN: formatDate sudah benar
        holder.tvVoucherExpiry.setText("Berlaku hingga: " +
                FormatHelper.formatDate(voucher.getValidUntil()));

        // Gambar voucher (bisa dari drawable atau internal storage kalau mau)
        holder.ivVoucher.setImageResource(voucher.getImageResource());

        // Klik voucher dengan animasi bounce
        holder.itemView.setOnClickListener(v -> {
            Animation bounce = AnimationUtils.loadAnimation(context, R.anim.bounce);
            v.startAnimation(bounce);
            listener.onVoucherClick(voucher);
        });

        // Animasi masuk dari kanan
        Animation slideIn = AnimationUtils.loadAnimation(context, R.anim.slide_in_right);
        holder.itemView.startAnimation(slideIn);
    }

    @Override
    public int getItemCount() {
        return vouchers != null ? vouchers.size() : 0;
    }

    static class VoucherViewHolder extends RecyclerView.ViewHolder {
        ImageView ivVoucher;
        TextView tvVoucherName, tvVoucherDescription, tvVoucherCode, tvVoucherExpiry;

        public VoucherViewHolder(@NonNull View itemView) {
            super(itemView);
            ivVoucher = itemView.findViewById(R.id.ivVoucher);
            tvVoucherName = itemView.findViewById(R.id.tvVoucherName);
            tvVoucherDescription = itemView.findViewById(R.id.tvVoucherDescription);
            tvVoucherCode = itemView.findViewById(R.id.tvVoucherCode);
            tvVoucherExpiry = itemView.findViewById(R.id.tvVoucherExpiry);
        }
    }
}