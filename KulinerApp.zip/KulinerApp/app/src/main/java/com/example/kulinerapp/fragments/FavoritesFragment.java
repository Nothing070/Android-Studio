package com.example.kulinerapp.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.R;
import com.example.kulinerapp.adapters.MenuAdapter;
import com.example.kulinerapp.database.DatabaseHelper;
import com.example.kulinerapp.models.MenuItem;
import com.example.kulinerapp.utils.SessionManager;

import java.util.ArrayList;
import java.util.List;

public class FavoritesFragment extends Fragment {

    private RecyclerView rvFavorites;
    private TextView tvEmpty;
    private MenuAdapter menuAdapter;
    private final List<MenuItem> favoriteList = new ArrayList<>();
    private DatabaseHelper db;
    private SessionManager sessionManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_favorites, container, false);

        rvFavorites = view.findViewById(R.id.rvFavorites);
        tvEmpty = view.findViewById(R.id.tvEmptyFavorites);

        db = new DatabaseHelper(requireContext());
        sessionManager = new SessionManager(requireContext());

        setupRecyclerView();
        loadFavorites();

        return view;
    }

    private void setupRecyclerView() {
        rvFavorites.setLayoutManager(new GridLayoutManager(requireContext(), 2));
        menuAdapter = new MenuAdapter(requireContext(), favoriteList, new MenuAdapter.OnItemActionListener() {

            @Override
            public void onAddToCart(MenuItem item) {
                // Bisa langsung tambah ke cart kalau mau
            }

            @Override
            public void onFavoriteClick(MenuItem item, boolean isFavorite) {
                db.toggleFavorite(sessionManager.getUserId(), item.getId());
                loadFavorites(); // refresh otomatis
            }

            @Override
            public void onItemClick(MenuItem item) {
                // Bisa buka detail menu nanti
            }
        });
        rvFavorites.setAdapter(menuAdapter);
    }

    private void loadFavorites() {
        favoriteList.clear();
        favoriteList.addAll(db.getFavoriteItems(sessionManager.getUserId()));
        menuAdapter.notifyDataSetChanged();

        if (favoriteList.isEmpty()) {
            tvEmpty.setVisibility(View.VISIBLE);
            rvFavorites.setVisibility(View.GONE);
        } else {
            tvEmpty.setVisibility(View.GONE);
            rvFavorites.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        loadFavorites(); // update kalau ada perubahan
    }
}