package com.example.kulinerapp.adapters;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.R;
import com.example.kulinerapp.models.MenuItem;
import com.example.kulinerapp.utils.FormatHelper;

import java.io.File;
import java.util.List;

public class DiscountAdapter extends RecyclerView.Adapter<DiscountAdapter.DiscountViewHolder> {

    private final Context context;
    private final List<MenuItem> discountItems;
    private final OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(MenuItem item);
    }

    public DiscountAdapter(Context context, List<MenuItem> discountItems, OnItemClickListener listener) {
        this.context = context;
        this.discountItems = discountItems;
        this.listener = listener;
    }

    @NonNull
    @Override
    public DiscountViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_discount, parent, false);
        return new DiscountViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DiscountViewHolder holder, int position) {
        MenuItem item = discountItems.get(position);

        holder.tvDiscountName.setText(item.getName());
        holder.tvDiscountPrice.setText(FormatHelper.formatRupiah(item.getFinalPrice()));

        // Badge diskon
        if (item.getDiscount() > 0) {
            holder.tvDiscountBadge.setVisibility(View.VISIBLE);
            holder.tvDiscountBadge.setText("-" + item.getDiscount() + "%");
        } else {
            holder.tvDiscountBadge.setVisibility(View.GONE);
        }

        // INI YANG BARU & BENAR — PAKAI getImagePath() BUKAN getImageResource()!
        String imagePath = item.getImagePath();

        if (imagePath != null && !imagePath.isEmpty()) {
            File imgFile = new File(imagePath);
            if (imgFile.exists()) {
                holder.ivDiscountItem.setImageURI(Uri.fromFile(imgFile));
            } else {
                holder.ivDiscountItem.setImageResource(R.drawable.placeholder_food);
            }
        } else {
            holder.ivDiscountItem.setImageResource(R.drawable.placeholder_food);
        }

        // Klik + animasi bounce
        holder.itemView.setOnClickListener(v -> {
            Animation bounce = AnimationUtils.loadAnimation(context, R.anim.bounce);
            v.startAnimation(bounce);
            listener.onItemClick(item);
        });

        // Animasi masuk dari kanan
        Animation slideIn = AnimationUtils.loadAnimation(context, R.anim.slide_in_right);
        slideIn.setStartOffset(position * 50);
        holder.itemView.startAnimation(slideIn);
    }

    @Override
    public int getItemCount() {
        return discountItems != null ? discountItems.size() : 0;
    }

    static class DiscountViewHolder extends RecyclerView.ViewHolder {
        ImageView ivDiscountItem;
        TextView tvDiscountName, tvDiscountPrice, tvDiscountBadge;

        DiscountViewHolder(@NonNull View itemView) {
            super(itemView);
            ivDiscountItem = itemView.findViewById(R.id.ivDiscountItem);
            tvDiscountName = itemView.findViewById(R.id.tvDiscountName);
            tvDiscountPrice = itemView.findViewById(R.id.tvDiscountPrice);
            tvDiscountBadge = itemView.findViewById(R.id.tvDiscountBadge);
        }
    }
}