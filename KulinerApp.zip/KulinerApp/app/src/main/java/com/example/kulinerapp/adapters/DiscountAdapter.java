package com.example.kulinerapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.R;
import com.example.kulinerapp.models.MenuItem;
import com.example.kulinerapp.utils.FormatHelper;

import java.util.List;

public class DiscountAdapter extends RecyclerView.Adapter<DiscountAdapter.DiscountViewHolder> {

    private Context context;
    private List<MenuItem> discountItems;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(MenuItem item);
    }

    public DiscountAdapter(Context context, List<MenuItem> discountItems, OnItemClickListener listener) {
        this.context = context;
        this.discountItems = discountItems;
        this.listener = listener;
    }

    @NonNull
    @Override
    public DiscountViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_discount, parent, false);
        return new DiscountViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DiscountViewHolder holder, int position) {
        MenuItem item = discountItems.get(position);

        holder.tvDiscountName.setText(item.getName());
        holder.tvDiscountPrice.setText(FormatHelper.formatCurrency(item.getFinalPrice()));
        holder.tvDiscountBadge.setText(FormatHelper.formatDiscount(item.getDiscount()));
        holder.ivDiscountItem.setImageResource(item.getImageResource());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Animation bounce = AnimationUtils.loadAnimation(context, R.anim.bounce);
                v.startAnimation(bounce);
                listener.onItemClick(item);
            }
        });

        // Apply animation
        Animation slideIn = AnimationUtils.loadAnimation(context, R.anim.slide_in_right);
        holder.itemView.startAnimation(slideIn);
    }

    @Override
    public int getItemCount() {
        return discountItems.size();
    }

    static class DiscountViewHolder extends RecyclerView.ViewHolder {
        ImageView ivDiscountItem;
        TextView tvDiscountName, tvDiscountPrice, tvDiscountBadge;

        public DiscountViewHolder(@NonNull View itemView) {
            super(itemView);
            ivDiscountItem = itemView.findViewById(R.id.ivDiscountItem);
            tvDiscountName = itemView.findViewById(R.id.tvDiscountName);
            tvDiscountPrice = itemView.findViewById(R.id.tvDiscountPrice);
            tvDiscountBadge = itemView.findViewById(R.id.tvDiscountBadge);
        }
    }
}