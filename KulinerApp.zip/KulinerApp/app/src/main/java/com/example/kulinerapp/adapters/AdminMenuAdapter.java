package com.example.kulinerapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.R;
import com.example.kulinerapp.models.MenuItem;
import com.example.kulinerapp.utils.FormatHelper;

import java.util.List;

public class AdminMenuAdapter extends RecyclerView.Adapter<AdminMenuAdapter.AdminMenuViewHolder> {

    private Context context;
    private List<MenuItem> menuItems;
    private OnAdminMenuActionListener listener;

    public interface OnAdminMenuActionListener {
        void onEditMenu(MenuItem item);
        void onDeleteMenu(MenuItem item);
        void onToggleAvailability(MenuItem item);
    }

    public AdminMenuAdapter(Context context, List<MenuItem> menuItems, OnAdminMenuActionListener listener) {
        this.context = context;
        this.menuItems = menuItems;
        this.listener = listener;
    }

    @NonNull
    @Override
    public AdminMenuViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_admin_menu, parent, false);
        return new AdminMenuViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdminMenuViewHolder holder, int position) {
        MenuItem item = menuItems.get(position);

        holder.tvMenuName.setText(item.getName());
        holder.tvMenuPrice.setText(FormatHelper.formatCurrency(item.getPrice()));
        holder.tvMenuCategory.setText(item.getCategory());
        holder.ivMenuItem.setImageResource(item.getImageResource());
        holder.switchAvailable.setChecked(item.isAvailable());

        holder.btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onEditMenu(item);
            }
        });

        holder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onDeleteMenu(item);
            }
        });

        holder.switchAvailable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onToggleAvailability(item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return menuItems.size();
    }

    static class AdminMenuViewHolder extends RecyclerView.ViewHolder {
        ImageView ivMenuItem;
        TextView tvMenuName, tvMenuPrice, tvMenuCategory;
        Switch switchAvailable;
        Button btnEdit, btnDelete;

        public AdminMenuViewHolder(@NonNull View itemView) {
            super(itemView);
            ivMenuItem = itemView.findViewById(R.id.ivMenuItem);
            tvMenuName = itemView.findViewById(R.id.tvMenuName);
            tvMenuPrice = itemView.findViewById(R.id.tvMenuPrice);
            tvMenuCategory = itemView.findViewById(R.id.tvMenuCategory);
            switchAvailable = itemView.findViewById(R.id.switchAvailable);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}