package com.example.kulinerapp.adapters;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.R;
import com.example.kulinerapp.models.MenuItem;
import com.example.kulinerapp.utils.FormatHelper;

import java.io.File;
import java.util.List;

public class AdminMenuAdapter extends RecyclerView.Adapter<AdminMenuAdapter.ViewHolder> {

    private final Context context;
    private final List<MenuItem> menuList;
    private final OnMenuActionListener listener;

    public interface OnMenuActionListener {
        void onEditClick(MenuItem menuItem);
        void onDeleteClick(MenuItem menuItem);
        void onAvailabilityChanged(MenuItem menuItem, boolean isAvailable);
    }

    public AdminMenuAdapter(Context context, List<MenuItem> menuList, OnMenuActionListener listener) {
        this.context = context;
        this.menuList = menuList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_admin_menu, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MenuItem menuItem = menuList.get(position);

        holder.tvMenuName.setText(menuItem.getName());
        holder.tvMenuPrice.setText(FormatHelper.formatRupiah(menuItem.getFinalPrice()));
        holder.tvMenuCategory.setText(menuItem.getCategory());
        holder.switchAvailable.setChecked(menuItem.isAvailable());

        // INI YANG BARU & BENAR — PAKAI getImagePath() bukan getImageResource()!
        String imagePath = menuItem.getImagePath();

        if (imagePath != null && !imagePath.isEmpty()) {
            File imgFile = new File(imagePath);
            if (imgFile.exists()) {
                holder.ivMenuItem.setImageURI(Uri.fromFile(imgFile));
            } else {
                holder.ivMenuItem.setImageResource(R.drawable.placeholder_food);
            }
        } else {
            holder.ivMenuItem.setImageResource(R.drawable.placeholder_food);
        }

        holder.btnEdit.setOnClickListener(v -> listener.onEditClick(menuItem));
        holder.btnDelete.setOnClickListener(v -> listener.onDeleteClick(menuItem));

        holder.switchAvailable.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (buttonView.isPressed()) { // biar ga trigger pas load
                listener.onAvailabilityChanged(menuItem, isChecked);
            }
        });
    }

    @Override
    public int getItemCount() {
        return menuList != null ? menuList.size() : 0;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivMenuItem;
        TextView tvMenuName, tvMenuPrice, tvMenuCategory;
        Switch switchAvailable;
        Button btnEdit, btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivMenuItem = itemView.findViewById(R.id.ivMenuItem);
            tvMenuName = itemView.findViewById(R.id.tvMenuName);
            tvMenuPrice = itemView.findViewById(R.id.tvMenuPrice);
            tvMenuCategory = itemView.findViewById(R.id.tvMenuCategory);
            switchAvailable = itemView.findViewById(R.id.switchAvailable);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}