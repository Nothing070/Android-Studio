package com.example.kulinerapp.utils;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;

import java.util.Locale;

public class LocaleHelper {

    public static Context setLocale(Context context, String languageCode) {
        Locale locale = new Locale(languageCode);
        Locale.setDefault(locale);

        Configuration config = new Configuration();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            config.setLocale(locale);
            config.setLayoutDirection(locale);
            return context.createConfigurationContext(config);
        } else {
            config.locale = locale;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                config.setLayoutDirection(locale);
            }
            context.getResources().updateConfiguration(config, context.getResources().getDisplayMetrics());
            return context;
        }
    }

    public static String getLanguageName(String code) {
        switch (code) {
            case "id": return "Bahasa Indonesia";
            case "en": return "English";
            case "jv": return "Basa Jawa";
            case "su": return "Basa Sunda";
            case "ms": return "Bahasa Melayu";
            case "zh": return "中文";
            case "ja": return "日本語";
            case "ko": return "한국어";
            case "ar": return "العربية";
            case "hi": return "हिन्दी";
            default: return "Bahasa Indonesia";
        }
    }

    public static String getFlag(String code) {
        switch (code) {
            case "id": return "Indonesia";
            case "en": return "UK";
            case "jv": return "Coffee";
            case "su": return "Sunrise";
            case "ms": return "Malaysia";
            case "zh": return "China";
            case "ja": return "Japan";
            case "ko": return "South Korea";
            case "ar": return "Saudi Arabia";
            case "hi": return "India";
            default: return "Indonesia";
        }
    }
}