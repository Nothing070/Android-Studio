package com.example.kulinerapp.utils;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;

import java.util.Locale;

public class LocaleHelper {

    public static Context setLocale(Context context, String languageCode) {
        new SessionManager(context).setLanguage(languageCode);
        return updateResources(context, languageCode);
    }

    public static Context onAttach(Context context) {
        String lang = new SessionManager(context).getLanguage();
        if (lang == null || lang.isEmpty()) {
            lang = "id";
            new SessionManager(context).setLanguage(lang);
        }
        return updateResources(context, lang);
    }

    // UPDATE BAHASA DI SISTEM
    private static Context updateResources(Context context, String languageCode) {
        Locale locale = new Locale(languageCode);
        Locale.setDefault(locale);

        Configuration configuration = new Configuration(context.getResources().getConfiguration());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            configuration.setLocale(locale);
            configuration.setLayoutDirection(locale);
            return context.createConfigurationContext(configuration);
        } else {
            configuration.locale = locale;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                configuration.setLayoutDirection(locale);
            }
            context.getResources().updateConfiguration(configuration, context.getResources().getDisplayMetrics());
            return context;
        }
    }

    // Bonus: Nama bahasa & emoji bendera
    public static String getLanguageName(String code) {
        switch (code) {
            case "id": return "Bahasa Indonesia";
            case "en": return "English";
            case "jv": return "Basa Jawa";
            case "su": return "Basa Sunda";
            case "ms": return "Bahasa Melayu";
            case "zh": return "中文 (Chinese)";
            case "ja": return "日本語 (Japanese)";
            case "ko": return "한국어 (Korean)";
            case "ar": return "العربية (Arabic)";
            case "hi": return "हिन्दी (Hindi)";
            default: return "Bahasa Indonesia";
        }
    }

    public static String getFlagEmoji(String code) {
        switch (code) {
            case "id": return "Indonesia";
            case "en": return "UK";
            case "jv": return "Coffee";
            case "su": return "Sunrise";
            case "ms": return "Malaysia";
            case "zh": return "China";
            case "ja": return "Japan";
            case "ko": return "South Korea";
            case "ar": return "Saudi Arabia";
            case "hi": return "India";
            default: return "Indonesia";
        }
    }
}