package com.example.kulinerapp.utils;

import android.content.Context;
import android.content.res.Configuration;
import java.util.Locale;

public class LocaleHelper {

    private static final String KEY_LANGUAGE = "app_language";

    // GANTI BAHASA + SIMPAN (PAKAI commit() biar langsung ke-save)
    public static void setLocale(Context context, String languageCode) {
        // Simpan ke SharedPreferences
        context.getSharedPreferences("KulinerAppSession", Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_LANGUAGE, languageCode)
                .commit();

        Locale locale = createLocale(languageCode);
        Locale.setDefault(locale);

        Configuration config = new Configuration();
        config.locale = locale;
        context.getResources().updateConfiguration(config, context.getResources().getDisplayMetrics());
    }

    // Dipanggil di BaseActivity.attachBaseContext()
    public static Context onAttach(Context context) {
        String lang = context.getSharedPreferences("KulinerAppSession", Context.MODE_PRIVATE)
                .getString(KEY_LANGUAGE, "id"); // default Indonesia

        Locale locale = createLocale(lang);
        Locale.setDefault(locale);

        Configuration config = new Configuration();
        config.locale = locale;
        return context.createConfigurationContext(config);
    }

    // INI YANG PALING PENTING — MAPPING KODE BAHASA YANG BENAR!
    private static Locale createLocale(String languageCode) {
        switch (languageCode) {
            case "en": return new Locale("en");        // English
            case "id": return new Locale("in", "ID");  // Indonesia (BENER: in_ID, bukan id!)
            case "jv": return new Locale("jv");        // Jawa
            case "su": return new Locale("su");        // Sunda
            case "ms": return new Locale("ms");        // Melayu
            case "zh": return new Locale("zh", "CN");  // China Simplified
            case "ja": return new Locale("ja");        // Jepang
            case "ko": return new Locale("ko");        // Korea
            case "ar": return new Locale("ar");        // Arab
            case "hi": return new Locale("hi");        // Hindi
            default:   return new Locale("in", "ID");  // fallback ke Indonesia
        }
    }

    public static String getCurrentLanguage(Context context) {
        String lang = context.getSharedPreferences("KulinerAppSession", Context.MODE_PRIVATE)
                .getString(KEY_LANGUAGE, "id");
        return lang.equals("id") ? "id" : lang; // biar konsisten
    }

    public static String getLanguageName(String code) {
        switch (code) {
            case "id": return "Bahasa Indonesia";
            case "en": return "English";
            case "jv": return "Basa Jawa";
            case "su": return "Basa Sunda";
            case "ms": return "Bahasa Melayu";
            case "zh": return "中文";
            case "ja": return "日本語";
            case "ko": return "한국어";
            case "ar": return "العربية";
            case "hi": return "हिन्दी";
            default: return "Bahasa Indonesia";
        }
    }
}