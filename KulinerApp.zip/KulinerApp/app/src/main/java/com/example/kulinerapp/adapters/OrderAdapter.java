package com.example.kulinerapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.R;
import com.example.kulinerapp.database.DatabaseHelper;
import com.example.kulinerapp.models.Order;
import com.example.kulinerapp.models.OrderDetail;
import com.example.kulinerapp.utils.FormatHelper;

import java.util.List;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderViewHolder> {

    private Context context;
    private List<Order> orders;
    private OnOrderClickListener listener;
    private DatabaseHelper db;

    public interface OnOrderClickListener {
        void onOrderClick(Order order);
    }

    public OrderAdapter(Context context, List<Order> orders, OnOrderClickListener listener) {
        this.context = context;
        this.orders = orders;
        this.listener = listener;
        this.db = new DatabaseHelper(context);
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_order, parent, false);
        return new OrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        Order order = orders.get(position);

        holder.tvOrderId.setText("Order #" + order.getId());
        holder.tvOrderDate.setText(FormatHelper.formatDate(order.getOrderDate()));

        // PERBAIKAN DI SINI: formatCurrency → formatRupiah
        holder.tvOrderTotal.setText(FormatHelper.formatRupiah(order.getTotalAmount()));

        holder.tvPaymentMethod.setText(order.getPaymentMethod());

        // Set status + background
        String status = order.getStatus();
        holder.tvOrderStatus.setText(FormatHelper.formatOrderStatus(status));

        switch (status.toLowerCase()) {
            case "pending":
                holder.tvOrderStatus.setBackgroundResource(R.drawable.bg_status_pending);
                break;
            case "processing":
                holder.tvOrderStatus.setBackgroundResource(R.drawable.bg_status_processing);
                break;
            case "completed":
                holder.tvOrderStatus.setBackgroundResource(R.drawable.bg_status_completed);
                break;
            case "cancelled":
                holder.tvOrderStatus.setBackgroundResource(R.drawable.bg_status_cancelled);
                break;
            default:
                holder.tvOrderStatus.setBackgroundResource(R.drawable.bg_status_pending);
                break;
        }

        // Tampilkan item pesanan
        List<OrderDetail> orderDetails = db.getOrderDetails(order.getId());
        StringBuilder itemsText = new StringBuilder();
        for (int i = 0; i < orderDetails.size(); i++) {
            OrderDetail detail = orderDetails.get(i);
            itemsText.append(detail.getMenuName())
                    .append(" x")
                    .append(detail.getQuantity());
            if (i < orderDetails.size() - 1) {
                itemsText.append(", ");
            }
        }
        holder.tvOrderItems.setText(itemsText.toString());

        // Tombol detail
        holder.btnViewDetails.setOnClickListener(v -> {
            Animation bounce = AnimationUtils.loadAnimation(context, R.anim.bounce);
            v.startAnimation(bounce);
            listener.onOrderClick(order);
        });

        // Animasi masuk
        Animation slideIn = AnimationUtils.loadAnimation(context, R.anim.slide_in_right);
        holder.itemView.startAnimation(slideIn);
    }

    @Override
    public int getItemCount() {
        return orders.size();
    }

    static class OrderViewHolder extends RecyclerView.ViewHolder {
        TextView tvOrderId, tvOrderDate, tvOrderStatus, tvOrderItems, tvPaymentMethod, tvOrderTotal;
        Button btnViewDetails;

        public OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            tvOrderId = itemView.findViewById(R.id.tvOrderId);
            tvOrderDate = itemView.findViewById(R.id.tvOrderDate);
            tvOrderStatus = itemView.findViewById(R.id.tvOrderStatus);
            tvOrderItems = itemView.findViewById(R.id.tvOrderItems);
            tvPaymentMethod = itemView.findViewById(R.id.tvPaymentMethod);
            tvOrderTotal = itemView.findViewById(R.id.tvOrderTotal);
            btnViewDetails = itemView.findViewById(R.id.btnViewDetails);
        }
    }
}