package com.example.kulinerapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.R;
import com.example.kulinerapp.database.DatabaseHelper;

import java.util.List;

public class SearchCategoryAdapter extends RecyclerView.Adapter<SearchCategoryAdapter.CategoryViewHolder> {

    private Context context;
    private List<String> categories;
    private List<String> categoryIcons;
    private OnCategoryClickListener listener;
    private DatabaseHelper db;

    public interface OnCategoryClickListener {
        void onCategoryClick(String category);
    }

    public SearchCategoryAdapter(Context context, List<String> categories, List<String> categoryIcons,
                                 OnCategoryClickListener listener) {
        this.context = context;
        this.categories = categories;
        this.categoryIcons = categoryIcons;
        this.listener = listener;
        this.db = new DatabaseHelper(context);
    }

    @NonNull
    @Override
    public CategoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_search_category, parent, false);
        return new CategoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryViewHolder holder, int position) {
        String category = categories.get(position);
        String icon = categoryIcons.get(position);

        holder.tvCategoryName.setText(category);
        holder.tvCategoryIcon.setText(icon);

        int count = db.getMenuItemsByCategory(category).size();
        holder.tvCategoryCount.setText(count + " menu tersedia");

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Animation bounce = AnimationUtils.loadAnimation(context, R.anim.bounce);
                v.startAnimation(bounce);
                listener.onCategoryClick(category);
            }
        });
    }

    @Override
    public int getItemCount() {
        return categories.size();
    }

    static class CategoryViewHolder extends RecyclerView.ViewHolder {
        TextView tvCategoryName, tvCategoryIcon, tvCategoryCount;

        public CategoryViewHolder(@NonNull View itemView) {
            super(itemView);
            tvCategoryName = itemView.findViewById(R.id.tvCategoryName);
            tvCategoryIcon = itemView.findViewById(R.id.tvCategoryIcon);
            tvCategoryCount = itemView.findViewById(R.id.tvCategoryCount);
        }
    }
}