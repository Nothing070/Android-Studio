package com.example.kulinerapp.activities;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.BaseActivity;
import com.example.kulinerapp.R;
import com.example.kulinerapp.adapters.OrderAdapter;
import com.example.kulinerapp.database.DatabaseHelper;
import com.example.kulinerapp.models.Order;
import com.example.kulinerapp.utils.LocaleHelper;
import com.example.kulinerapp.utils.SessionManager;

import java.util.ArrayList;
import java.util.List;

public class OrderHistoryActivity extends BaseActivity {

    private ImageView ivBack;
    private RecyclerView rvOrders;
    private LinearLayout emptyOrderView;

    private OrderAdapter orderAdapter;
    private DatabaseHelper db;
    private SessionManager sessionManager;
    private List<Order> orders;

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(LocaleHelper.onAttach(newBase));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history);

        // Initialize
        db = new DatabaseHelper(this);
        sessionManager = new SessionManager(this);

        // Find views
        ivBack = findViewById(R.id.ivBack);
        rvOrders = findViewById(R.id.rvOrders);
        emptyOrderView = findViewById(R.id.emptyOrderView);

        // Handle back press
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                finish();
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            }
        });

        // Setup RecyclerView
        setupOrdersRecyclerView();

        // Load orders
        loadOrders();

        // Set click listener
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            }
        });
    }

    private void setupOrdersRecyclerView() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        rvOrders.setLayoutManager(layoutManager);

        orders = new ArrayList<>();
        orderAdapter = new OrderAdapter(this, orders, new OrderAdapter.OnOrderClickListener() {
            @Override
            public void onOrderClick(Order order) {
                // Show order details
                Toast.makeText(OrderHistoryActivity.this,
                        "Order #" + order.getId(), Toast.LENGTH_SHORT).show();
            }
        });
        rvOrders.setAdapter(orderAdapter);
    }

    private void loadOrders() {
        orders.clear();
        orders.addAll(db.getUserOrders(sessionManager.getUserId()));

        if (orders.isEmpty()) {
            emptyOrderView.setVisibility(View.VISIBLE);
            rvOrders.setVisibility(View.GONE);
        } else {
            emptyOrderView.setVisibility(View.GONE);
            rvOrders.setVisibility(View.VISIBLE);
        }

        orderAdapter.notifyDataSetChanged();
    }
}