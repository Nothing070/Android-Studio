package com.example.kulinerapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.R;
import com.example.kulinerapp.database.DatabaseHelper;
import com.example.kulinerapp.models.Order;
import com.example.kulinerapp.models.OrderDetail;
import com.example.kulinerapp.utils.FormatHelper;

import java.util.List;

public class AdminOrderAdapter extends RecyclerView.Adapter<AdminOrderAdapter.AdminOrderViewHolder> {

    private Context context;
    private List<Order> orders;
    private OnAdminOrderActionListener listener;
    private DatabaseHelper db;

    public interface OnAdminOrderActionListener {
        void onUpdateStatus(Order order);
        void onViewDetails(Order order);
    }

    public AdminOrderAdapter(Context context, List<Order> orders, OnAdminOrderActionListener listener) {
        this.context = context;
        this.orders = orders;
        this.listener = listener;
        this.db = new DatabaseHelper(context);
    }

    @NonNull
    @Override
    public AdminOrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_order, parent, false);
        return new AdminOrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdminOrderViewHolder holder, int position) {
        Order order = orders.get(position);

        holder.tvOrderId.setText("Order #" + order.getId());
        holder.tvOrderDate.setText(FormatHelper.formatDate(order.getOrderDate()));

        // PERBAIKAN: formatCurrency → formatRupiah
        holder.tvOrderTotal.setText(FormatHelper.formatRupiah(order.getTotalAmount()));

        holder.tvPaymentMethod.setText(order.getPaymentMethod());

        // Status dalam bahasa Indonesia + background
        String status = order.getStatus();
        holder.tvOrderStatus.setText(FormatHelper.formatOrderStatus(status));

        switch (status.toLowerCase()) {
            case "pending":
                holder.tvOrderStatus.setBackgroundResource(R.drawable.bg_status_pending);
                break;
            case "processing":
                holder.tvOrderStatus.setBackgroundResource(R.drawable.bg_status_processing);
                break;
            case "completed":
                holder.tvOrderStatus.setBackgroundResource(R.drawable.bg_status_completed);
                break;
            case "cancelled":
                holder.tvOrderStatus.setBackgroundResource(R.drawable.bg_status_cancelled);
                break;
            default:
                holder.tvOrderStatus.setBackgroundResource(R.drawable.bg_status_pending);
                break;
        }

        // Tampilkan item pesanan (contoh: Nasi Goreng x2, Es Teh x1)
        List<OrderDetail> details = db.getOrderDetails(order.getId());
        StringBuilder items = new StringBuilder();
        for (int i = 0; i < details.size(); i++) {
            OrderDetail d = details.get(i);
            items.append(d.getMenuName()).append(" x").append(d.getQuantity());
            if (i < details.size() - 1) items.append(", ");
        }
        holder.tvOrderItems.setText(items.toString());

        // Tombol utama di admin: Update Status
        holder.btnViewDetails.setText("Update Status");
        holder.btnViewDetails.setOnClickListener(v -> {
            Animation bounce = AnimationUtils.loadAnimation(context, R.anim.bounce);
            v.startAnimation(bounce);
            listener.onUpdateStatus(order);
        });

        // Animasi masuk halus
        Animation slideIn = AnimationUtils.loadAnimation(context, R.anim.slide_in_right);
        holder.itemView.startAnimation(slideIn);
    }

    @Override
    public int getItemCount() {
        return orders != null ? orders.size() : 0;
    }

    static class AdminOrderViewHolder extends RecyclerView.ViewHolder {
        TextView tvOrderId, tvOrderDate, tvOrderStatus, tvOrderItems, tvPaymentMethod, tvOrderTotal;
        Button btnViewDetails;

        public AdminOrderViewHolder(@NonNull View itemView) {
            super(itemView);
            tvOrderId = itemView.findViewById(R.id.tvOrderId);
            tvOrderDate = itemView.findViewById(R.id.tvOrderDate);
            tvOrderStatus = itemView.findViewById(R.id.tvOrderStatus);
            tvOrderItems = itemView.findViewById(R.id.tvOrderItems);
            tvPaymentMethod = itemView.findViewById(R.id.tvPaymentMethod);
            tvOrderTotal = itemView.findViewById(R.id.tvOrderTotal);
            btnViewDetails = itemView.findViewById(R.id.btnViewDetails);
        }
    }
}