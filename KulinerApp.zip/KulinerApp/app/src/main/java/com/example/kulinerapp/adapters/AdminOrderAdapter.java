package com.example.kulinerapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.R;
import com.example.kulinerapp.models.Order;
import com.example.kulinerapp.utils.FormatHelper;

import java.util.List;

public class AdminOrderAdapter extends RecyclerView.Adapter<AdminOrderAdapter.AdminOrderViewHolder> {

    private Context context;
    private List<Order> orders;
    private OnAdminOrderActionListener listener;

    public interface OnAdminOrderActionListener {
        void onUpdateStatus(Order order);
        void onViewDetails(Order order);
    }

    public AdminOrderAdapter(Context context, List<Order> orders, OnAdminOrderActionListener listener) {
        this.context = context;
        this.orders = orders;
        this.listener = listener;
    }

    @NonNull
    @Override
    public AdminOrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_order, parent, false);
        return new AdminOrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdminOrderViewHolder holder, int position) {
        Order order = orders.get(position);

        holder.tvOrderId.setText("Order #" + order.getId());
        holder.tvOrderDate.setText(FormatHelper.formatDate(order.getOrderDate()));
        holder.tvOrderTotal.setText(FormatHelper.formatCurrency(order.getTotalAmount()));
        holder.tvPaymentMethod.setText(order.getPaymentMethod());
        holder.tvOrderStatus.setText(order.getStatus());

        // Set status background
        switch (order.getStatus()) {
            case "Pending":
                holder.tvOrderStatus.setBackgroundResource(R.drawable.bg_status_pending);
                break;
            case "Processing":
                holder.tvOrderStatus.setBackgroundResource(R.drawable.bg_status_processing);
                break;
            case "Completed":
                holder.tvOrderStatus.setBackgroundResource(R.drawable.bg_status_completed);
                break;
            case "Cancelled":
                holder.tvOrderStatus.setBackgroundResource(R.drawable.bg_status_cancelled);
                break;
        }

        holder.btnViewDetails.setText("Update Status");
        holder.btnViewDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onUpdateStatus(order);
            }
        });
    }

    @Override
    public int getItemCount() {
        return orders.size();
    }

    static class AdminOrderViewHolder extends RecyclerView.ViewHolder {
        TextView tvOrderId, tvOrderDate, tvOrderStatus, tvOrderItems, tvPaymentMethod, tvOrderTotal;
        Button btnViewDetails;

        public AdminOrderViewHolder(@NonNull View itemView) {
            super(itemView);
            tvOrderId = itemView.findViewById(R.id.tvOrderId);
            tvOrderDate = itemView.findViewById(R.id.tvOrderDate);
            tvOrderStatus = itemView.findViewById(R.id.tvOrderStatus);
            tvOrderItems = itemView.findViewById(R.id.tvOrderItems);
            tvPaymentMethod = itemView.findViewById(R.id.tvPaymentMethod);
            tvOrderTotal = itemView.findViewById(R.id.tvOrderTotal);
            btnViewDetails = itemView.findViewById(R.id.btnViewDetails);
        }
    }
}