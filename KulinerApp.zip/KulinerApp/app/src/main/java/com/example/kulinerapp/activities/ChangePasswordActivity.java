package com.example.kulinerapp.activities;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kulinerapp.R;
import com.example.kulinerapp.database.DatabaseHelper;
import com.example.kulinerapp.utils.LocaleHelper;
import com.example.kulinerapp.utils.SessionManager;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class ChangePasswordActivity extends AppCompatActivity {

    private ImageView ivBack;
    private TextInputLayout tilOldPassword, tilNewPassword, tilConfirmPassword;
    private TextInputEditText etOldPassword, etNewPassword, etConfirmPassword;
    private Button btnChangePassword;

    private DatabaseHelper databaseHelper;
    private SessionManager sessionManager;

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(LocaleHelper.onAttach(newBase));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        // Initialize
        databaseHelper = new DatabaseHelper(this);
        sessionManager = new SessionManager(this);

        // Find views
        ivBack = findViewById(R.id.ivBack);
        tilOldPassword = findViewById(R.id.tilOldPassword);
        tilNewPassword = findViewById(R.id.tilNewPassword);
        tilConfirmPassword = findViewById(R.id.tilConfirmPassword);
        etOldPassword = findViewById(R.id.etOldPassword);
        etNewPassword = findViewById(R.id.etNewPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        btnChangePassword = findViewById(R.id.btnChangePassword);

        // Handle back press
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                finish();
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            }
        });

        // Set click listeners
        ivBack.setOnClickListener(v -> {
            finish();
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        });

        btnChangePassword.setOnClickListener(v -> changePassword());
    }

    private void changePassword() {
        // Get input values
        String oldPassword = etOldPassword.getText().toString().trim();
        String newPassword = etNewPassword.getText().toString().trim();
        String confirmPassword = etConfirmPassword.getText().toString().trim();

        // Reset errors
        tilOldPassword.setError(null);
        tilNewPassword.setError(null);
        tilConfirmPassword.setError(null);

        // Validate inputs
        if (TextUtils.isEmpty(oldPassword)) {
            tilOldPassword.setError("Password lama tidak boleh kosong");
            etOldPassword.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(newPassword)) {
            tilNewPassword.setError("Password baru tidak boleh kosong");
            etNewPassword.requestFocus();
            return;
        }

        if (newPassword.length() < 6) {
            tilNewPassword.setError("Password minimal 6 karakter");
            etNewPassword.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(confirmPassword)) {
            tilConfirmPassword.setError("Konfirmasi password tidak boleh kosong");
            etConfirmPassword.requestFocus();
            return;
        }

        if (!newPassword.equals(confirmPassword)) {
            tilConfirmPassword.setError("Password tidak cocok");
            etConfirmPassword.requestFocus();
            return;
        }

        if (oldPassword.equals(newPassword)) {
            tilNewPassword.setError("Password baru harus berbeda dengan password lama");
            etNewPassword.requestFocus();
            return;
        }

        // Get current user ID from session
        int userId = sessionManager.getUserId();

        if (userId == -1) {
            Toast.makeText(this, "Sesi login tidak valid. Silakan login kembali.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Update password in database
        boolean success = databaseHelper.updatePassword(userId, oldPassword, newPassword);

        if (success) {
            Toast.makeText(this, "Password berhasil diubah", Toast.LENGTH_SHORT).show();

            // Clear input fields
            etOldPassword.setText("");
            etNewPassword.setText("");
            etConfirmPassword.setText("");

            // Kembali ke settings
            finish();
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        } else {
            tilOldPassword.setError("Password lama salah");
            etOldPassword.requestFocus();
            Toast.makeText(this, "Gagal mengubah password. Password lama salah.", Toast.LENGTH_SHORT).show();
        }
    }
}