package com.example.kulinerapp.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kulinerapp.R;
import com.example.kulinerapp.database.DatabaseHelper;
import com.example.kulinerapp.models.Membership;
import com.example.kulinerapp.utils.FormatHelper;
import com.example.kulinerapp.utils.SessionManager;

public class MembershipActivity extends AppCompatActivity {

    private ImageView ivBack;
    private TextView tvMemberType, tvMemberName, tvMemberPoints, tvMemberExpiry;

    private DatabaseHelper db;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_membership);

        // Initialize
        db = new DatabaseHelper(this);
        sessionManager = new SessionManager(this);

        // Find views
        ivBack = findViewById(R.id.ivBack);
        tvMemberType = findViewById(R.id.tvMemberType);
        tvMemberName = findViewById(R.id.tvMemberName);
        tvMemberPoints = findViewById(R.id.tvMemberPoints);
        tvMemberExpiry = findViewById(R.id.tvMemberExpiry);

        // Handle back press
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                finish();
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            }
        });

        // Load membership data
        loadMembershipData();

        // Set click listeners
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            }
        });
    }

    private void loadMembershipData() {
        Membership membership = db.getMembershipByUserId(sessionManager.getUserId());

        if (membership != null) {
            tvMemberType.setText(membership.getMemberType().toUpperCase() + " MEMBER");
            tvMemberName.setText(sessionManager.getUsername());
            tvMemberPoints.setText("Points: " + membership.getPoints());
            tvMemberExpiry.setText("Valid Until: " +
                    FormatHelper.formatDate(membership.getExpiredDate()));
        } else {
            // Create default membership
            Membership newMembership = new Membership(
                    sessionManager.getUserId(),
                    "Silver",
                    0,
                    FormatHelper.getCurrentDateTime(),
                    "2025-12-31 23:59:59"
            );
            db.addMembership(newMembership);
            loadMembershipData();
        }
    }
}