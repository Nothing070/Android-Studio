package com.example.kulinerapp;

import android.content.Context;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.example.kulinerapp.utils.LocaleHelper;
import com.example.kulinerapp.utils.SessionManager;

public class BaseActivity extends AppCompatActivity {
    @Override
    protected void attachBaseContext(Context newBase) {
        SessionManager sm = new SessionManager(newBase);
        super.attachBaseContext(LocaleHelper.setLocale(newBase, sm.getLanguage()));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}