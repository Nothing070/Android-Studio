package com.example.kulinerapp.fragments;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.MainActivity;
import com.example.kulinerapp.R;
import com.example.kulinerapp.adapters.MenuAdapter;
import com.example.kulinerapp.adapters.SearchCategoryAdapter;
import com.example.kulinerapp.adapters.SearchHistoryAdapter;
import com.example.kulinerapp.database.DatabaseHelper;
import com.example.kulinerapp.models.CartItem;
import com.example.kulinerapp.models.Favorite;
import com.example.kulinerapp.models.MenuItem;
import com.example.kulinerapp.utils.FormatHelper;
import com.example.kulinerapp.utils.SessionManager;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SearchFragment extends Fragment {

    private EditText etSearch;
    private ImageView ivClearSearch;
    private TextView tvClearHistory, tvNoHistory, tvResultCount, tvNoResults;
    private LinearLayout searchHistorySection, popularSearchSection, categoriesSection, searchResultsSection;
    private RecyclerView rvSearchHistory, rvSearchCategories, rvSearchResults;
    private ChipGroup chipGroupPopular;

    private SearchHistoryAdapter historyAdapter;
    private SearchCategoryAdapter categoryAdapter;
    private MenuAdapter searchResultsAdapter;

    private DatabaseHelper db;
    private SessionManager sessionManager;
    private List<String> searchHistory;
    private List<MenuItem> searchResults;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_search, container, false);

        // Initialize
        db = new DatabaseHelper(getActivity());
        sessionManager = new SessionManager(getActivity());

        // Find views
        etSearch = view.findViewById(R.id.etSearch);
        ivClearSearch = view.findViewById(R.id.ivClearSearch);
        tvClearHistory = view.findViewById(R.id.tvClearHistory);
        tvNoHistory = view.findViewById(R.id.tvNoHistory);
        tvResultCount = view.findViewById(R.id.tvResultCount);
        tvNoResults = view.findViewById(R.id.tvNoResults);
        searchHistorySection = view.findViewById(R.id.searchHistorySection);
        popularSearchSection = view.findViewById(R.id.popularSearchSection);
        categoriesSection = view.findViewById(R.id.categoriesSection);
        searchResultsSection = view.findViewById(R.id.searchResultsSection);
        rvSearchHistory = view.findViewById(R.id.rvSearchHistory);
        rvSearchCategories = view.findViewById(R.id.rvSearchCategories);
        rvSearchResults = view.findViewById(R.id.rvSearchResults);
        chipGroupPopular = view.findViewById(R.id.chipGroupPopular);

        // Setup RecyclerViews
        setupSearchHistoryRecyclerView();
        setupCategoriesRecyclerView();
        setupSearchResultsRecyclerView();
        setupPopularSearchChips();

        // Load data
        loadSearchHistory();

        // Set listeners
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0) {
                    ivClearSearch.setVisibility(View.VISIBLE);
                    performSearch(s.toString());
                } else {
                    ivClearSearch.setVisibility(View.GONE);
                    showDefaultView();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        etSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    String query = etSearch.getText().toString().trim();
                    if (!query.isEmpty()) {
                        saveSearchQuery(query);
                        performSearch(query);
                    }
                    return true;
                }
                return false;
            }
        });

        ivClearSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etSearch.setText("");
                showDefaultView();
            }
        });

        tvClearHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearSearchHistory();
            }
        });

        return view;
    }

    private void setupSearchHistoryRecyclerView() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        rvSearchHistory.setLayoutManager(layoutManager);

        searchHistory = new ArrayList<>();
        historyAdapter = new SearchHistoryAdapter(getActivity(), searchHistory,
                new SearchHistoryAdapter.OnHistoryActionListener() {
                    @Override
                    public void onHistoryClick(String query) {
                        etSearch.setText(query);
                        etSearch.setSelection(query.length());
                        performSearch(query);
                    }

                    @Override
                    public void onDeleteClick(String query) {
                        deleteSearchHistoryItem(query);
                    }
                });
        rvSearchHistory.setAdapter(historyAdapter);
    }

    private void setupCategoriesRecyclerView() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        rvSearchCategories.setLayoutManager(layoutManager);

        List<String> categories = Arrays.asList("Makanan Berat", "Makanan Ringan", "Minuman", "Dessert");
        List<String> categoryIcons = Arrays.asList("🍜", "🍕", "🥤", "🍰");

        categoryAdapter = new SearchCategoryAdapter(getActivity(), categories, categoryIcons,
                new SearchCategoryAdapter.OnCategoryClickListener() {
                    @Override
                    public void onCategoryClick(String category) {
                        etSearch.setText(category);
                        performSearch(category);
                    }
                });
        rvSearchCategories.setAdapter(categoryAdapter);
    }

    private void setupSearchResultsRecyclerView() {
        GridLayoutManager layoutManager = new GridLayoutManager(getActivity(), 1);
        rvSearchResults.setLayoutManager(layoutManager);

        searchResults = new ArrayList<>();
        searchResultsAdapter = new MenuAdapter(getActivity(), searchResults,
                new MenuAdapter.OnItemActionListener() {
                    @Override
                    public void onAddToCart(MenuItem item) {
                        addToCart(item);
                    }

                    @Override
                    public void onFavoriteClick(MenuItem item, boolean isFavorite) {
                        toggleFavorite(item, isFavorite);
                    }

                    @Override
                    public void onItemClick(MenuItem item) {
                        Toast.makeText(getActivity(), item.getName(), Toast.LENGTH_SHORT).show();
                    }
                });
        rvSearchResults.setAdapter(searchResultsAdapter);
    }

    private void setupPopularSearchChips() {
        List<String> popularSearches = Arrays.asList(
                "Nasi Goreng", "Ayam Geprek", "Es Teh", "Mie Goreng",
                "Kopi", "Jus", "Dessert", "Dimsum"
        );

        for (String search : popularSearches) {
            Chip chip = new Chip(getActivity());
            chip.setText(search);
            chip.setChipBackgroundColorResource(R.color.white);
            chip.setChipStrokeColorResource(R.color.divider);
            chip.setChipStrokeWidth(2f);
            chip.setTextColor(getResources().getColor(R.color.text_primary));
            chip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    etSearch.setText(search);
                    performSearch(search);
                }
            });
            chipGroupPopular.addView(chip);
        }
    }

    private void loadSearchHistory() {
        searchHistory.clear();
        searchHistory.addAll(db.getSearchHistory(sessionManager.getUserId()));

        if (searchHistory.isEmpty()) {
            tvNoHistory.setVisibility(View.VISIBLE);
            rvSearchHistory.setVisibility(View.GONE);
        } else {
            tvNoHistory.setVisibility(View.GONE);
            rvSearchHistory.setVisibility(View.VISIBLE);
        }

        historyAdapter.notifyDataSetChanged();
    }

    private void performSearch(String query) {
        searchResults.clear();
        searchResults.addAll(db.searchMenuItems(query));

        // Show search results section
        searchHistorySection.setVisibility(View.GONE);
        popularSearchSection.setVisibility(View.GONE);
        categoriesSection.setVisibility(View.GONE);
        searchResultsSection.setVisibility(View.VISIBLE);

        // Update result count
        tvResultCount.setText("Ditemukan " + searchResults.size() + " hasil");

        if (searchResults.isEmpty()) {
            tvNoResults.setVisibility(View.VISIBLE);
            rvSearchResults.setVisibility(View.GONE);
        } else {
            tvNoResults.setVisibility(View.GONE);
            rvSearchResults.setVisibility(View.VISIBLE);
        }

        searchResultsAdapter.notifyDataSetChanged();
    }

    private void showDefaultView() {
        searchHistorySection.setVisibility(View.VISIBLE);
        popularSearchSection.setVisibility(View.VISIBLE);
        categoriesSection.setVisibility(View.VISIBLE);
        searchResultsSection.setVisibility(View.GONE);
        loadSearchHistory();
    }

    private void saveSearchQuery(String query) {
        db.addSearchHistory(sessionManager.getUserId(), query, FormatHelper.getCurrentDateTime());
        loadSearchHistory();
    }

    private void deleteSearchHistoryItem(String query) {
        db.deleteSearchHistoryItem(sessionManager.getUserId(), query);
        loadSearchHistory();
        Toast.makeText(getActivity(), "Riwayat dihapus", Toast.LENGTH_SHORT).show();
    }

    private void clearSearchHistory() {
        db.clearSearchHistory(sessionManager.getUserId());
        loadSearchHistory();
        Toast.makeText(getActivity(), "Semua riwayat dihapus", Toast.LENGTH_SHORT).show();
    }

    private void addToCart(MenuItem item) {
        CartItem cartItem = new CartItem(
                sessionManager.getUserId(),
                item.getId(),
                item.getName(),
                item.getFinalPrice(),
                item.getImagePath(),
                1,
                ""
        );

        long result = db.addToCart(cartItem);

        if (result > 0) {
            Toast.makeText(getActivity(), item.getName() + " ditambahkan ke keranjang",
                    Toast.LENGTH_SHORT).show();

            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).updateCartBadge();
            }
        } else {
            Toast.makeText(getActivity(), "Gagal menambahkan ke keranjang",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleFavorite(MenuItem item, boolean isFavorite) {
        int userId = sessionManager.getUserId();
        int menuId = item.getId();

        if (isFavorite) {
            db.removeFavorite(userId, menuId);
            Toast.makeText(getActivity(), "Dihapus dari favorit", Toast.LENGTH_SHORT).show();
        } else {
            db.addFavorite(userId, menuId);
            Toast.makeText(getActivity(), "Ditambahkan ke favorit", Toast.LENGTH_SHORT).show();
        }
        performSearch(etSearch.getText().toString());
    }

    @Override
    public void onResume() {
        super.onResume();
        loadSearchHistory();
    }
}