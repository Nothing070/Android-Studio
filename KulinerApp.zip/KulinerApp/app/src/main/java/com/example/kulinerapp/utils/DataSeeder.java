package com.example.kulinerapp.utils;

import android.content.Context;

import com.example.kulinerapp.R;
import com.example.kulinerapp.database.DatabaseHelper;
import com.example.kulinerapp.models.MenuItem;
import com.example.kulinerapp.models.User;
import com.example.kulinerapp.models.Voucher;

public class DataSeeder {

    private DatabaseHelper db;

    public DataSeeder(Context context) {
        db = new DatabaseHelper(context);
    }

    public void seedData() {
        // Check if data already exists
        if (db.getAllMenuItems().size() > 0) {
            return;
        }

        // Add admin user
        User admin = new User("Admin", "admin@kuliner.com", "08123456789",
                "admin123", true);
        db.addUser(admin);

        // Add regular user for testing
        User user = new User("User Test", "user@test.com", "08198765432",
                "user123", false);
        db.addUser(user);

        // Seed Menu Items - Makanan Berat
        db.addMenuItem(new MenuItem("Nasi Goreng Special",
                "Nasi goreng dengan telur, ayam, dan sayuran segar",
                25000, "Makanan Berat", R.drawable.ic_launcher_foreground,
                4.5f, 0, true));

        db.addMenuItem(new MenuItem("Mie Goreng Seafood",
                "Mie goreng dengan udang, cumi, dan sayuran",
                30000, "Makanan Berat", R.drawable.ic_launcher_foreground,
                4.7f, 15, true));

        db.addMenuItem(new MenuItem("Ayam Geprek",
                "Ayam crispy dengan sambal geprek pedas",
                22000, "Makanan Berat", R.drawable.ic_launcher_foreground,
                4.8f, 0, true));

        db.addMenuItem(new MenuItem("Soto Ayam",
                "Soto ayam kuah kuning dengan nasi",
                20000, "Makanan Berat", R.drawable.ic_launcher_foreground,
                4.3f, 10, true));

        db.addMenuItem(new MenuItem("Rendang Sapi",
                "Rendang sapi empuk dengan nasi putih",
                35000, "Makanan Berat", R.drawable.ic_launcher_foreground,
                4.9f, 0, true));

        db.addMenuItem(new MenuItem("Gado-Gado",
                "Sayuran rebus dengan bumbu kacang",
                18000, "Makanan Berat", R.drawable.ic_launcher_foreground,
                4.2f, 0, true));

        // Seed Menu Items - Makanan Ringan
        db.addMenuItem(new MenuItem("Risoles Mayo",
                "Risoles isi sayur dengan mayonaise",
                15000, "Makanan Ringan", R.drawable.ic_launcher_foreground,
                4.4f, 20, true));

        db.addMenuItem(new MenuItem("Pisang Goreng Coklat",
                "Pisang goreng dengan topping coklat",
                12000, "Makanan Ringan", R.drawable.ic_launcher_foreground,
                4.6f, 0, true));

        db.addMenuItem(new MenuItem("Lumpia Basah",
                "Lumpia isi rebung dan sayuran",
                10000, "Makanan Ringan", R.drawable.ic_launcher_foreground,
                4.1f, 0, true));

        db.addMenuItem(new MenuItem("Tahu Crispy",
                "Tahu goreng crispy dengan saus",
                8000, "Makanan Ringan", R.drawable.ic_launcher_foreground,
                4.3f, 25, true));

        db.addMenuItem(new MenuItem("Dimsum Ayam",
                "Dimsum ayam kukus isi 4",
                18000, "Makanan Ringan", R.drawable.ic_launcher_foreground,
                4.7f, 0, true));

        // Seed Menu Items - Minuman
        db.addMenuItem(new MenuItem("Es Teh Manis",
                "Es teh manis segar",
                5000, "Minuman", R.drawable.ic_launcher_foreground,
                4.0f, 0, true));

        db.addMenuItem(new MenuItem("Es Jeruk",
                "Es jeruk peras segar",
                8000, "Minuman", R.drawable.ic_launcher_foreground,
                4.5f, 0, true));

        db.addMenuItem(new MenuItem("Jus Alpukat",
                "Jus alpukat segar tanpa gula",
                15000, "Minuman", R.drawable.ic_launcher_foreground,
                4.6f, 0, true));

        db.addMenuItem(new MenuItem("Kopi Susu",
                "Kopi susu gula aren",
                12000, "Minuman", R.drawable.ic_launcher_foreground,
                4.8f, 0, true));

        db.addMenuItem(new MenuItem("Thai Tea",
                "Thai tea original",
                10000, "Minuman", R.drawable.ic_launcher_foreground,
                4.4f, 15, true));

        db.addMenuItem(new MenuItem("Milkshake Coklat",
                "Milkshake coklat dengan whipped cream",
                18000, "Minuman", R.drawable.ic_launcher_foreground,
                4.7f, 20, true));

        // Seed Menu Items - Dessert
        db.addMenuItem(new MenuItem("Es Krim Vanilla",
                "Es krim vanilla premium",
                15000, "Dessert", R.drawable.ic_launcher_foreground,
                4.5f, 0, true));

        db.addMenuItem(new MenuItem("Pudding Coklat",
                "Pudding coklat lembut",
                12000, "Dessert", R.drawable.ic_launcher_foreground,
                4.3f, 0, true));

        db.addMenuItem(new MenuItem("Pancake",
                "Pancake dengan madu dan butter",
                20000, "Dessert", R.drawable.ic_launcher_foreground,
                4.6f, 10, true));

        db.addMenuItem(new MenuItem("Klepon",
                "Klepon isi gula merah",
                8000, "Dessert", R.drawable.ic_launcher_foreground,
                4.2f, 0, true));

        // Seed Vouchers
        db.addVoucher(new Voucher("DISKON20", "Diskon 20%",
                "Diskon 20% untuk pembelian minimal Rp 50.000",
                20, 0, 50000, "2025-12-31 23:59:59", true,
                R.drawable.ic_voucher));

        db.addVoucher(new Voucher("GRATIS10K", "Gratis Ongkir Rp 10.000",
                "Gratis ongkir Rp 10.000 untuk semua pesanan",
                0, 10000, 0, "2025-12-31 23:59:59", true,
                R.drawable.ic_voucher));

        db.addVoucher(new Voucher("HEMAT30", "Hemat Rp 30.000",
                "Potongan Rp 30.000 untuk pembelian minimal Rp 100.000",
                0, 30000, 100000, "2025-12-31 23:59:59", true,
                R.drawable.ic_voucher));

        db.addVoucher(new Voucher("WELCOME15", "Welcome Bonus 15%",
                "Diskon 15% untuk pengguna baru",
                15, 0, 30000, "2025-12-31 23:59:59", true,
                R.drawable.ic_voucher));

        db.addVoucher(new Voucher("NEWUSER", "Diskon Member Baru 25%",
                "Khusus member baru, diskon 25%",
                25, 0, 20000, "2025-12-31 23:59:59", true,
                R.drawable.ic_voucher));
    }
}