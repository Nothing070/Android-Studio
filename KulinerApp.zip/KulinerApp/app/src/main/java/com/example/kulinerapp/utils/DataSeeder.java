package com.example.kulinerapp.utils;

import android.content.Context;

import com.example.kulinerapp.R;
import com.example.kulinerapp.database.DatabaseHelper;
import com.example.kulinerapp.models.MenuItem;
import com.example.kulinerapp.models.User;
import com.example.kulinerapp.models.Voucher;

public class DataSeeder {

    private final DatabaseHelper db;

    public DataSeeder(Context context) {
        db = new DatabaseHelper(context);
    }

    public void seedData() {
        // Hanya jalankan sekali
        if (db.getAllMenuItems().size() > 0) {
            return;
        }

        // === USER ADMIN & USER TEST ===
        User admin = new User("Admin", "admin@kuliner.com", "08123456789", "admin123", true);
        db.addUser(admin);

        User user = new User("User Test", "user@test.com", "08198765432", "user123", false);
        db.addUser(user);

        // === MENU ITEMS - PAKAI STRING imagePath (sesuai MenuItem baru) ===
        // Format: new MenuItem(name, desc, price, category, "filename.jpg", rating, discount, available)

        // Makanan Berat
        db.addMenuItem(new MenuItem("Nasi Goreng Special", "Nasi goreng kampung dengan telur ceplok & ayam suwir", 25000, "Makanan Berat", "nasi_goreng.jpg", 4.8f, 10, true));
        db.addMenuItem(new MenuItem("Mie Goreng Seafood", "Mie goreng spesial dengan udang, cumi & kerang", 30000, "Makanan Berat", "mie_goreng.jpg", 4.7f, 15, true));
        db.addMenuItem(new MenuItem("Ayam Geprek Sambal Ijo", "Ayam crispy geprek dengan sambal ijo pedas", 22000, "Makanan Berat", "ayam_geprek.jpg", 4.9f, 20, true));
        db.addMenuItem(new MenuItem("Soto Ayam Kampung", "Soto ayam kuah bening dengan suwiran ayam & tauge", 20000, "Makanan Berat", "soto_ayam.jpg", 4.6f, 0, true));
        db.addMenuItem(new MenuItem("Rendang Daging Sapi", "Rendang padang autentik, empuk & kaya rempah", 35000, "Makanan Berat", "rendang.jpg", 4.9f, 0, true));

        // Makanan Ringan
        db.addMenuItem(new MenuItem("Risoles Ragout Mayo", "Risoles isi ayam ragout dengan saus mayo", 15000, "Makanan Ringan", "risoles.jpg", 4.5f, 25, true));
        db.addMenuItem(new MenuItem("Pisang Goreng Madu", "Pisang goreng renyah disiram madu asli", 12000, "Makanan Ringan", "pisang_goreng.jpg", 4.7f, 0, true));
        db.addMenuItem(new MenuItem("Tahu Crispy Saus", "Tahu goreng tepung crispy + saus spesial", 8000, "Makanan Ringan", "tahu_crispy.jpg", 4.4f, 30, true));
        db.addMenuItem(new MenuItem("Dimsum Ayam Kukus", "Dimsum isi ayam halus, disajikan panas (4 pcs)", 18000, "Makanan Ringan", "dimsum.jpg", 4.8f, 0, true));

        // Minuman
        db.addMenuItem(new MenuItem("Es Teh Manis", "Es teh manis dingin dengan es batu melimpah", 5000, "Minuman", "es_teh.jpg", 4.5f, 0, true));
        db.addMenuItem(new MenuItem("Es Jeruk Peras", "Jeruk peras segar tanpa gula tambahan", 8000, "Minuman", "es_jeruk.jpg", 4.6f, 0, true));
        db.addMenuItem(new MenuItem("Jus Alpukat Extra", "Jus alpukat creamy + susu kental manis", 15000, "Minuman", "jus_alpukat.jpg", 4.8f, 10, true));
        db.addMenuItem(new MenuItem("Kopi Susu Gula Aren", "Kopi hitam robusta + gula aren asli", 12000, "Minuman", "kopi_susu.jpg", 4.9f, 0, true));
        db.addMenuItem(new MenuItem("Thai Tea Boba", "Thai tea original + boba kenyal", 15000, "Minuman", "thai_tea.jpg", 4.7f, 15, true));

        // Dessert
        db.addMenuItem(new MenuItem("Es Krim Vanilla Cone", "Es krim vanilla premium dengan cone renyah", 15000, "Dessert", "es_krim.jpg", 4.6f, 0, true));
        db.addMenuItem(new MenuItem("Pancake Madu Butter", "Pancake lembut dengan madu & butter meleleh", 20000, "Dessert", "pancake.jpg", 4.8f, 10, true));
        db.addMenuItem(new MenuItem("Klepon Gula Merah", "Klepon kenyal isi gula merah cair (5 pcs)", 8000, "Dessert", "klepon.jpg", 4.5f, 0, true));

        // === VOUCHER (R.drawable.ic_voucher sudah ada di drawable-mu) ===
        db.addVoucher(new Voucher("DISKON20", "Diskon 20%", "Diskon 20% untuk minimal belanja Rp50.000", 20, 0, 50000, "2025-12-31", true, R.drawable.ic_voucher));
        db.addVoucher(new Voucher("GRATIS10K", "Gratis Ongkir Rp10K", "Bebas ongkir hingga Rp10.000", 0, 10000, 0, "2025-12-31", true, R.drawable.ic_voucher));
        db.addVoucher(new Voucher("HEMAT30", "Hemat Rp30K", "Potongan langsung Rp30.000", 0, 30000, 100000, "2025-12-31", true, R.drawable.ic_voucher));
        db.addVoucher(new Voucher("WELCOME15", "Welcome Bonus 15%", "Khusus pengguna baru", 15, 0, 30000, "2025-12-31", true, R.drawable.ic_voucher));
        db.addVoucher(new Voucher("FREESHIP", "Free Shipping", "Gratis ongkir tanpa minimum", 0, 15000, 0, "2025-12-31", true, R.drawable.ic_voucher));
    }
}