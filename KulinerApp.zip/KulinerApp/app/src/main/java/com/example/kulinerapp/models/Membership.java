package com.example.kulinerapp.models;

public class Membership {
    private int id;
    private int userId;
    private String memberType; // Silver, Gold, Platinum
    private int points;
    private String joinDate;
    private String expiredDate;

    public Membership() {
    }

    public Membership(int id, int userId, String memberType, int points,
                      String joinDate, String expiredDate) {
        this.id = id;
        this.userId = userId;
        this.memberType = memberType;
        this.points = points;
        this.joinDate = joinDate;
        this.expiredDate = expiredDate;
    }

    public Membership(int userId, String memberType, int points,
                      String joinDate, String expiredDate) {
        this.userId = userId;
        this.memberType = memberType;
        this.points = points;
        this.joinDate = joinDate;
        this.expiredDate = expiredDate;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getMemberType() { return memberType; }
    public void setMemberType(String memberType) { this.memberType = memberType; }

    public int getPoints() { return points; }
    public void setPoints(int points) { this.points = points; }

    public String getJoinDate() { return joinDate; }
    public void setJoinDate(String joinDate) { this.joinDate = joinDate; }

    public String getExpiredDate() { return expiredDate; }
    public void setExpiredDate(String expiredDate) { this.expiredDate = expiredDate; }
}