package com.example.kulinerapp.adapters;

import android.content.Context;
import android.net.Uri;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.R;
import com.example.kulinerapp.models.CartItem;
import com.example.kulinerapp.utils.FormatHelper;

import java.io.File;
import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {

    private Context context;
    private List<CartItem> cartItems;
    private OnCartActionListener listener;

    public interface OnCartActionListener {
        void onQuantityChanged(CartItem item, int newQuantity);
        void onDeleteItem(CartItem item);
        void onNotesChanged(CartItem item, String notes);
    }

    public CartAdapter(Context context, List<CartItem> cartItems, OnCartActionListener listener) {
        this.context = context;
        this.cartItems = cartItems;
        this.listener = listener;
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_cart, parent, false);
        return new CartViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        CartItem item = cartItems.get(position);

        holder.tvCartItemName.setText(item.getMenuName());
        holder.tvCartItemPrice.setText(FormatHelper.formatRupiah(item.getMenuPrice()));
        holder.tvCartItemSubtotal.setText(FormatHelper.formatRupiah(item.getSubtotal()));
        holder.tvQuantity.setText(String.valueOf(item.getQuantity()));

        // LOAD GAMBAR – INI YANG TADI RUSAK, SEKARANG SUDAH BENAR 100%
        int imageId = item.getMenuImage();
        if (imageId != 0) {
            File imgFile = new File(context.getFilesDir(), "menu_" + imageId + ".jpg");
            if (imgFile.exists()) {
                holder.ivCartItem.setImageURI(Uri.fromFile(imgFile));
            } else {
                holder.ivCartItem.setImageResource(R.drawable.ic_add_photo_big);
            }
        } else {
            holder.ivCartItem.setImageResource(R.drawable.ic_add_photo_big);
        }

        // Catatan
        if (item.getNotes() != null && !item.getNotes().trim().isEmpty()) {
            holder.notesSection.setVisibility(View.VISIBLE);
            holder.etNotes.setText(item.getNotes());
            holder.tvAddNotes.setText("Catatan ditambahkan");
        } else {
            holder.notesSection.setVisibility(View.GONE);
            holder.tvAddNotes.setText("+ Tambah Catatan");
        }

        holder.btnDecreaseQty.setOnClickListener(v -> {
            Animation a = AnimationUtils.loadAnimation(context, R.anim.bounce);
            v.startAnimation(a);
            int qty = item.getQuantity() - 1;
            if (qty >= 1) listener.onQuantityChanged(item, qty);
        });

        holder.btnIncreaseQty.setOnClickListener(v -> {
            Animation a = AnimationUtils.loadAnimation(context, R.anim.bounce);
            v.startAnimation(a);
            listener.onQuantityChanged(item, item.getQuantity() + 1);
        });

        holder.ivDeleteCart.setOnClickListener(v -> {
            Animation a = AnimationUtils.loadAnimation(context, R.anim.bounce);
            v.startAnimation(a);
            listener.onDeleteItem(item);
        });

        holder.tvAddNotes.setOnClickListener(v -> {
            if (holder.notesSection.getVisibility() == View.GONE) {
                holder.notesSection.setVisibility(View.VISIBLE);
                holder.tvAddNotes.setText("Catatan ditambahkan");
                holder.etNotes.requestFocus();
            } else {
                holder.notesSection.setVisibility(View.GONE);
                holder.tvAddNotes.setText("+ Tambah Catatan");
            }
        });

        holder.etNotes.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                listener.onNotesChanged(item, s.toString().trim());
            }
        });

        Animation slideIn = AnimationUtils.loadAnimation(context, R.anim.slide_in_right);
        holder.itemView.startAnimation(slideIn);
    }

    @Override
    public int getItemCount() {
        return cartItems != null ? cartItems.size() : 0;
    }

    static class CartViewHolder extends RecyclerView.ViewHolder {
        ImageView ivCartItem, btnDecreaseQty, btnIncreaseQty, ivDeleteCart;
        TextView tvCartItemName, tvCartItemPrice, tvQuantity, tvCartItemSubtotal, tvAddNotes;
        LinearLayout notesSection;
        EditText etNotes;

        public CartViewHolder(@NonNull View itemView) {
            super(itemView);
            ivCartItem = itemView.findViewById(R.id.ivCartItem);
            btnDecreaseQty = itemView.findViewById(R.id.btnDecreaseQty);
            btnIncreaseQty = itemView.findViewById(R.id.btnIncreaseQty);
            ivDeleteCart = itemView.findViewById(R.id.ivDeleteCart);
            tvCartItemName = itemView.findViewById(R.id.tvCartItemName);
            tvCartItemPrice = itemView.findViewById(R.id.tvCartItemPrice);
            tvQuantity = itemView.findViewById(R.id.tvQuantity);
            tvCartItemSubtotal = itemView.findViewById(R.id.tvCartItemSubtotal);
            tvAddNotes = itemView.findViewById(R.id.tvAddNotes);
            notesSection = itemView.findViewById(R.id.notesSection);
            etNotes = itemView.findViewById(R.id.etNotes);
        }
    }
}