package com.example.kulinerapp.adapters;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kulinerapp.R;
import com.example.kulinerapp.models.CartItem;
import com.example.kulinerapp.utils.FormatHelper;

import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {

    private Context context;
    private List<CartItem> cartItems;
    private OnCartActionListener listener;

    public interface OnCartActionListener {
        void onQuantityChanged(CartItem item, int newQuantity);
        void onDeleteItem(CartItem item);
        void onNotesChanged(CartItem item, String notes);
    }

    public CartAdapter(Context context, List<CartItem> cartItems, OnCartActionListener listener) {
        this.context = context;
        this.cartItems = cartItems;
        this.listener = listener;
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_cart, parent, false);
        return new CartViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        CartItem item = cartItems.get(position);

        holder.tvCartItemName.setText(item.getMenuName());
        holder.tvCartItemPrice.setText(FormatHelper.formatCurrency(item.getMenuPrice()));
        holder.tvQuantity.setText(String.valueOf(item.getQuantity()));
        holder.tvCartItemSubtotal.setText(FormatHelper.formatCurrency(item.getSubtotal()));
        holder.ivCartItem.setImageResource(item.getMenuImage());

        // Set notes if available
        if (item.getNotes() != null && !item.getNotes().isEmpty()) {
            holder.notesSection.setVisibility(View.VISIBLE);
            holder.etNotes.setText(item.getNotes());
            holder.tvAddNotes.setText("✓ Catatan ditambahkan");
        } else {
            holder.notesSection.setVisibility(View.GONE);
            holder.tvAddNotes.setText("+ Tambah Catatan");
        }

        // Decrease quantity
        holder.btnDecreaseQty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Animation bounce = AnimationUtils.loadAnimation(context, R.anim.bounce);
                v.startAnimation(bounce);
                int newQuantity = item.getQuantity() - 1;
                listener.onQuantityChanged(item, newQuantity);
            }
        });

        // Increase quantity
        holder.btnIncreaseQty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Animation bounce = AnimationUtils.loadAnimation(context, R.anim.bounce);
                v.startAnimation(bounce);
                int newQuantity = item.getQuantity() + 1;
                listener.onQuantityChanged(item, newQuantity);
            }
        });

        // Delete item
        holder.ivDeleteCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Animation bounce = AnimationUtils.loadAnimation(context, R.anim.bounce);
                v.startAnimation(bounce);
                listener.onDeleteItem(item);
            }
        });

        // Add/Edit notes
        holder.tvAddNotes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (holder.notesSection.getVisibility() == View.GONE) {
                    holder.notesSection.setVisibility(View.VISIBLE);
                    holder.tvAddNotes.setText("✓ Catatan ditambahkan");
                    holder.etNotes.requestFocus();
                } else {
                    holder.notesSection.setVisibility(View.GONE);
                    holder.tvAddNotes.setText("+ Tambah Catatan");
                }
            }
        });

        // Notes text changed listener
        holder.etNotes.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                item.setNotes(s.toString());
                listener.onNotesChanged(item, s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Apply animation
        Animation slideIn = AnimationUtils.loadAnimation(context, R.anim.slide_in_right);
        holder.itemView.startAnimation(slideIn);
    }

    @Override
    public int getItemCount() {
        return cartItems.size();
    }

    static class CartViewHolder extends RecyclerView.ViewHolder {
        ImageView ivCartItem, btnDecreaseQty, btnIncreaseQty, ivDeleteCart;
        TextView tvCartItemName, tvCartItemPrice, tvQuantity, tvCartItemSubtotal, tvAddNotes;
        LinearLayout notesSection;
        EditText etNotes;

        public CartViewHolder(@NonNull View itemView) {
            super(itemView);
            ivCartItem = itemView.findViewById(R.id.ivCartItem);
            btnDecreaseQty = itemView.findViewById(R.id.btnDecreaseQty);
            btnIncreaseQty = itemView.findViewById(R.id.btnIncreaseQty);
            ivDeleteCart = itemView.findViewById(R.id.ivDeleteCart);
            tvCartItemName = itemView.findViewById(R.id.tvCartItemName);
            tvCartItemPrice = itemView.findViewById(R.id.tvCartItemPrice);
            tvQuantity = itemView.findViewById(R.id.tvQuantity);
            tvCartItemSubtotal = itemView.findViewById(R.id.tvCartItemSubtotal);
            tvAddNotes = itemView.findViewById(R.id.tvAddNotes);
            notesSection = itemView.findViewById(R.id.notesSection);
            etNotes = itemView.findViewById(R.id.etNotes);
        }
    }
}