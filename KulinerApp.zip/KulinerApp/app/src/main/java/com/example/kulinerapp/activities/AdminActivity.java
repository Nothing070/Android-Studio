package com.example.kulinerapp.activities;

import android.content.Context;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import com.example.kulinerapp.R;
import com.example.kulinerapp.fragments.AdminMenuFragment;
import com.example.kulinerapp.fragments.AdminOrdersFragment;
import com.example.kulinerapp.utils.LocaleHelper;
import com.example.kulinerapp.utils.SessionManager;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import android.widget.ImageView;

public class AdminActivity extends AppCompatActivity {

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(LocaleHelper.onAttach(newBase));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        ImageView ivBack = findViewById(R.id.ivBack);
        TabLayout tabLayout = findViewById(R.id.tabLayout);
        ViewPager2 viewPager = findViewById(R.id.viewPager);

        viewPager.setAdapter(new AdminPagerAdapter(this));

        new TabLayoutMediator(tabLayout, viewPager, (tab, position) -> {
            if (position == 0) {
                tab.setText("Menu");
                tab.setIcon(R.drawable.ic_food);
            } else {
                tab.setText("Pesanan");
                tab.setIcon(R.drawable.ic_order);
            }
        }).attach();

        ivBack.setOnClickListener(v -> finish());
    }

    private static class AdminPagerAdapter extends FragmentStateAdapter {
        public AdminPagerAdapter(@NonNull AppCompatActivity activity) {
            super(activity);
        }

        @NonNull @Override
        public Fragment createFragment(int position) {
            return position == 0 ? new AdminMenuFragment() : new AdminOrdersFragment();
        }

        @Override
        public int getItemCount() {
            return 2;
        }
    }
}