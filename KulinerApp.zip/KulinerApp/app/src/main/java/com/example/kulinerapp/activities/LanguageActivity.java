package com.example.kulinerapp.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.kulinerapp.MainActivity;
import com.example.kulinerapp.R;
import com.example.kulinerapp.SplashActivity;
import com.example.kulinerapp.utils.LocaleHelper;
import com.example.kulinerapp.utils.SessionManager;
import com.google.android.material.button.MaterialButton;

public class LanguageActivity extends AppCompatActivity {

    private ImageView ivBack;
    private RadioGroup radioGroupLanguage;
    private RadioButton rbIndonesia, rbEnglish, rbJava, rbSunda, rbMalay,
            rbChinese, rbJapanese, rbKorean, rbArabic, rbHindi;
    private CardView cardIndonesia, cardEnglish, cardJava, cardSunda, cardMalay,
            cardChinese, cardJapanese, cardKorean, cardArabic, cardHindi;
    private MaterialButton btnSave;

    private SessionManager sessionManager;
    private String selectedLanguage;

    @Override
    protected void attachBaseContext(Context newBase) {
        SessionManager sessionManager = new SessionManager(newBase);
        String savedLanguage = sessionManager.getLanguage();
        super.attachBaseContext(LocaleHelper.setLocale(newBase, savedLanguage));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language);

        // Initialize
        sessionManager = new SessionManager(this);
        selectedLanguage = sessionManager.getLanguage();

        // Find views
        ivBack = findViewById(R.id.ivBack);
        radioGroupLanguage = findViewById(R.id.radioGroupLanguage);
        rbIndonesia = findViewById(R.id.rbIndonesia);
        rbEnglish = findViewById(R.id.rbEnglish);
        rbJava = findViewById(R.id.rbJava);
        rbSunda = findViewById(R.id.rbSunda);
        rbMalay = findViewById(R.id.rbMalay);
        rbChinese = findViewById(R.id.rbChinese);
        rbJapanese = findViewById(R.id.rbJapanese);
        rbKorean = findViewById(R.id.rbKorean);
        rbArabic = findViewById(R.id.rbArabic);
        rbHindi = findViewById(R.id.rbHindi);
        btnSave = findViewById(R.id.btnSave);

        // Find CardViews (harus ada ID di XML)
        cardIndonesia = (CardView) rbIndonesia.getParent().getParent();
        cardEnglish = (CardView) rbEnglish.getParent().getParent();
        cardJava = (CardView) rbJava.getParent().getParent();
        cardSunda = (CardView) rbSunda.getParent().getParent();
        cardMalay = (CardView) rbMalay.getParent().getParent();
        cardChinese = (CardView) rbChinese.getParent().getParent();
        cardJapanese = (CardView) rbJapanese.getParent().getParent();
        cardKorean = (CardView) rbKorean.getParent().getParent();
        cardArabic = (CardView) rbArabic.getParent().getParent();
        cardHindi = (CardView) rbHindi.getParent().getParent();

        // Set current language selection
        setCurrentLanguageSelection();

        // Handle back press
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                finish();
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            }
        });

        // Set click listeners
        ivBack.setOnClickListener(v -> {
            finish();
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        });

        // ✅ CardView onClick - Ini yang penting!
        cardIndonesia.setOnClickListener(v -> selectLanguage(rbIndonesia, "id"));
        cardEnglish.setOnClickListener(v -> selectLanguage(rbEnglish, "en"));
        cardJava.setOnClickListener(v -> selectLanguage(rbJava, "jv"));
        cardSunda.setOnClickListener(v -> selectLanguage(rbSunda, "su"));
        cardMalay.setOnClickListener(v -> selectLanguage(rbMalay, "ms"));
        cardChinese.setOnClickListener(v -> selectLanguage(rbChinese, "zh"));
        cardJapanese.setOnClickListener(v -> selectLanguage(rbJapanese, "ja"));
        cardKorean.setOnClickListener(v -> selectLanguage(rbKorean, "ko"));
        cardArabic.setOnClickListener(v -> selectLanguage(rbArabic, "ar"));
        cardHindi.setOnClickListener(v -> selectLanguage(rbHindi, "hi"));

        // RadioButton onChange
        radioGroupLanguage.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rbIndonesia) {
                selectedLanguage = "id";
            } else if (checkedId == R.id.rbEnglish) {
                selectedLanguage = "en";
            } else if (checkedId == R.id.rbJava) {
                selectedLanguage = "jv";
            } else if (checkedId == R.id.rbSunda) {
                selectedLanguage = "su";
            } else if (checkedId == R.id.rbMalay) {
                selectedLanguage = "ms";
            } else if (checkedId == R.id.rbChinese) {
                selectedLanguage = "zh";
            } else if (checkedId == R.id.rbJapanese) {
                selectedLanguage = "ja";
            } else if (checkedId == R.id.rbKorean) {
                selectedLanguage = "ko";
            } else if (checkedId == R.id.rbArabic) {
                selectedLanguage = "ar";
            } else if (checkedId == R.id.rbHindi) {
                selectedLanguage = "hi";
            }
        });

        btnSave.setOnClickListener(v -> saveLanguage());
    }

    // ✅ Method untuk select language (uncheck semua, check yang dipilih)
    private void selectLanguage(RadioButton radioButton, String langCode) {
        // Uncheck all
        rbIndonesia.setChecked(false);
        rbEnglish.setChecked(false);
        rbJava.setChecked(false);
        rbSunda.setChecked(false);
        rbMalay.setChecked(false);
        rbChinese.setChecked(false);
        rbJapanese.setChecked(false);
        rbKorean.setChecked(false);
        rbArabic.setChecked(false);
        rbHindi.setChecked(false);

        // Check selected
        radioButton.setChecked(true);
        selectedLanguage = langCode;
    }

    private void setCurrentLanguageSelection() {
        switch (selectedLanguage) {
            case "id": rbIndonesia.setChecked(true); break;
            case "en": rbEnglish.setChecked(true); break;
            case "jv": rbJava.setChecked(true); break;
            case "su": rbSunda.setChecked(true); break;
            case "ms": rbMalay.setChecked(true); break;
            case "zh": rbChinese.setChecked(true); break;
            case "ja": rbJapanese.setChecked(true); break;
            case "ko": rbKorean.setChecked(true); break;
            case "ar": rbArabic.setChecked(true); break;
            case "hi": rbHindi.setChecked(true); break;
            default: rbIndonesia.setChecked(true); break;
        }
    }

    private void saveLanguage() {
        String oldLang = sessionManager.getLanguage();
        if (!selectedLanguage.equals(oldLang)) {
            sessionManager.setLanguage(selectedLanguage);
            Toast.makeText(this, "Bahasa diubah! Aplikasi diperbarui...", Toast.LENGTH_SHORT).show();

            new Handler().postDelayed(() -> {
                Intent intent = new Intent(this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            }, 300);
        } else {
            finish();
        }
    }
}