package com.example.kulinerapp.activities;

import android.content.Context;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.kulinerapp.MainActivity;
import com.example.kulinerapp.R;
import com.example.kulinerapp.utils.LocaleHelper;
import com.example.kulinerapp.utils.SessionManager;
import com.google.android.material.button.MaterialButton;

public class LanguageActivity extends AppCompatActivity {

    private ImageView ivBack;
    private RadioGroup radioGroupLanguage;
    private RadioButton rbIndonesia, rbEnglish, rbJava, rbSunda, rbMalay,
            rbChinese, rbJapanese, rbKorean, rbArabic, rbHindi;
    private MaterialButton btnSave;

    private SessionManager sessionManager;
    private String selectedLanguage = "id";

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(LocaleHelper.onAttach(newBase));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language);

        sessionManager = new SessionManager(this);
        selectedLanguage = sessionManager.getLanguage();
        if (selectedLanguage == null || selectedLanguage.isEmpty()) {
            selectedLanguage = "id";
        }

        initViews();
        loadCurrentLanguage();
        setupListeners();
    }

    private void initViews() {
        ivBack = findViewById(R.id.ivBack);
        radioGroupLanguage = findViewById(R.id.radioGroupLanguage);
        rbIndonesia = findViewById(R.id.rbIndonesia);
        rbEnglish = findViewById(R.id.rbEnglish);
        rbJava = findViewById(R.id.rbJava);
        rbSunda = findViewById(R.id.rbSunda);
        rbMalay = findViewById(R.id.rbMalay);
        rbChinese = findViewById(R.id.rbChinese);
        rbJapanese = findViewById(R.id.rbJapanese);
        rbKorean = findViewById(R.id.rbKorean);
        rbArabic = findViewById(R.id.rbArabic);
        rbHindi = findViewById(R.id.rbHindi);
        btnSave = findViewById(R.id.btnSave);
    }

    private void loadCurrentLanguage() {
        switch (selectedLanguage) {
            case "id": rbIndonesia.setChecked(true); break;
            case "en": rbEnglish.setChecked(true); break;
            case "jv": rbJava.setChecked(true); break;
            case "su": rbSunda.setChecked(true); break;
            case "ms": rbMalay.setChecked(true); break;
            case "zh": rbChinese.setChecked(true); break;
            case "ja": rbJapanese.setChecked(true); break;
            case "ko": rbKorean.setChecked(true); break;
            case "ar": rbArabic.setChecked(true); break;
            case "hi": rbHindi.setChecked(true); break;
            default: rbIndonesia.setChecked(true); selectedLanguage = "id"; break;
        }
    }

    private void setupListeners() {
        // Back button
        ivBack.setOnClickListener(v -> {
            finish();
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        });

        // RadioGroup listener — otomatis single choice & update selectedLanguage
        radioGroupLanguage.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rbIndonesia) {
                selectedLanguage = "id";
            } else if (checkedId == R.id.rbEnglish) {
                selectedLanguage = "en";
            } else if (checkedId == R.id.rbJava) {
                selectedLanguage = "jv";
            } else if (checkedId == R.id.rbSunda) {
                selectedLanguage = "su";
            } else if (checkedId == R.id.rbMalay) {
                selectedLanguage = "ms";
            } else if (checkedId == R.id.rbChinese) {
                selectedLanguage = "zh";
            } else if (checkedId == R.id.rbJapanese) {
                selectedLanguage = "ja";
            } else if (checkedId == R.id.rbKorean) {
                selectedLanguage = "ko";
            } else if (checkedId == R.id.rbArabic) {
                selectedLanguage = "ar";
            } else if (checkedId == R.id.rbHindi) {
                selectedLanguage = "hi";
            }
        });

        // Tombol Simpan — LANGSUNG BERUBAH TANPA KELUAR APP!
        btnSave.setOnClickListener(v -> {
            String oldLang = sessionManager.getLanguage();

            if (!selectedLanguage.equals(oldLang)) {
                // Simpan + ubah bahasa + refresh tampilan
                LocaleHelper.setLocale(this, selectedLanguage);
                sessionManager.setLanguage(selectedLanguage);

                Toast.makeText(this,
                        "Berhasil diubah ke " + LocaleHelper.getLanguageName(selectedLanguage),
                        Toast.LENGTH_LONG).show();

                // LANGSUNG RECREATE — BAHASA BERUBAH DI TEMPAT!
                recreate();
            } else {
                finish();
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            }
        });
    }
}