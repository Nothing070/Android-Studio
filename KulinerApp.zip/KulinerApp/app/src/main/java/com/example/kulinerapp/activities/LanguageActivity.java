package com.example.kulinerapp.activities;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;

import com.example.kulinerapp.BaseActivity;
import com.example.kulinerapp.R;
import com.example.kulinerapp.utils.LocaleHelper;

public class LanguageActivity extends BaseActivity {

    private CardView cardIndonesia, cardEnglish, cardJavanese, cardSundanese;
    private CardView cardMalay, cardChinese, cardJapanese, cardKorean, cardArabic, cardHindi;

    private ImageView checkIndonesia, checkEnglish, checkJava, checkSunda;
    private ImageView checkMalay, checkChinese, checkJapanese, checkKorean, checkArabic, checkHindi;

    private String selectedLanguage = "";
    private String currentLanguage = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language);

        initViews();

        currentLanguage = LocaleHelper.getCurrentLanguage(this);
        selectedLanguage = currentLanguage;

        updateCheckMark(currentLanguage);
        setupLanguageClickListeners();

        // Tombol Back
        findViewById(R.id.ivBack).setOnClickListener(v -> finish());

        // TOMBOL SIMPAN
        findViewById(R.id.btnSave).setOnClickListener(v -> {
            if (selectedLanguage.equals(currentLanguage)) {
                finish();
                return;
            }

            // 1. Simpan bahasa baru
            LocaleHelper.setLocale(this, selectedLanguage);

            // 2. Feedback ke user
            Toast.makeText(this, "Bahasa diubah ke " + LocaleHelper.getLanguageName(selectedLanguage),
                    Toast.LENGTH_SHORT).show();

            Intent intent = getPackageManager().getLaunchIntentForPackage(getPackageName());
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
            finish();
        });
    }

    private void initViews() {
        cardIndonesia = findViewById(R.id.cardIndonesia);
        cardEnglish = findViewById(R.id.cardEnglish);
        cardJavanese = findViewById(R.id.cardJavanese);
        cardSundanese = findViewById(R.id.cardSundanese);
        cardMalay = findViewById(R.id.cardMalay);
        cardChinese = findViewById(R.id.cardChinese);
        cardJapanese = findViewById(R.id.cardJapanese);
        cardKorean = findViewById(R.id.cardKorean);
        cardArabic = findViewById(R.id.cardArabic);
        cardHindi = findViewById(R.id.cardHindi);

        checkIndonesia = findViewById(R.id.checkIndonesia);
        checkEnglish = findViewById(R.id.checkEnglish);
        checkJava = findViewById(R.id.checkJava);
        checkSunda = findViewById(R.id.checkSunda);
        checkMalay = findViewById(R.id.checkMalay);
        checkChinese = findViewById(R.id.checkChinese);
        checkJapanese = findViewById(R.id.checkJapanese);
        checkKorean = findViewById(R.id.checkKorean);
        checkArabic = findViewById(R.id.checkArabic);
        checkHindi = findViewById(R.id.checkHindi);
    }

    private void setupLanguageClickListeners() {
        cardIndonesia.setOnClickListener(v -> selectLanguage("id"));
        cardEnglish.setOnClickListener(v -> selectLanguage("en"));
        cardJavanese.setOnClickListener(v -> selectLanguage("jv"));
        cardSundanese.setOnClickListener(v -> selectLanguage("su"));
        cardMalay.setOnClickListener(v -> selectLanguage("ms"));
        cardChinese.setOnClickListener(v -> selectLanguage("zh"));
        cardJapanese.setOnClickListener(v -> selectLanguage("ja"));
        cardKorean.setOnClickListener(v -> selectLanguage("ko"));
        cardArabic.setOnClickListener(v -> selectLanguage("ar"));
        cardHindi.setOnClickListener(v -> selectLanguage("hi"));
    }

    private void selectLanguage(String langCode) {
        selectedLanguage = langCode;
        updateCheckMark(langCode);
    }

    private void updateCheckMark(String langCode) {
        hideAllChecks();
        switch (langCode) {
            case "id": checkIndonesia.setVisibility(VISIBLE); break;
            case "en": checkEnglish.setVisibility(VISIBLE); break;
            case "jv": checkJava.setVisibility(VISIBLE); break;
            case "su": checkSunda.setVisibility(VISIBLE); break;
            case "ms": checkMalay.setVisibility(VISIBLE); break;
            case "zh": checkChinese.setVisibility(VISIBLE); break;
            case "ja": checkJapanese.setVisibility(VISIBLE); break;
            case "ko": checkKorean.setVisibility(VISIBLE); break;
            case "ar": checkArabic.setVisibility(VISIBLE); break;
            case "hi": checkHindi.setVisibility(VISIBLE); break;
        }
    }

    private void hideAllChecks() {
        checkIndonesia.setVisibility(GONE);
        checkEnglish.setVisibility(GONE);
        checkJava.setVisibility(GONE);
        checkSunda.setVisibility(GONE);
        checkMalay.setVisibility(GONE);
        checkChinese.setVisibility(GONE);
        checkJapanese.setVisibility(GONE);
        checkKorean.setVisibility(GONE);
        checkArabic.setVisibility(GONE);
        checkHindi.setVisibility(GONE);
    }
}