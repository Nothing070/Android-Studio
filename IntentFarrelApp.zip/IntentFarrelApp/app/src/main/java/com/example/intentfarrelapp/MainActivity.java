package com.example.intentfarrelapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button Football = findViewById(R.id.Football);
        Button Basketball = findViewById(R.id.Basketball);
        Button Tennis = findViewById(R.id.Tennis);
        Button Badminton = findViewById(R.id.Badminton);

        Football.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Football.class);
                startActivity(intent);
            }
        });
        Basketball.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Basketball.class);
                startActivity(intent);
            }
        });
        Tennis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Tennis.class);
                startActivity(intent);
            }
        });
        Badminton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Badminton.class);
                startActivity(intent);
            }
        });
    }
}