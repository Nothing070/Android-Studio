package com.example.weatherapp;

public class Kota {
    public String nama;
    public double lat;
    public double lon;
}