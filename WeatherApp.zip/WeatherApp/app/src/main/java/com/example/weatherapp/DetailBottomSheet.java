package com.example.weatherapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.squareup.picasso.Picasso;

public class DetailBottomSheet extends BottomSheetDialogFragment {

    private static final String ARG_KOTA = "kota";

    public static DetailBottomSheet newInstance(KotaCuaca kota) {
        DetailBottomSheet sheet = new DetailBottomSheet();
        Bundle args = new Bundle();
        args.putSerializable(ARG_KOTA, kota);
        sheet.setArguments(args);
        return sheet;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.bottom_sheet_detail, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(v, savedInstanceState);
        KotaCuaca kc = (KotaCuaca) getArguments().getSerializable(ARG_KOTA);

        ImageView ivIcon = v.findViewById(R.id.ivDetailIcon);
        TextView tvKota = v.findViewById(R.id.tvDetailKota);
        TextView tvSuhu = v.findViewById(R.id.tvDetailSuhu);
        TextView tvDesk = v.findViewById(R.id.tvDetailDesk);

        tvKota.setText(kc.nama);
        tvSuhu.setText(kc.suhu + "°C");
        tvDesk.setText(getDeskripsi(kc.weatherCode));
        Picasso.get().load(kc.iconUrl).into(ivIcon);
    }

    private String getDeskripsi(int code) {
        switch (code) {
            case 0: return "Langit cerah";
            case 1: return "Sebagian besar cerah";
            case 2: return "Berawan sebagian";
            case 3: return "Berawan total";
            case 45: case 48: return "Kabut";
            case 51: case 53: case 55: return "Gerimis ringan";
            case 61: case 63: case 65: return "Hujan ringan";
            default: return "Cuaca tidak diketahui";
        }
    }
}