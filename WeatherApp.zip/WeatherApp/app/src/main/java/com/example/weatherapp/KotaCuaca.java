package com.example.weatherapp;

public class KotaCuaca extends Kota implements java.io.Serializable {
    public double suhu;
    public int weatherCode;
    public String iconUrl;
}