package com.example.weatherapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class KotaAdapter extends RecyclerView.Adapter<KotaAdapter.ViewHolder> {

    private final List<KotaCuaca> list;

    public KotaAdapter(List<KotaCuaca> list) {
        this.list = list;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvNama, tvSuhu, tvDesk;
        ImageView ivIcon;

        ViewHolder(View v) {
            super(v);
            tvNama  = v.findViewById(R.id.tvNama);
            tvSuhu  = v.findViewById(R.id.tvSuhu);
            tvDesk  = v.findViewById(R.id.tvDesk);
            ivIcon  = v.findViewById(R.id.ivIcon);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_kota, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        KotaCuaca k = list.get(position);

        holder.tvNama.setText(k.nama);
        holder.tvSuhu.setText(k.suhu + "°C");
        holder.tvDesk.setText(getDeskripsi(k.weatherCode)); // <-- deskripsi, bukan kode
        Picasso.get().load(k.iconUrl).into(holder.ivIcon);

        holder.itemView.setAlpha(0f);
        holder.itemView.animate()
                .alpha(1f)
                .setStartDelay(position * 40)
                .setDuration(400)
                .start();

        holder.itemView.setOnClickListener(v ->
                DetailBottomSheet.newInstance(k)
                        .show(((AppCompatActivity) v.getContext())
                                .getSupportFragmentManager(), "detail")
        );
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    private String getDeskripsi(int code) {
        switch (code) {
            case 0:  return "Langit cerah";
            case 1:  return "Sebagian besar cerah";
            case 2:  return "Berawan sebagian";
            case 3:  return "Berawan total";
            case 45:
            case 48: return "Kabut";
            case 51:
            case 53:
            case 55: return "Gerimis ringan";
            case 61:
            case 63:
            case 65: return "Hujan ringan";
            default: return "Cuaca tidak diketahui";
        }
    }
}