package com.example.weatherapp;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private androidx.recyclerview.widget.RecyclerView recyclerView;
    private SwipeRefreshLayout swipeRefresh;
    private KotaAdapter adapter;
    private final List<KotaCuaca> listCuaca = new ArrayList<>();

    private boolean darkModeChecked = false;
    private final ExecutorService executor = Executors.newFixedThreadPool(10);
    private final Queue<Kota> queue = new LinkedList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");

        recyclerView = findViewById(R.id.recyclerView);
        swipeRefresh = findViewById(R.id.swipeRefresh);

        adapter = new KotaAdapter(listCuaca);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        swipeRefresh.setOnRefreshListener(() -> {
            listCuaca.clear();
            adapter.notifyDataSetChanged();
            loadKota();
            swipeRefresh.setRefreshing(false);
        });

        loadKota();
        updateDarkModeCheck();
    }

    /* ---------- MENU ---------- */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        int nightMode = AppCompatDelegate.getDefaultNightMode();
        boolean isLightMode =
                nightMode == AppCompatDelegate.MODE_NIGHT_NO ||
                        (nightMode == AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM &&
                                (getResources().getConfiguration().uiMode &
                                        android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
                                        android.content.res.Configuration.UI_MODE_NIGHT_NO);

        for (int i = 0; i < menu.size(); i++) {
            MenuItem item = menu.getItem(i);
            SpannableString s = new SpannableString(item.getTitle());
            s.setSpan(new ForegroundColorSpan(isLightMode ? Color.BLACK : Color.WHITE),
                    0, s.length(), 0);
            item.setTitle(s);
        }

        MenuItem darkItem = menu.findItem(R.id.menu_dark);
        if (darkItem != null) darkItem.setChecked(darkModeChecked);
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_rating) {
            Intent email = new Intent(Intent.ACTION_SENDTO);
            email.setData(Uri.parse("mailto:farrel.adyatma40@smk.belajar.id"));
            email.putExtra(Intent.EXTRA_SUBJECT, "Rating WeatherApp 100 Kota");
            startActivity(Intent.createChooser(email, "Kirim email"));
            return true;
        } else if (id == R.id.menu_dark) {
            boolean isDark = AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES;
            AppCompatDelegate.setDefaultNightMode(
                    isDark ? AppCompatDelegate.MODE_NIGHT_NO : AppCompatDelegate.MODE_NIGHT_YES);
            darkModeChecked = !isDark;

            // Hapus cache agar selalu reload saat ganti tema
            getSharedPreferences("cache", MODE_PRIVATE)
                    .edit()
                    .remove("last_fetch")
                    .apply();

            invalidateOptionsMenu();
            recreate();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /* ---------- LOAD DATA ---------- */
    private void loadKota() {
        // Tidak pakai cache tema-berubah
        try {
            InputStream is = getAssets().open("kota100.json");
            Type type = new TypeToken<List<Kota>>(){}.getType();
            List<Kota> listKota = new Gson().fromJson(new InputStreamReader(is), type);
            queue.clear();
            queue.addAll(listKota);

            for (int i = 0; i < 10 && !queue.isEmpty(); i++) fetchNext();
        } catch (Exception e) {
            Toast.makeText(this, "Gagal load kota", Toast.LENGTH_SHORT).show();
        }
    }

    private void fetchNext() {
        Kota k = queue.poll();
        if (k == null) return; // selesai
        executor.execute(() -> fetchWeather(k));
    }

    private void fetchWeather(Kota kota) {
        RetrofitClient.getInstance()
                .create(ApiService.class)
                .getWeather(kota.lat, kota.lon, true, "Asia/Jakarta")
                .enqueue(new Callback<WeatherResponse>() {
                    @Override
                    public void onResponse(Call<WeatherResponse> call, Response<WeatherResponse> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            WeatherResponse.CurrentWeather cw = response.body().current_weather;
                            KotaCuaca kc = new KotaCuaca();
                            kc.nama = kota.nama;
                            kc.suhu = cw.temperature;
                            kc.weatherCode = cw.weathercode;
                            kc.iconUrl = "https://openweathermap.org/img/wn/"
                                    + mapIcon(cw.weathercode) + "@2x.png";

                            runOnUiThread(() -> {
                                listCuaca.add(kc);
                                adapter.notifyItemInserted(listCuaca.size() - 1);
                            });
                        }
                        fetchNext(); // kota berikutnya
                    }

                    @Override
                    public void onFailure(Call<WeatherResponse> call, Throwable t) {
                        fetchNext(); // tetap lanjut
                    }
                });
    }

    private String mapIcon(int code) {
        if (code == 0 || code == 1) return "01d";
        if (code == 2) return "02d";
        if (code == 3) return "03d";
        if (code == 45 || code == 48) return "50d";
        if (code >= 51 && code <= 55) return "09d";
        if (code >= 61 && code <= 65) return "10d";
        return "01d";
    }

    private void updateDarkModeCheck() {
        darkModeChecked = AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES;
    }
}